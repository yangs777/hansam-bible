# Genesis 7:1–17

Hansam Yang · Original Bible · v0.4.31

AI-assisted translation draft · specialist and native-language review pending

This is a research draft. It does not claim discovery of an autograph or a complete reconstruction of the earliest text.

Provisional selections for verses 1–17 distinguish model proposals, actual final opinions, limited witness observations and access gaps. Specialist review and full collation remain pending.

Basis: 고정WLC4.20/OSHB잠정저본.독립GPT·Gemini초기안및실제최종의견·반론·난구검토보존.과거Claude다섯절초안재사용.Swete1901인쇄10쪽직접열람,레닌그라드4v핵심자음어구한정대조.현대장치·사본전면대조·인간전문가검수대기.

Decision: Current best selected — revisable with stronger evidence

## 1 · HYB.GEN.007.001

Hebrew display (MT/WLC): וַיֹּ֤אמֶר יְהוָה֙ לְנֹ֔חַ בֹּֽא־אַתָּ֥ה וְכָל־בֵּיתְךָ֖ אֶל־הַתֵּבָ֑ה כִּֽי־אֹתְךָ֥ רָאִ֛יתִי צַדִּ֥יק לְפָנַ֖י בַּדּ֥וֹר הַזֶּֽה׃

YHWH said to Noah, “Enter the ark, you and all your household, for I have seen that you are righteous before me in this generation.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.7.1

### Current best selected translation

화자 여호와와 노아수신자,명령,온집안,이유 כי,앞세운 목적어너,보았다와 의롭다·내앞에서·이세대를 보존한다.집은 건물이아닌 구성원으로 읽는다.

#### claude-sonnet-5-5

The LORD said to Noah, "Go into the ark, you and all your household, for I have seen that you are righteous before me in this generation.

Final opinion (Korean original): 현재 번역을 잠정안으로 둔다.

#### gemini-3.8-flash-medium

Then YHWH said to Noah, “Come into the ark, you and all your household, for I have seen that you are righteous before Me in this generation.

Final opinion (Korean original): 노아 1인에 대한 구체적 평가와 가구 전체의 방주 승선 연대성을 원문 어순대로 공존시키고, 신명 '여호와'를 확고히 지킨 현 후보안을 잠정 채택 권고합니다. 신적 발화가 계속되므로 절 끝 따옴표는 닫지 않습니다.

#### gpt-6.1-sol

YHWH said to Noah, “Enter the ark, you and all your household, for I have seen that you are righteous before me in this generation.

Final opinion (Korean original): 화자 여호와와 노아수신자,명령,온집안,이유 כי,앞세운 목적어너,보았다와 의롭다·내앞에서·이세대를 보존한다.집은 건물이아닌 구성원으로 읽는다. 반론: 의롭게 인정했다는 평가적번역도 가능하나 보았다를남긴다.명령은단수노아에게 주어졌지만 가구전체가포함된다.너의전면배치가 오직너만이라는 배타적무죄를뜻한다고단정하지않는다.의로움의신학적기준·완전무죄·가족의동일평가를보충하지않는다. 고정WLC와Swete차이를구별하고인간전문가검수대기.

Counterargument (Korean): 의롭게 인정했다는 평가적번역도 가능하나 보았다를남긴다.명령은단수노아에게 주어졌지만 가구전체가포함된다.너의전면배치가 오직너만이라는 배타적무죄를뜻한다고단정하지않는다.의로움의신학적기준·완전무죄·가족의동일평가를보충하지않는다.

Previous v0.4.28

YHWH said to Noah, “Enter the ark, you and all your household, for I have seen that you are righteous before me in this generation.

Previous v0.4.29

YHWH said to Noah, “Enter the ark, you and all your household, for I have seen that you are righteous before me in this generation.

Previous v0.4.30

YHWH said to Noah, “Enter the ark, you and all your household, for I have seen that you are righteous before me in this generation.

## 2 · HYB.GEN.007.002

Hebrew display (MT/WLC): מִכֹּ֣ל ׀ הַבְּהֵמָ֣ה הַטְּהוֹרָ֗ה תִּֽקַּח־לְךָ֛ שִׁבְעָ֥ה שִׁבְעָ֖ה אִ֣ישׁ וְאִשְׁתּ֑וֹ וּמִן־הַבְּהֵמָ֡ה אֲ֠שֶׁר לֹ֣א טְהֹרָ֥ה הִ֛וא שְׁנַ֖יִם אִ֥ישׁ וְאִשְׁתּֽוֹ׃

From every clean animal take seven by seven, a male and its mate; and from the animals that are not clean, two, a male and its mate.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.7.2

### Current best selected translation

반복수사 שבעה שבעה의 분배형태와 사람용어인 איש ואשתו의동물짝 적용을 드러낸다.한국어 일곱씩은 반복수사의분배기능을 자연스럽게옮긴다.뒤의둘은 수컷과짝을 이룬다.정결하지않은이라는부정을지켜 부정형범주를동일어휘로유지한다. 7:2의짝·수량논쟁은공개주석에유보.

#### claude-sonnet-5-5

From every clean animal take seven pairs, a male and its mate; and from the animals that are not clean, two, a male and its mate;

Final opinion (Korean original): '암수 일곱 쌍'으로 잠정 정리한다.

#### gemini-3.8-flash-medium

Of every clean beast you shall take to you sevens, a male and his female; and of the beasts that are not clean, two, a male and his female;

Final opinion (Korean original): 사본 교정(텍스트 변경)과 번역 선택(해석적 어휘 결정)을 엄격히 구분하여, 본문은 분배형 직역 '일곱씩, 수컷과 그 짝'으로 원문의 불명확성을 그대로 열어두고, '일곱 쌍(14마리)' 및 '총 7마리' 해석의 긴장은 접힌 주석에 객관적으로 명시하는 방안으로 잠정 채택 권고합니다.

#### gpt-6.1-sol

From every clean animal take seven by seven, a male and its mate; and from the animals that are not clean, two, a male and its mate.

Final opinion (Korean original): 반복수사 שבעה שבעה의 분배형태와 사람용어인 איש ואשתו의동물짝 적용을 드러낸다.한국어 일곱씩은 반복수사의분배기능을 자연스럽게옮긴다.뒤의둘은 수컷과짝을 이룬다.정결하지않은이라는부정을지켜 부정형범주를동일어휘로유지한다. 반론: 정결한동물은 일곱쌍(14마리)인지 총일곱인지 논쟁이있다.수컷과그짝의분배를일곱에적용하면 일곱쌍이자연스러우나 반복수사만으로 숫자를곱하지는않는다.직역후보는 현대독자에게 수량을불명확하게할수있다.정결은 위생이나후대음식법 전체를뜻한다고확정못한다.בהמה범위를가축만으로 제한할지도유보. 고정WLC와Swete차이를구별하고인간전문가검수대기.

Counterargument (Korean): 정결한동물은 일곱쌍(14마리)인지 총일곱인지 논쟁이있다.수컷과그짝의분배를일곱에적용하면 일곱쌍이자연스러우나 반복수사만으로 숫자를곱하지는않는다.직역후보는 현대독자에게 수량을불명확하게할수있다.정결은 위생이나후대음식법 전체를뜻한다고확정못한다.בהמה범위를가축만으로 제한할지도유보.

Previous v0.4.28

From every clean animal take seven by seven, a male and its mate; and from the animals that are not clean, two, a male and its mate.

Previous v0.4.29

From every clean animal take seven by seven, a male and its mate; and from the animals that are not clean, two, a male and its mate.

Previous v0.4.30

From every clean animal take seven by seven, a male and its mate; and from the animals that are not clean, two, a male and its mate.

## 3 · HYB.GEN.007.003

Hebrew display (MT/WLC): גַּ֣ם מֵע֧וֹף הַשָּׁמַ֛יִם שִׁבְעָ֥ה שִׁבְעָ֖ה זָכָ֣ר וּנְקֵבָ֑ה לְחַיּ֥וֹת זֶ֖רַע עַל־פְּנֵ֥י כָל־הָאָֽרֶץ׃

Also from the birds of the heavens, take seven by seven, male and female, to keep offspring alive over the face of all the earth.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.7.3

### Current best selected translation

גם의추가,새의범주,분배수사반복과암수,살려보존하는목적,זרע와온땅위의공간표현을유지.데려가다는7:2의생략된동사를문맥에서보충.씨는개체의종자라는뜻이아니라후손의연속을가리키는표현으로읽음. 이번 후보: WLC의 비구분 새 표현을 유지하며 그리스어의 긴 구별을 삽입하지 않음. 일곱쌍이 강한 해석이나 일곱씩으로 분배표현 보존. 총일곱 대안과 직역의 모호함 공개.

#### claude-sonnet-5-5

also of the birds of the sky, seven pairs, male and female, to keep their kind alive on the face of all the earth.

Final opinion (Korean original): 현재 번역을 잠정안으로 둔다.

#### gemini-3.8-flash-medium

also of the birds of the heavens by sevens, male and female, to keep seed alive on the face of all the earth.

Final opinion (Korean original): 고정 WLC 본문에 충실하며 직역의 해석 가능성(일곱 쌍 대 총 일곱)을 훼손하지 않은 candidate의 3개 언어 번역을 잠정 채택 권고합니다. 조류의 정결성 구분 미명시 및 70인역과의 차이는 각주와 비평 공백으로 공개 처리합니다.

#### gpt-6.1-sol

Also from the birds of the heavens, take seven by seven, male and female, to keep offspring alive over the face of all the earth.

Final opinion (Korean original): WLC의 비구분 새 표현을 유지하며 그리스어의 긴 구별을 삽입하지 않음. 일곱쌍이 강한 해석이나 일곱씩으로 분배표현 보존. 총일곱 대안과 직역의 모호함 공개. 반론: 그리스어 긴 문구가 더 이른 다른 히브리어 저본을 반영했을 가능성을 배제 못함. 7:2에 맞춘 확대 가능성도 입증된 기원이 아님. 사마리아오경·현대장치 대조 전에는 우열 확정 못함. 인간전문가 검수 대기.

Counterargument (Korean): 일곱씩은총일곱/일곱쌍을확정하지않아불명확하다.암수와분배를함께읽는일곱쌍해석이강하다.씨는한국어에서종자로오해될수있어자손/후손이명료한대안이다.본문에새의정결구분은명시되어있지않으므로7:2에서자동보충하지않음.동물의현대종분류나분포회복기제를단정하지않음. 그리스어 긴 문구가 더 이른 다른 히브리어 저본을 반영했을 가능성을 배제 못함. 7:2에 맞춘 확대 가능성도 입증된 기원이 아님. 사마리아오경·현대장치 대조 전에는 우열 확정 못함.

Previous v0.4.29

Also from the birds of the heavens, take seven by seven, male and female, to keep offspring alive over the face of all the earth.

Previous v0.4.30

Also from the birds of the heavens, take seven by seven, male and female, to keep offspring alive over the face of all the earth.

## 4 · HYB.GEN.007.004

Hebrew display (MT/WLC): כִּי֩ לְיָמִ֨ים ע֜וֹד שִׁבְעָ֗ה אָֽנֹכִי֙ מַמְטִ֣יר עַל־הָאָ֔רֶץ אַרְבָּעִ֣ים י֔וֹם וְאַרְבָּעִ֖ים לָ֑יְלָה וּמָחִ֗יתִי אֶֽת־כָּל־הַיְקוּם֙ אֲשֶׁ֣ר עָשִׂ֔יתִי מֵעַ֖ל פְּנֵ֥י הָֽאֲדָמָֽה׃

For in seven more days I will send rain upon the earth for forty days and forty nights, and I will wipe every living thing that I have made from the face of the ground.”

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.7.4

### Current best selected translation

עוד를더로표현하고남은일곱날과사십낮·사십밤,명시1인칭주어와비내림,만들었던것을지면에서지우는행위를보존한다.יקום은문맥상생명체로번역하되존재전체의무화로확대하지않음.7:1부터발화가계속되므로이절끝에서인용닫음. 이번 후보: WLC 잠정 유지. 한국어에서도 두 사십 명시. יקום은 문맥상 살아 있는 모든 것으로 옮기되 존재물 전체라는 넓은 대안과 해석성을 밝힘.

#### claude-sonnet-5-5

For in seven days I will send rain on the earth for forty days and forty nights, and I will blot out from the face of the ground every living thing that I have made."

Final opinion (Korean original): 현재 번역을 잠정안으로 둔다.

#### gemini-3.8-flash-medium

For after seven more days I will send rain on the earth forty days and forty nights, and I will blot out from the face of the ground every existing thing that I have made.”

Final opinion (Korean original): 신적 심판 주체(1인칭 주어)의 행동과 시간·지리적 표현을 가감 없이 전달한 candidate의 번역을 잠정 채택 권고합니다. 'יְקוּם'의 외연과 관련된 해석적 층위는 주석으로 공개합니다.

#### gpt-6.1-sol

For in seven more days I will send rain upon the earth for forty days and forty nights, and I will wipe every living thing that I have made from the face of the ground.”

Final opinion (Korean original): WLC 잠정 유지. 한국어에서도 두 사십 명시. יקום은 문맥상 살아 있는 모든 것으로 옮기되 존재물 전체라는 넓은 대안과 해석성을 밝힘. 반론: יקום의 외연과 땅/지면 범위는 한 절만으로 확정 못함. 어원만으로 생물만 또는 우주 전체라고 단정 불가. 그리스어 대응도 배후 히브리어를 증명하지 않음. 인간전문가 검수 대기.

Counterargument (Korean): יקום은존재하는모든것으로더넓게번역할수있어살아있는은문맥해석이다.범위가모든생물종·식물·수생생물까지인지본문한절만으로확정하지못한다.한국어사십일밤낮은반복된두사십을압축하므로엄밀히사십일과사십밤이대안.כי의이유접속을초기한국어에서는자연스러운설명순서로처리했지만왜냐하면을명시할수있다.홍수지질범위를단정하지않음. יקום의 외연과 땅/지면 범위는 한 절만으로 확정 못함. 어원만으로 생물만 또는 우주 전체라고 단정 불가. 그리스어 대응도 배후 히브리어를 증명하지 않음.

Previous v0.4.29

For in seven more days I will send rain upon the earth for forty days and forty nights, and I will wipe every living thing that I have made from the face of the ground.”

Previous v0.4.30

For in seven more days I will send rain upon the earth for forty days and forty nights, and I will wipe every living thing that I have made from the face of the ground.”

## 5 · HYB.GEN.007.005

Hebrew display (MT/WLC): וַיַּ֖עַשׂ נֹ֑חַ כְּכֹ֥ל אֲשֶׁר־צִוָּ֖הוּ יְהוָֽה׃

Noah did according to all that YHWH had commanded him.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.7.5

### Current best selected translation

서술주어노아,명령주체여호와,목적접미사그에게,명령전체에따른행동을보존.6:22와달리이절의행동동사는한번뿐이므로그렇게행했다를추가하지않음. 이번 후보: WLC יהוה는 한국어 여호와, 영어·스페인어 YHWH로 유지. 모든 것과 행위를 보존.

#### claude-sonnet-5-5

And Noah did all that the LORD had commanded him.

Final opinion (Korean original): 현재 번역을 잠정안으로 둔다.

#### gemini-3.8-flash-medium

And Noah did according to all that YHWH commanded him.

Final opinion (Korean original): 원문 형태소에 충실하고 신명 표기 지침을 정확히 따른 candidate의 서술형 번역을 잠정 채택 권고합니다.

#### gpt-6.1-sol

Noah did according to all that YHWH had commanded him.

Final opinion (Korean original): WLC יהוה는 한국어 여호와, 영어·스페인어 YHWH로 유지. 모든 것과 행위를 보존. 반론: 그리스어 확대의 기원은 미확정. 문법의 순서만으로 즉시성·내면·절대무죄를 입증 못함. 인간전문가 검수 대기.

Counterargument (Korean): 했다는시간순서만으로방주입장완료나모든세부이행기제를확정하지못한다.כל을모든것으로보존하되내적심리나완전무죄를추가하면과잉이다.영어과거완료는명령의선행성을명시한문맥의역이며히브리어상과일대일대응아님. 그리스어 확대의 기원은 미확정. 문법의 순서만으로 즉시성·내면·절대무죄를 입증 못함.

Previous v0.4.29

Noah did according to all that YHWH had commanded him.

Previous v0.4.30

Noah did according to all that YHWH had commanded him.

## 6 · HYB.GEN.007.006

Hebrew display (MT/WLC): וְנֹ֕חַ בֶּן־שֵׁ֥שׁ מֵא֖וֹת שָׁנָ֑ה וְהַמַּבּ֣וּל הָיָ֔ה מַ֖יִם עַל־הָאָֽרֶץ׃

Noah was six hundred years old, and the floodwaters were upon the earth.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.7.6

### Current best selected translation

초기안의 시간절은 명시 접속이 아니라 문맥적 해석이었다. 이번 후보는 when/도래 표현을 덜고 나이 명사절과 홍수물 상태를 접속으로 잇는다. 물의 설명적 병치는 홍수의 물로 통합한다. WLC의 물을 생략하지 않고 홍수의 물로 자연스럽게 통합. when을 덜고 접속을 살림. 그리스어 짧은 주본문을 히브리어 교정 근거로 삼지 않음.

#### claude-sonnet-5-5

Noah was six hundred years old when the flood of waters came upon the earth.

Final opinion (Korean original): 현재 번역을 잠정안으로 둔다.

#### gemini-3.8-flash-medium

Now Noah was six hundred years old when the flood came, water upon the earth.

Final opinion (Korean original): 시간절 의역(when)을 지양하고 WLC의 명사 병치를 존중한 candidate의 균형 잡힌 번역을 잠정 채택 권고합니다.

#### gpt-6.1-sol

Noah was six hundred years old when the flood came, waters upon the earth.

Final opinion (Korean original): WLC의 물을 생략하지 않고 홍수의 물로 자연스럽게 통합. when을 덜고 접속을 살림. 그리스어 짧은 주본문을 히브리어 교정 근거로 삼지 않음. 반론: 그리스어 물 생략/추가는 번역 또는 다른 저본 가능성. 병치의 정확한 구문분석은 논쟁 가능. 단순 연결도 독자의 시간 이해를 완전히 중립화하지 못함. 현대 날짜·지질범위 보충 금지. 인간전문가 검수 대기.

Counterargument (Korean): 히브리어 접속은 한국어 때·영어 when·스페인어 cuando를 명시하지 않는다.시간관계 표현은 문맥해석이다.홍수와 물의 병치 및 היה의 관계는 자연스러운 번역에서 풀어쓸 수 있으나 범람의 지질학적 범위·역사적 연대는 확정할 수 없다. 그리스어 물 생략/추가는 번역 또는 다른 저본 가능성. 병치의 정확한 구문분석은 논쟁 가능. 단순 연결도 독자의 시간 이해를 완전히 중립화하지 못함. 현대 날짜·지질범위 보충 금지.

Previous v0.4.29

Noah was six hundred years old, and the floodwaters were upon the earth.

Previous v0.4.30

Noah was six hundred years old, and the floodwaters were upon the earth.

## 7 · HYB.GEN.007.007

Hebrew display (MT/WLC): וַיָּ֣בֹא נֹ֗חַ וּ֠בָנָיו וְאִשְׁתּ֧וֹ וּנְשֵֽׁי־בָנָ֛יו אִתּ֖וֹ אֶל־הַתֵּבָ֑ה מִפְּנֵ֖י מֵ֥י הַמַּבּֽוּל׃

Noah entered the ark, and his sons, his wife, and his sons’ wives with him, because of the waters of the flood.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.7.7

### Current best selected translation

들어감·노아·아들들·아내·아들들의 아내들·그와함께·방주·홍수물의 요소를 보존.מפני는 원인 때문에로 잠정선택하며 피하여라는 해석도 가능.한국어 며느리들은 아들들의 아내들을 자연스럽게 옮긴다. 이번 후보: 때문에/because of/por causa de로 인과관계 선택. 피하여도 가능한 해석으로 보존. 순간 수위·위기·정밀 입장일·총 인원수는 보충하지 않음.

#### claude-sonnet-5-5

Noah went into the ark, with his sons and his wife and his sons' wives, because of the waters of the flood.

Final opinion (Korean original): 현재 번역을 잠정안으로 둔다.

#### gemini-3.8-flash-medium

And Noah went into the ark, and his sons, his wife, and his sons’ wives with him, because of the waters of the flood.

Final opinion (Korean original): 과도한 정황 묘사를 억제하고 원문의 인과적 전치사와 친족 열거를 충실히 살린 candidate 번역을 잠정 채택 권고합니다.

#### gpt-6.1-sol

Noah entered the ark, and his sons, his wife, and his sons’ wives with him, because of the waters of the flood.

Final opinion (Korean original): 때문에/because of/por causa de로 인과관계 선택. 피하여도 가능한 해석으로 보존. 순간 수위·위기·정밀 입장일·총 인원수는 보충하지 않음. 반론: 인과적 번역은 회피의 함의를 약화할 수 있고 피하여는 장면을 더 구체화함. 그리스어 인과표현만으로 히브리어 전치사의 모든 함의와 사건시점 확정 못함. 인간전문가 검수 대기.

Counterargument (Korean): מפני는 때문에/앞에서/피하여로 번역될 수 있다.때문에는 위협에서 피하는 함의를 약화할 수 있고 피하여는 도피의 세부를 더한다.열거와 단수동사의 결합은 노아와 가족의 진입을 나타내지만 수위나 정확한 진입시점·가족 인원수를 이 절만으로 확정하지 못한다. 인과적 번역은 회피의 함의를 약화할 수 있고 피하여는 장면을 더 구체화함. 그리스어 인과표현만으로 히브리어 전치사의 모든 함의와 사건시점 확정 못함.

Previous v0.4.29

Noah entered the ark, and his sons, his wife, and his sons’ wives with him, because of the waters of the flood.

Previous v0.4.30

Noah entered the ark, and his sons, his wife, and his sons’ wives with him, because of the waters of the flood.

## 8 · HYB.GEN.007.008

Hebrew display (MT/WLC): מִן־הַבְּהֵמָה֙ הַטְּהוֹרָ֔ה וּמִן־הַ֨בְּהֵמָ֔ה אֲשֶׁ֥ר אֵינֶ֖נָּה טְהֹרָ֑ה וּמִ֨ן־הָע֔וֹף וְכֹ֥ל אֲשֶׁר־רֹמֵ֖שׂ עַל־הָֽאֲדָמָֽה׃

From the clean animals and the animals that were not clean, and from the birds and everything that creeps on the ground,

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.7.8

### Current best selected translation

8절은 유한동사가 없는 출처·부분 집합 구문으로 9절에 이어 읽는다. 부정결을 정결하지 않은으로 원문 부정을 보존. 새는 정결구분을 추가하지 않는다.

#### claude-sonnet-5-5

Of clean animals, and of animals that are not clean, and of birds, and of everything that creeps on the ground,

Final opinion (Korean original): 현재 번역을 잠정안으로 둔다.

#### gemini-3.8-flash-medium

From the clean animals and from the animals that are not clean, and from the birds, and everything that creeps on the ground,

Final opinion (Korean original): 본 견해는 모델 간 비교 및 편집자 열람 보고를 반영한 독립 평가이며 최종 확정 채택이 아닙니다. 고정 WLC를 방어 가능한 잠정 저본으로 권고하되, 그리스어의 긴 열거 차이를 공백 및 대안으로 기록에 보존합니다. 생물학적 종의 세부 분류나 전체 개체수를 본문에 추가하지 않습니다.

#### gpt-6.1-sol

From the clean animals and the animals that were not clean, and from the birds and everything that creeps on the ground,

Final opinion (Korean original): 9절과 연결되는 미완결 구문을 유지. 정결분류의 현대 적용·생물종의 정확한 범주·전체 개체수는 확정하지 않는다. 실제 사본·그리스어 관찰과 비교해도 고정WLC 잠정선택 유지. 최초원문 인증·인간전문가 검수완료 아님.

Counterargument (Korean): 그리스어 긴 열거가 다른 히브리어 저본인지 조화적 확대인지 확정 못함. 더 짧다는 이유만으로 원형이라 단정하지 않음.

Previous v0.4.30

From the clean animals and the animals that were not clean, and from the birds and everything that creeps on the ground,

## 9 · HYB.GEN.007.009

Hebrew display (MT/WLC): שְׁנַ֨יִם שְׁנַ֜יִם בָּ֧אוּ אֶל־נֹ֛חַ אֶל־הַתֵּבָ֖ה זָכָ֣ר וּנְקֵבָ֑ה כַּֽאֲשֶׁ֛ר צִוָּ֥ה אֱלֹהִ֖ים אֶת־נֹֽחַ׃

they came two by two to Noah, into the ark, male and female, as God had commanded Noah.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.7.9

### Current best selected translation

둘 반복은 분배·둘씩. 노아에게와 방주로의 두 방향을 보존. 하나님은 אלהים이며 5절 여호와와 구별한다. 한국어 들어갔다는 두번째 방향을 자연스럽게 풀어쓴 것이다.

#### claude-sonnet-5-5

two by two they came to Noah into the ark, male and female, as God had commanded Noah.

Final opinion (Korean original): 현재 번역을 잠정안으로 둔다.

#### gemini-3.8-flash-medium

two by two they came to Noah into the ark, male and female, just as God had commanded Noah.

Final opinion (Korean original): 본 견해는 독립 평가이며 최종 확정 채택이 아닙니다. 본문에 총수 조화 설명이나 인위적 해설을 덧붙이지 않고, WLC의 이동·방향·암수·명령 진술을 보존한 번역을 잠정 채택 권고합니다.

#### gpt-6.1-sol

they came two by two to Noah, into the ark, male and female, as God had commanded Noah.

Final opinion (Korean original): 둘씩의 이동·암수·두 방향·노아에게 명령한 하나님을 보존. 들어감의 상세 과정과 총수는 보충하지 않는다. 실제 사본·그리스어 관찰과 비교해도 고정WLC 잠정선택 유지. 최초원문 인증·인간전문가 검수완료 아님.

Counterargument (Korean): 한국어 들어갔다는 방향구를 자연스럽게 푼 표현이며 총두마리라는 뜻은 아님.

Previous v0.4.30

they came two by two to Noah, into the ark, male and female, as God had commanded Noah.

## 10 · HYB.GEN.007.010

Hebrew display (MT/WLC): וַֽיְהִ֖י לְשִׁבְעַ֣ת הַיָּמִ֑ים וּמֵ֣י הַמַּבּ֔וּל הָי֖וּ עַל־הָאָֽרֶץ׃

After the seven days, the waters of the flood were upon the earth.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.7.10

### Current best selected translation

לשבעת הימים는 앞 일곱날과 연결해 이레가 지난 때로 읽는다. 후속 היו는 물이 땅위에 있음을 진술한다.

#### claude-sonnet-5-5

And after the seven days the waters of the flood came upon the earth.

Final opinion (Korean original): 현재 번역을 잠정안으로 둔다.

#### gemini-3.8-flash-medium

And it came to pass after the seven days that the waters of the flood were upon the earth.

Final opinion (Korean original): 본 견해는 독립 평가이며 최종 확정 채택이 아닙니다. 인위적인 연대기적 시간표나 역법 조화를 본문에 삽입하지 않고, 7일의 경과와 물의 정태적 존재를 담담하게 번역한 WLC 잠정안을 권고합니다.

#### gpt-6.1-sol

After the seven days, the waters of the flood were upon the earth.

Final opinion (Korean original): 일곱날과 홍수물 상태를 유지하되 현대 날짜나 앞 절과의 정밀 시간표는 만들지 않는다. 실제 사본·그리스어 관찰과 비교해도 고정WLC 잠정선택 유지. 최초원문 인증·인간전문가 검수완료 아님.

Counterargument (Korean): 이레째/이레후의 시점 뉘앙스는 논쟁 가능. 번역표현만으로 시간표를 확정하지 않음.

Previous v0.4.30

After the seven days, the waters of the flood were upon the earth.

## 11 · HYB.GEN.007.011

Hebrew display (MT/WLC): בִּשְׁנַ֨ת שֵׁשׁ־מֵא֤וֹת שָׁנָה֙ לְחַיֵּי־נֹ֔חַ בַּחֹ֨דֶשׁ֙ הַשֵּׁנִ֔י בְּשִׁבְעָֽה־עָשָׂ֥ר י֖וֹם לַחֹ֑דֶשׁ בַּיּ֣וֹם הַזֶּ֗ה נִבְקְעוּ֙ כָּֽל־מַעְיְנֹת֙ תְּה֣וֹם רַבָּ֔ה וַאֲרֻבֹּ֥ת הַשָּׁמַ֖יִם נִפְתָּֽחוּ׃

In the six hundredth year of Noah’s life, in the second month, on the seventeenth day of the month, on that very day all the springs of the great deep burst open, and the windows of the heavens were opened.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.7.11

### Current best selected translation

노아생애 육백년·둘째달·17일·바로그날을 모두 보존. 두 수동동사는 터짐과 열림으로 옮기고 큰깊음의 모든 샘과 하늘창을 병렬로 둔다.

#### claude-sonnet-5-5

In the six hundredth year of Noah's life, in the second month, on the seventeenth day of the month, on that day all the fountains of the great deep burst forth, and the windows of the heavens were opened.

Final opinion (Korean original): '창들'로 잠정 정리한다.

#### gemini-3.8-flash-medium

In the six hundredth year of Noah's life, in the second month, on the seventeenth day of the month, on that very day all the springs of the great deep burst open, and the windows of heaven were opened.

Final opinion (Korean original): 본 견해는 독립 평가이며 최종 확정 채택이 아닙니다. 27일을 현대 역법이나 지질학적 기제로 조화시키지 않으며, WLC의 17일과 큰 깊음·하늘의 창들을 잠정 채택하되 그리스어 역본에서 관찰된 27일 및 '큰'의 생략을 주요 비평적 대안으로 명시합니다.

#### gpt-6.1-sol

In the six hundredth year of Noah’s life, in the second month, on the seventeenth day of the month, on that very day all the springs of the great deep burst open, and the windows of the heavens were opened.

Final opinion (Korean original): 직접읽은 Swete 주본문의27일과 큰 생략을 실제 대안으로 보존. 고정WLC의17일·큰깊음·하늘창을 잠정유지하되 초기성은 미확인. 현대달력·물리기제·최초원문 인증 없음.

Counterargument (Korean): 그리스어가 더 이른 히브리어 숫자를 반영할 가능성을 배제 못함. 17일이 더 오래되었다고 판정한 것이 아님. Swete는 고대사본 자체가 아니고 현대장치 미열람.

Previous v0.4.30

In the six hundredth year of Noah’s life, in the second month, on the seventeenth day of the month, on that very day all the springs of the great deep burst open, and the windows of the heavens were opened.

## 12 · HYB.GEN.007.012

Hebrew display (MT/WLC): וַֽיְהִ֥י הַגֶּ֖שֶׁם עַל־הָאָ֑רֶץ אַרְבָּעִ֣ים י֔וֹם וְאַרְבָּעִ֖ים לָֽיְלָה׃

The rain was upon the earth for forty days and forty nights.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.7.12

### Current best selected translation

비·땅위·사십낮과 사십밤을 모두 보존. 한국어 내렸다와 스페인어 cayó는 비가 있었다를 자연스럽게 옮긴다.

#### claude-sonnet-5-5

And the rain fell on the earth forty days and forty nights.

Final opinion (Korean original): 현재 번역을 잠정안으로 둔다.

#### gemini-3.8-flash-medium

And the rain was upon the earth forty days and forty nights.

Final opinion (Korean original): 본 견해는 독립 평가이며 최종 확정 채택이 아닙니다. 폭우/일반비의 작위적 이분법을 배제하고, 40주야의 강우 지속성을 왜곡 없이 기술한 WLC 기반 잠정안을 권고합니다. 홍수 전체 기간과의 혼동이나 전 지구적 범위에 대한 교리적 확장은 추가하지 않습니다.

#### gpt-6.1-sol

The rain was upon the earth for forty days and forty nights.

Final opinion (Korean original): 두 사십과 비의 지속을 유지. 원인·전지구성·홍수 전체 종료시점은 덧붙이지 않는다. 실제 사본·그리스어 관찰과 비교해도 고정WLC 잠정선택 유지. 최초원문 인증·인간전문가 검수완료 아님.

Counterargument (Korean): גשם이 언제나 מטר와 배타적인 폭우 대립이라는 Gemini 초기 설명은 근거 미확인으로 채택하지 않음. 홍수전체기간과 강우기간을 혼동하지 않음.

Previous v0.4.30

The rain was upon the earth for forty days and forty nights.

## 13 · HYB.GEN.007.013

Hebrew display (MT/WLC): בְּעֶ֨צֶם הַיּ֤וֹם הַזֶּה֙ בָּ֣א נֹ֔חַ וְשֵׁם־וְחָ֥ם וָיֶ֖פֶת בְּנֵי־נֹ֑חַ וְאֵ֣שֶׁת נֹ֗חַ וּשְׁלֹ֧שֶׁת נְשֵֽׁי־בָנָ֛יו אִתָּ֖ם אֶל־הַתֵּבָֽה׃

On that very day Noah, and Shem, Ham, and Japheth, Noah’s sons, and Noah’s wife and the three wives of his sons with them, entered the ark.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.7.13

### Current best selected translation

히브리어 가족열거·세 아내·אתם, Swete 그날·가족·μετ᾽ αὐτοῦ 관찰. 히브리어 복수 그들과 함께 및 세 아내 유지.

#### claude-sonnet-5-5

On that very day Noah and his sons Shem and Ham and Japheth, and Noah's wife and the three wives of his sons with them, entered the ark,

Final opinion (Korean original): 현재 번역을 잠정안으로 둔다.

#### gemini-3.8-flash-medium

On that very day Noah and Noah's sons, Shem and Ham and Japheth, and Noah's wife and the three wives of his sons with them, entered into the ark.

Final opinion (Korean original): WLC의 복수 접미사(אִתָּם)와 세 며느리 표기를 보존하고 외재적 인원수 합산 없이 본문 어휘대로 번역한 안을 잠정 채택 권고합니다.

#### gpt-6.1-sol

On that very day Noah, and Shem, Ham, and Japheth, Noah’s sons, and Noah’s wife and the three wives of his sons with them, entered the ark.

Final opinion (Korean original): 히브리어 복수 그들과 함께 및 세 아내 유지. 그리스어의 그와 함께는 표현차이이며 배후 히브리어 단수이문인지 번역선택인지 확정 못함. 해당 대안과 접근공백을 주석·근거기록으로 보존하는 잠정채택 권고. 인간전문가 검수 대기.

Counterargument (Korean): אתם의 복수 지시범위를 노아 한명으로 축소하지 않음. 단수 בא 뒤 복합주어는 한국어 복수서술로 자연화. 정확한 입장순서·인원 합계는 추가하지 않는다. 그리스어의 그와 함께는 표현차이이며 배후 히브리어 단수이문인지 번역선택인지 확정 못함.

## 14 · HYB.GEN.007.014

Hebrew display (MT/WLC): הֵ֜מָּה וְכָל־הַֽחַיָּ֣ה לְמִינָ֗הּ וְכָל־הַבְּהֵמָה֙ לְמִינָ֔הּ וְכָל־הָרֶ֛מֶשׂ הָרֹמֵ֥שׂ עַל־הָאָ֖רֶץ לְמִינֵ֑הוּ וְכָל־הָע֣וֹף לְמִינֵ֔הוּ כֹּ֖ל צִפּ֥וֹר כָּל־כָּנָֽף׃

They, and every wild animal according to its kind, all livestock according to their kinds, every creeping thing that creeps on the earth according to its kind, and every flying creature according to its kind—every bird, every winged thing—entered.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.7.14

### Current best selected translation

WLC·사본 핵심자음에 그들 및 끝 כל צפור כל כנף. Swete 주본문은 네 범주만 열거하며 두 구절 미표시. WLC의 더 긴 열거를 유지. 종류는 현대 생물분류가 아님. 14절 들어갔다는 13절에서 연결한 보충동사. 모든새/모든날개의 환유를 열거로 풀었으며 모든종류의날개 대안도 남긴다. 가축은 בהמה의 문맥대조이며 고정분류 주장 아님.

#### claude-sonnet-5-5

they and every wild animal according to its kind, and all the livestock according to their kinds, and every creeping thing that creeps on the earth according to its kind, and every bird according to its kind, every winged bird of every sort.

Final opinion (Korean original): 현재 번역을 잠정안으로 둔다.

#### gemini-3.8-flash-medium

They, and every beast after its kind, and all cattle after their kind, and every creeping thing that creeps on the earth after its kind, and every bird after its kind, every bird of every wing.

Final opinion (Korean original): WLC의 긴 열거를 유지하되, 무동사 구문의 보충 성격과 그리스어 역본의 짧은 형태 대안을 난외 주석으로 보존하는 조건으로 잠정 채택 권고합니다.

#### gpt-6.1-sol

They, and every wild animal according to its kind, every domestic animal according to its kind, every creeping thing that creeps on the earth according to its kind, and every flying creature according to its kind—every bird, every winged thing—entered.

Final opinion (Korean original): WLC의 더 긴 열거를 유지. 종류는 현대 생물분류가 아님. 그리스어의 짧은 열거가 더 이른 히브리어를 반영할 가능성 또는 번역상 축약 가능성 양쪽 미확정. 길이 자체로 우열 결정 못함. 해당 대안과 접근공백을 주석·근거기록으로 보존하는 잠정채택 권고. 인간전문가 검수 대기.

Counterargument (Korean): 동사가 없는 열거에 들어갔다 보충은 문맥해석. חיה/בהמה를 들짐승/집짐승으로 대조하지만 항상 고정적 분류 아님. כל כנף는 모든종류의날개 또는 날개있는 모든것으로 해석가능. 현대 종 분류 아님. 그리스어의 짧은 열거가 더 이른 히브리어를 반영할 가능성 또는 번역상 축약 가능성 양쪽 미확정. 길이 자체로 우열 결정 못함.

## 15 · HYB.GEN.007.015

Hebrew display (MT/WLC): וַיָּבֹ֥אוּ אֶל־נֹ֖חַ אֶל־הַתֵּבָ֑ה שְׁנַ֤יִם שְׁנַ֨יִם֙ מִכָּל־הַבָּשָׂ֔ר אֲשֶׁר־בּ֖וֹ ר֥וּחַ חַיִּֽים׃

They came to Noah, into the ark, two by two from all flesh in which was the breath of life.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.7.15

### Current best selected translation

고정WLC·사본 핵심자음·Swete에 둘씩과 생명의숨 및 노아에게/방주로. 분배·두 방향을 유지하고 한국어 육체는 6:17·19와 통일. 한국어 육체는 6:17·19와 통일하고 친족오해가 있는 초기 살붙이를 수정. 둘씩은 분배이지 총수를 한정하는 계산이 아님.

#### claude-sonnet-5-5

They went into the ark to Noah, two by two, of all flesh in which there was the breath of life.

Final opinion (Korean original): 현재 번역을 잠정안으로 둔다.

#### gemini-3.8-flash-medium

And they came to Noah into the ark, two by two of all flesh in which is the breath of life.

Final opinion (Korean original): 물질-영혼의 이분법적 선입견을 배제하고 기존 번역과의 통일성을 지닌 '육체' 표기와 두 방향 전치사를 온전히 살린 안을 잠정 채택 권고합니다.

#### gpt-6.1-sol

They came to Noah, into the ark, two by two from all flesh in which was the breath of life.

Final opinion (Korean original): 분배·두 방향을 유지하고 한국어 육체는 6:17·19와 통일. 육체는 물질몸으로 오해 가능. 여기서는 앞 열거된 살아있는 존재를 가리킴. 짝 총수·영혼론을 결정하지 않음. 해당 대안과 접근공백을 주석·근거기록으로 보존하는 잠정채택 권고. 인간전문가 검수 대기.

Counterargument (Korean): 살붙이는 한국어에서 친족으로 들릴수 있어 생물로 풀어쓸 대안이 있다. רוח는 바람/영 의미폭 있으나 생명숨은 문맥선택. 둘씩은 최종 총수를 고정하지 않는다. 육체는 물질몸으로 오해 가능. 여기서는 앞 열거된 살아있는 존재를 가리킴. 짝 총수·영혼론을 결정하지 않음.

## 16 · HYB.GEN.007.016

Hebrew display (MT/WLC): וְהַבָּאִ֗ים זָכָ֨ר וּנְקֵבָ֤ה מִכָּל־בָּשָׂר֙ בָּ֔אוּ כַּֽאֲשֶׁ֛ר צִוָּ֥ה אֹת֖וֹ אֱלֹהִ֑ים וַיִּסְגֹּ֥ר יְהוָ֖ה בַּֽעֲדֽוֹ׃

Those entering, male and female of all flesh, entered as God had commanded him; and YHWH shut him in.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.7.16

### Current best selected translation

히브리어 אלהים의 명령과 יהוה의 닫음 구별. Swete는 주본문에 여호와 하나님·방주·밖에서를 명시. 하나님/여호와 전환 유지. 노아를 안에 두고 닫으셨다로 닫힌 상태를 풀되 문/밖에서라는 미명시 목적어·위치 제외. 여호와가라는 신명표기는 기존서술문체를 유지. 노아는 남성단수대명사의 문맥상 지시대상이며 다른신명과 합치지 않음.

#### claude-sonnet-5-5

Those that entered, male and female of all flesh, went in as God had commanded him; and the LORD shut him in.

Final opinion (Korean original): 현재 번역을 잠정안으로 둔다.

#### gemini-3.8-flash-medium

And those that entered, male and female of all flesh entered, as God had commanded him; and YHWH closed it behind him.

Final opinion (Korean original): 신명 전환을 명확히 하고 외재적 목적어(문)의 본문 삽입을 배제하되, '안에 두고' 외에 '그의 뒤에서/그를 위하여'의 직역 가능성을 각주에 명시하는 것을 전제로 잠정 채택 권고합니다.

#### gpt-6.1-sol

Those entering, male and female of all flesh, entered as God had commanded him; and YHWH shut him in.

Final opinion (Korean original): 하나님/여호와 전환 유지. 노아를 안에 두고 닫으셨다로 닫힌 상태를 풀되 문/밖에서라는 미명시 목적어·위치 제외. בעדו는 뒤에서/그를위하여 등의 번역가능성이 있고 안에 두고는 문맥해석. 그리스어가 다른 저본인지 설명적 번역인지 확정 못함. 해당 대안과 접근공백을 주석·근거기록으로 보존하는 잠정채택 권고. 인간전문가 검수 대기.

Counterargument (Korean): בעדו는 뒤에서/위하여/그를두고의 공간·보호해석이 가능. 문이라는 목적어·밖에서라는 위치는 미명시라 보충하지 않는다. 닫으셨다는 목적어가 생략된 자연화이다. בעדו는 뒤에서/그를위하여 등의 번역가능성이 있고 안에 두고는 문맥해석. 그리스어가 다른 저본인지 설명적 번역인지 확정 못함.

## 17 · HYB.GEN.007.017

Hebrew display (MT/WLC): וַֽיְהִ֧י הַמַּבּ֛וּל אַרְבָּעִ֥ים י֖וֹם עַל־הָאָ֑רֶץ וַיִּרְבּ֣וּ הַמַּ֗יִם וַיִּשְׂאוּ֙ אֶת־הַתֵּבָ֔ה וַתָּ֖רָם מֵעַ֥ל הָאָֽרֶץ׃

The flood was on the earth for forty days. The waters increased and lifted the ark, and it rose above the earth.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.7.17

### Current best selected translation

고정WLC와 사진 핵심자음은 ארבעים יום. Swete11쪽 주본문에는 사십밤도 있음. 물증가·방주들림·상승 확인. WLC의 사십날 유지, 사십밤은 역본대안으로 공개. 높이의 과잉강조 제외.

#### claude-sonnet-5-5

The flood continued forty days on the earth. The waters increased and bore up the ark, and it rose high above the earth.

Final opinion (Korean original): 현재 번역을 잠정안으로 둔다.

#### gemini-3.8-flash-medium

And the flood was forty days upon the earth; and the waters increased, and bore up the ark, and it was lifted up above the earth.

Final opinion (Korean original): WLC의 '사십 일'을 본문으로 유지하되, 그리스어 역본의 '사십 밤' 추가 형태와 학술적 조화 논의를 투명하게 공개하는 조건으로 잠정 채택 권고합니다.

#### gpt-6.1-sol

The flood was on the earth for forty days. The waters increased and lifted the ark, and it rose above the earth.

Final opinion (Korean original): WLC의 사십날 유지, 사십밤은 역본대안으로 공개. 높이의 과잉강조 제외. 그리스어의 사십밤이 더 이른 읽기일 가능성을 배제 못함. 7:12와 조화적 확대라는 연구견해는 설득력있는 설명이나 전승기원 증명은 아님. 해당 대안과 접근공백을 주석·근거기록으로 보존하는 잠정채택 권고. 인간전문가 검수 대기.

Counterargument (Korean): 높이는 한국어 자연화이나 구체고도는 없음. 사십날은 전체홍수종료나 이후기간을 결정하지 않음. 이절 MT에 사십밤은 없어 보충하지 않는다. 그리스어의 사십밤이 더 이른 읽기일 가능성을 배제 못함. 7:12와 조화적 확대라는 연구견해는 설득력있는 설명이나 전승기원 증명은 아님.

## Notes

Verse 1 preserves I have seen, righteous, before me and this generation, while including the whole household. Verse 2 retains distributive seven by seven with a male and its mate. Seven pairs (fourteen animals) is a strong reading when the pair is distributed, but seven in total remains an alternative; the wording does not fix a total. Repeated sevens and male/female in the Greek edition do not settle the question. Cleanliness criteria, later sacrifice and harmonization with chapter 6 are not inserted.

Input is pinned WLC4.20/OSHB. Swete1901 p.10 is a modern scholarly edition of an ancient version. Leningrad4v was inspected for limited consonantal phrases only, not every vowel, accent or Masoretic note. Modern apparatus and full witness collation remain pending.

WLC verse 3 does not explicitly distinguish clean from unclean birds. The inspected Swete1901 edition does: clean birds by sevens, unclean birds by twos. Whether this longer Greek reflects another Hebrew Vorlage or harmonizing expansion remains unresolved. WLC remains provisional. Seven pairs is a strong reading, but a total of seven remains an alternative; distributive sevens are retained and seed is rendered as offspring.

Verse 4 distinguishes seven more days and forty days and forty nights. Every living thing interprets yequm contextually; everything that exists is a broader alternative. Verse 5 does not establish immediacy, inner motives or absolute sinlessness. Verse 6 retains age six hundred and floodwaters upon the earth. Swete main text lacks a water noun here; an addition appears in its apparatus, but its manuscript attribution is unverified. Because of in verse 7 has a fleeing-from alternative; no entry date, water level, headcount or geological extent is supplied.

For verses 3–7, Swete1901 pp.10–11 were directly read and limited consonantal phrases inspected in a Leningrad4v photograph. Full manuscripts, vowels, accents, Masoretic notes and modern apparatus or other Hebrew witnesses remain uncollated. Pinned WLC is an electronic transcription, not proof of the earliest wording or independent witness consensus.

Verses 8–9 retain the connected list and movement two by two. Swete1901 p.11 has a longer distinction between clean and unclean birds, absent in pinned WLC. Its Hebrew background and origin remain unresolved; WLC is retained provisionally. Two by two does not fix the total at two or harmonize it with sevens.

In verse 11 pinned WLC and the inspected consonantal wording of Leningrad4v have day seventeen of the second month. Swete1901 p.11 reads twenty-seven and lacks a main-text equivalent for great in great deep. These differences are preserved; without established grounds to replace the Hebrew input, seventeen and great deep remain provisional. This does not prove their priority. No calendar conversion, full flood duration or geological mechanism is added.

Verse 10 marks the seven days and the state of floodwaters; verse 12 describes rain for forty days and forty nights. A fixed intensity contrast between geshem and matar was not established, so rain is retained. Inspection was limited to Swete and consonantal phrases in Leningrad. Modern apparatus, other Hebrew witnesses including Samaritan texts and 4Q252, other ancient versions and specialist review remain pending.

Verses 13–15 preserve the family and animal lists, the four repetitions of according to kind, movement two by two and the breath of life. Kind is not a modern taxonomic species. In verse 14, they and every bird/every winged thing are in pinned Hebrew and the inspected Leningrad consonants, with no corresponding phrases in Swete1901 p.11. The longer Hebrew is retained provisionally; a different Vorlage or Greek abbreviation remains unresolved. In verse 13 Hebrew has with them and Swete with him; the source of the difference is unresolved. Entered in verse 14 is supplied from verse 13. Every wing is interpreted as every winged thing; every bird of every kind of wing is an alternative.

Verse 16 distinguishes God commanding from YHWH closing. Shut him in interprets beʿado in context; behind him or for him are alternatives. The Hebrew does not specify a door, the ark as object, or an outside position. Swete explicitly has Lord God, the ark and outside him. Whether this reflects another Hebrew text or explanatory translation remains unresolved.

In verse 17 pinned Hebrew and the inspected Leningrad consonants read forty days; Swete1901 p.11 reads forty days and forty nights. Rösel (1998) interprets this as harmonization with 7:12, which does not prove its origin. Hebrew without the added nights is retained provisionally, while the possibility of an earlier longer reading remains open. Rising waters and the ark rising are preserved; the end of the whole flood is not fixed. Modern apparatus, other Hebrew witnesses, full ancient-version collation and specialist review remain pending.

## Citation

Hansam Yang. Original Bible: Genesis 7:1–17 (en), research pilot v0.4.31. https://yangs777.github.io/hansam-bible/en/genesis-7/

Editorial material: CC BY 4.0 to the extent rights are held. Ancient WLC text: public domain. OSHB morphology: CC BY 4.0, Open Scriptures Hebrew Bible.

No human specialist approval is claimed.

Source transformation: OSHB separators removed; original vowel/accent codepoints preserved; punctuation spacing adapted.
