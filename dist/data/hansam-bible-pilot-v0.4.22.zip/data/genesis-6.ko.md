# 창세기 6장 1절

Hansam Yang · Original Bible · v0.4.22

AI 보조 번역 초안 · 원어·모국어 전문가 검수 전

이 판본은 연구 초안입니다. 자필원본의 발견이나 완전한 본문 복원을 주장하지 않습니다.

다음 절로 이어지는 시간절 한 절의 잠정 번역이다. 실제 독립 GPT·Gemini 및 기존 Claude 검토를 구분하며 인간 전문가 검수는 대기한다.

Basis: 고정 WLC/OSHB 잠정 선택. 독립 GPT·Gemini 제안과 실제 최종 의견·반론, 기존 Claude 초안 및6:1 난구 검토, 직접 읽은 Swete1901 인쇄9쪽을 구분한다. 최초 원문·전면 사본 대조·인간 전문가 검수 완료 아님.

Decision: Current best selected — revisable with stronger evidence

## 1 · HYB.GEN.006.001

Hebrew display (MT/WLC): וַֽיְהִי֙ כִּֽי־הֵחֵ֣ל הָֽאָדָ֔ם לָרֹ֖ב עַל־פְּנֵ֣י הָֽאֲדָמָ֑ה וּבָנ֖וֹת יֻלְּד֥וּ לָהֶֽם׃

사람들이 땅 위에서 늘어나기 시작하고 그들에게 딸들이 태어났을 때에,

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.1

### 현재 최선의 채택 번역

집합적 사람들과 복수 그들에게, 수동 출생을 보존한다. 독립 GPT초기의 때였다 종결을 철회하고 기존 Claude 난구와 실제 Gemini 의견을 수용해 다음 절로 이어지는 시간절을 세 언어 쉼표로 유지한다.

#### claude-sonnet-5-5

사람들이 땅 위에 번성하기 시작하고 그들에게 딸들이 태어났을 때,

Final opinion (Korean original): 유지한다.

#### claude-opus-5-5

사람들이 땅 위에 많아지기 시작하고 그들에게 딸들이 태어났을 때에,

Final opinion (Korean original): 저장된 독립 초기안과 preferred_wording은 다음 절로 이어지는 시간절을 유지한다. 현재 후보에 대한 새 승인 응답은 아니다.

#### gemini-3.8-flash-medium

사람이 땅 위에서 번성하기 시작하고 그들에게 딸들이 태어났을 때에,

Final opinion (Korean original): 'וַיְהִי כִּי' 구문은 6:2의 주절로 이어지는 전형적인 시간 종속절이므로, 독립 종결형(GPT 초안 '때였다.')을 지양하고 쉼표로 열어두는 것이 원문 통사론에 정확히 부합함. 편집자가 기록한 바와 같이 그리스어 역본(Swete)의 복수 표기 관측은 고대 번역 전통의 해석 증거이며, 히브리어 집합명사 'הָאָדָם'과 복수 대명사 'לָהֶם'의 호응을 한국어 '사람들이... 그들에게'로 살리고 쉼표로 종결한 selected 번역을 확정함.

#### gpt-6.1-sol

사람들이 땅 위에서 늘어나기 시작하고 그들에게 딸들이 태어났을 때였다.

Final opinion (Korean original): 집합적 사람들과 복수 그들에게, 수동 출생을 보존한다. 독립 GPT초기의 때였다 종결을 철회하고 기존 Claude 난구와 실제 Gemini 의견을 수용해 다음 절로 이어지는 시간절을 세 언어 쉼표로 유지한다. 한 절만 읽으면 문법적으로 미완결이다. 이는 뒤 절을 미리 번역해 보충하는 근거가 아니다. 땅을 지구 전체로 확대하거나 사람을 특정 계보·남성 집단으로 좁히지 않는다. 사람/땅의 원어 말놀이는 번역에서 온전히 재현되지 않는다.

Counterargument (Korean): 한 절만 읽으면 문법적으로 미완결이다. 이는 뒤 절을 미리 번역해 보충하는 근거가 아니다. 땅을 지구 전체로 확대하거나 사람을 특정 계보·남성 집단으로 좁히지 않는다. 사람/땅의 원어 말놀이는 번역에서 온전히 재현되지 않는다.

## Notes

1절은 다음 절로 이어지는 시간절이다. 현재 세 언어의 쉼표는 미완결 연결을 보존하며 아직 채택하지 않은 다음 절을 보충하지 않는다. 사람(아담)과 땅(아다마)의 소리 연결은 원어 주석 사항이다.

직접 입력은 고정 WLC/OSHB 전사다. 레닌그라드 4r 사진의 색인·열람과 모든 문자·모음·악센트 대조는 구별한다. Swete1901 인쇄 9쪽을 직접 읽었지만 이는 고대 사본 자체가 아니며 전체 비평장치 대조도 미완료다.

## Citation

Hansam Yang. Original Bible: Genesis 6:1 (ko), research pilot v0.4.22. https://yangs777.github.io/hansam-bible/ko/genesis-6/

Editorial material: CC BY 4.0 to the extent rights are held. Ancient WLC text: public domain. OSHB morphology: CC BY 4.0, Open Scriptures Hebrew Bible.

No human specialist approval is claimed.

Source transformation: OSHB separators removed; original vowel/accent codepoints preserved; punctuation spacing adapted.
