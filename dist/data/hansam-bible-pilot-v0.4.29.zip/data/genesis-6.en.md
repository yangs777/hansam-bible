# Genesis 6:1–22

Hansam Yang · Original Bible · v0.4.29

AI-assisted translation draft · specialist and native-language review pending

This is a research draft. It does not claim discovery of an autograph or a complete reconstruction of the earliest text.

Provisional WLC-based translations of verses 1–22 preserve independent proposals, final opinions, Greek edition differences and access gaps. Specialist review and full collation remain pending.

Basis: 고정 WLC/OSHB 잠정 선택. 독립 GPT·Gemini 제안과 실제 최종 의견·반론, 기존 Claude 초안 및6:1 난구 검토, 직접 읽은 Swete1901 인쇄9쪽을 구분한다. 최초 원문·전면 사본 대조·인간 전문가 검수 완료 아님.

Decision: Current best selected — revisable with stronger evidence

## 1 · HYB.GEN.006.001

Hebrew display (MT/WLC): וַֽיְהִי֙ כִּֽי־הֵחֵ֣ל הָֽאָדָ֔ם לָרֹ֖ב עַל־פְּנֵ֣י הָֽאֲדָמָ֑ה וּבָנ֖וֹת יֻלְּד֥וּ לָהֶֽם׃

When humankind began to multiply on the face of the ground and daughters were born to them,

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.1

### Current best selected translation

집합적 사람들과 복수 그들에게, 수동 출생을 보존한다. 독립 GPT초기의 때였다 종결을 철회하고 기존 Claude 난구와 실제 Gemini 의견을 수용해 다음 절로 이어지는 시간절을 세 언어 쉼표로 유지한다.

#### claude-sonnet-5-5

When people began to multiply on the face of the ground, and daughters were born to them,

Final opinion (Korean original): 유지한다.

#### claude-opus-5-5

When humankind began to multiply on the face of the ground, and daughters were born to them,

Final opinion (Korean original): 저장된 독립 초기안과 preferred_wording은 다음 절로 이어지는 시간절을 유지한다. 현재 후보에 대한 새 승인 응답은 아니다.

#### gemini-3.8-flash-medium

And it came to pass, when man began to multiply on the face of the ground and daughters were born to them,

Final opinion (Korean original): 'וַיְהִי כִּי' 구문은 6:2의 주절로 이어지는 전형적인 시간 종속절이므로, 독립 종결형(GPT 초안 '때였다.')을 지양하고 쉼표로 열어두는 것이 원문 통사론에 정확히 부합함. 편집자가 기록한 바와 같이 그리스어 역본(Swete)의 복수 표기 관측은 고대 번역 전통의 해석 증거이며, 히브리어 집합명사 'הָאָדָם'과 복수 대명사 'לָהֶם'의 호응을 한국어 '사람들이... 그들에게'로 살리고 쉼표로 종결한 selected 번역을 확정함.

#### gpt-6.1-sol

When humankind began to multiply on the face of the ground and daughters were born to them,

Final opinion (Korean original): 집합적 사람들과 복수 그들에게, 수동 출생을 보존한다. 독립 GPT초기의 때였다 종결을 철회하고 기존 Claude 난구와 실제 Gemini 의견을 수용해 다음 절로 이어지는 시간절을 세 언어 쉼표로 유지한다. 한 절만 읽으면 문법적으로 미완결이다. 이는 뒤 절을 미리 번역해 보충하는 근거가 아니다. 땅을 지구 전체로 확대하거나 사람을 특정 계보·남성 집단으로 좁히지 않는다. 사람/땅의 원어 말놀이는 번역에서 온전히 재현되지 않는다.

Counterargument (Korean): 한 절만 읽으면 문법적으로 미완결이다. 이는 뒤 절을 미리 번역해 보충하는 근거가 아니다. 땅을 지구 전체로 확대하거나 사람을 특정 계보·남성 집단으로 좁히지 않는다. 사람/땅의 원어 말놀이는 번역에서 온전히 재현되지 않는다.

Previous v0.4.22

When humankind began to multiply on the face of the ground and daughters were born to them,

Previous v0.4.23

When humankind began to multiply on the face of the ground and daughters were born to them,

Previous v0.4.24

When humankind began to multiply on the face of the ground and daughters were born to them,

Previous v0.4.25

When humankind began to multiply on the face of the ground and daughters were born to them,

Previous v0.4.26

When humankind began to multiply on the face of the ground and daughters were born to them,

Previous v0.4.27

When humankind began to multiply on the face of the ground and daughters were born to them,

Previous v0.4.28

When humankind began to multiply on the face of the ground and daughters were born to them,

## 2 · HYB.GEN.006.002

Hebrew display (MT/WLC): וַיִּרְא֤וּ בְנֵי־הָֽאֱלֹהִים֙ אֶת־בְּנ֣וֹת הָֽאָדָ֔ם כִּ֥י טֹבֹ֖ת הֵ֑נָּה וַיִּקְח֤וּ לָהֶם֙ נָשִׁ֔ים מִכֹּ֖ל אֲשֶׁ֥ר בָּחָֽרוּ׃

The sons of God saw that the daughters of humankind were beautiful, and they took wives for themselves from all whom they chose.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.2

### Current best selected translation

하나님의 아들들/사람의 딸들 및 고른 모든 이들 가운데서라는 범위를 보존한다.직접 읽은 Swete1901 인쇄9쪽의 천사들과 고정WLC 아들들을 구별하고 후자를 잠정 선택한다.집단 정체와 강제혼인 여부를 삽입하지 않는다.

#### claude-sonnet-5-5

the sons of God saw that the daughters of humans were fair, and they took wives for themselves, from all whom they chose.

Final opinion (Korean original): 직역하고 정체는 주석으로 돌린다.

#### claude-opus-5-5

the sons of God saw that the daughters of humankind were beautiful, and they took for themselves wives from all whom they chose.

Final opinion (Korean original): 과거 실제 난구 검토의 선호 번역: {"ko": "하나님의 아들들이 사람의 딸들을 보니 아름다웠다. 그들은 자기들이 고른 모든 여자를 아내로 맞아들였다.", "en": "the sons of God saw that the daughters of humankind were beautiful, and they took for themselves wives from all whom they chose.", "es": "los hijos de Dios vieron que las hijas de los seres humanos eran hermosas, y tomaron para sí mujeres de entre todas las que escogieron."} 현재 후보에 대한 새 승인 응답은 아니다.과거 신명 표기는 원기록 그대로 보존한다.

#### gemini-3.8-flash-medium

The sons of God saw that the daughters of humankind were beautiful, and they took for themselves wives from all whom they chose.

Final opinion (Korean original): 현재 후보는 'מִכֹּל אֲשֶׁר בָּחָרוּ'를 '자기들이 고른 모든 이들 가운데서'로 옮겨 전치사 מִן(부분/선택)과 כֹּל(전체)의 통사적 범위를 정확하게 살렸습니다. '하나님의 아들들'과 '사람의 딸들'의 정체를 천상 존재나 특정 혈통으로 닫아두지 않고 원문의 대칭 구조를 그대로 보존했으며, 평서체 서술 규칙을 유지하고 있으므로 수정 없이 채택합니다.

#### gpt-6.1-sol

The sons of God saw that the daughters of humankind were beautiful, and they took wives for themselves from all whom they chose.

Final opinion (Korean original): 하나님의 아들들/사람의 딸들 및 고른 모든 이들 가운데서라는 범위를 보존한다.직접 읽은 Swete1901 인쇄9쪽의 천사들과 고정WLC 아들들을 구별하고 후자를 잠정 선택한다.집단 정체와 강제혼인 여부를 삽입하지 않는다. 그리스어 천사들이 다른 초기 히브리어 전통을 보존할 수 있다.전치사와 결혼 관용구만으로 선택의 자의성·일부다처·폭력을 확정할 수 없으며 현대 비평장치·해당 사본 전면 대조는 미완료다.

Counterargument (Korean): 그리스어 천사들이 다른 초기 히브리어 전통을 보존할 수 있다.전치사와 결혼 관용구만으로 선택의 자의성·일부다처·폭력을 확정할 수 없으며 현대 비평장치·해당 사본 전면 대조는 미완료다.

Previous v0.4.23

The sons of God saw that the daughters of humankind were beautiful, and they took wives for themselves from all whom they chose.

Previous v0.4.24

The sons of God saw that the daughters of humankind were beautiful, and they took wives for themselves from all whom they chose.

Previous v0.4.25

The sons of God saw that the daughters of humankind were beautiful, and they took wives for themselves from all whom they chose.

Previous v0.4.26

The sons of God saw that the daughters of humankind were beautiful, and they took wives for themselves from all whom they chose.

Previous v0.4.27

The sons of God saw that the daughters of humankind were beautiful, and they took wives for themselves from all whom they chose.

Previous v0.4.28

The sons of God saw that the daughters of humankind were beautiful, and they took wives for themselves from all whom they chose.

## 3 · HYB.GEN.006.003

Hebrew display (MT/WLC): וַיֹּ֣אמֶר יְהוָ֗ה לֹֽא־יָד֨וֹן רוּחִ֤י בָֽאָדָם֙ לְעֹלָ֔ם בְּשַׁגַּ֖ם ה֣וּא בָשָׂ֑ר וְהָי֣וּ יָמָ֔יו מֵאָ֥ה וְעֶשְׂרִ֖ים שָׁנָֽה׃

YHWH said, “My spirit will not remain in humankind forever, because they too are flesh. Their days will be one hundred twenty years.”

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.3

### Current best selected translation

고정WLC 자음을 유지하며 초기 GPT의 다투다를 머물다로 수정했다.위치구·문맥 및 직접 읽은 Swete καταμείνῃ를 참고한 잠정 어휘 선택이다.그도 육체와120년의 날들을 보존하고 수명/유예를 확정하지 않는다.

#### claude-sonnet-5-5

Then the LORD said, "My spirit shall not abide in humans forever, for they are flesh; their days shall be one hundred twenty years."

Final opinion (Korean original): "머물지 않을 것이다"를 잠정 채택하고 대안을 주석에 병기한다.

#### claude-opus-5-5

YHWH said, “My spirit shall not remain in humankind forever, since they too are flesh; their days shall be one hundred and twenty years.”

Final opinion (Korean original): 과거 실제 난구 검토의 선호 번역: {"ko": "야훼가 말씀하셨다. “내 영이 사람 안에 영원히 머물지는 않을 것이다. 그도 육체이기 때문이다. 그의 날은 백이십 년이 될 것이다.”", "en": "YHWH said, “My spirit shall not remain in humankind forever, since they too are flesh; their days shall be one hundred and twenty years.”", "es": "YHWH dijo: «Mi espíritu no permanecerá para siempre en el ser humano, porque también él es carne; sus días serán ciento veinte años»."} 현재 후보에 대한 새 승인 응답은 아니다.과거 신명 표기는 원기록 그대로 보존한다.

#### gemini-3.8-flash-medium

YHWH said, "My spirit shall not abide in man forever, for he also is flesh; his days shall be one hundred and twenty years."

Final opinion (Korean original): 'יָד֨וֹן'에 대해 편집자가 인쇄면에서 관측한 고대 그리스어 독법(καταμείνῃ)과 문맥을 참조하여 '머물다'를 잠정 선택한 후보안의 태도를 지지합니다. 이는 확정된 어원 주장이 아닌 잠정 번역이며, '120년' 또한 본문의 '그의 날들'을 직역하여 개인 수명 단축과 심판 유예라는 양대 해석 가능성을 모두 열어두었습니다. 평서체 '말했다'를 준수하고 있으므로 그대로 채택합니다.

#### gpt-6.1-sol

YHWH said, “My spirit will not contend with humankind forever, because they too are flesh. Their days will be one hundred twenty years.”

Final opinion (Korean original): 고정WLC 자음을 유지하며 초기 GPT의 다투다를 머물다로 수정했다.위치구·문맥 및 직접 읽은 Swete καταμείνῃ를 참고한 잠정 어휘 선택이다.그도 육체와120년의 날들을 보존하고 수명/유예를 확정하지 않는다. ידון의 뜻은 불확실하며 다투다/판단하다 대안이 남는다.그리스어 해석에 의존하는 위험이 있다.다른 모음 분석·어원·고대 셈어 병행은 미검증이고 모델 합의는 어휘 확증이 아니다.

Counterargument (Korean): ידון의 뜻은 불확실하며 다투다/판단하다 대안이 남는다.그리스어 해석에 의존하는 위험이 있다.다른 모음 분석·어원·고대 셈어 병행은 미검증이고 모델 합의는 어휘 확증이 아니다.

Previous v0.4.23

YHWH said, “My spirit will not remain in humankind forever, because they too are flesh. Their days will be one hundred twenty years.”

Previous v0.4.24

YHWH said, “My spirit will not remain in humankind forever, because they too are flesh. Their days will be one hundred twenty years.”

Previous v0.4.25

YHWH said, “My spirit will not remain in humankind forever, because they too are flesh. Their days will be one hundred twenty years.”

Previous v0.4.26

YHWH said, “My spirit will not remain in humankind forever, because they too are flesh. Their days will be one hundred twenty years.”

Previous v0.4.27

YHWH said, “My spirit will not remain in humankind forever, because they too are flesh. Their days will be one hundred twenty years.”

Previous v0.4.28

YHWH said, “My spirit will not remain in humankind forever, because they too are flesh. Their days will be one hundred twenty years.”

## 4 · HYB.GEN.006.004

Hebrew display (MT/WLC): הַנְּפִלִ֞ים הָי֣וּ בָאָרֶץ֮ בַּיָּמִ֣ים הָהֵם֒ וְגַ֣ם אַֽחֲרֵי־כֵ֗ן אֲשֶׁ֨ר יָבֹ֜אוּ בְּנֵ֤י הָֽאֱלֹהִים֙ אֶל־בְּנ֣וֹת הָֽאָדָ֔ם וְיָלְד֖וּ לָהֶ֑ם הֵ֧מָּה הַגִּבֹּרִ֛ים אֲשֶׁ֥ר מֵעוֹלָ֖ם אַנְשֵׁ֥י הַשֵּֽׁם׃

The Nephilim were on the earth in those days, and also afterward, when the sons of God would go in to the daughters of humankind and they bore children to them. They were the mighty men of old, men of renown.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.4

### Current best selected translation

네피림을 음역하고 그 뒤에도·반복적 상황·딸들의 출생주어·옛 용사/명성을 보존한다.그들은의 선행사는 확정하지 않는다.초기 GPT 한국어의 모호한 주어를 명료화했고 실제 Gemini 최종 스페인어 Esos fueron을 수용했다.

#### claude-sonnet-5-5

The Nephilim were on the earth in those days—and also afterward—when the sons of God went in to the daughters of humans, and they bore children to them. These were the heroes that were of old, warriors of renown.

Final opinion (Korean original): 음역하고 정체는 주석 사항으로 둔다.

#### claude-opus-5-5

The Nephilim were on the earth in those days, and also afterward, when the sons of God would go in to the daughters of humankind and they bore children to them. These were the mighty men of old, the men of renown.

Final opinion (Korean original): 과거 실제 난구 검토의 선호 번역: {"ko": "그 시대에, 그리고 그 뒤에도, 땅에는 네피림이 있었다. 하나님의 아들들이 사람의 딸들과 동침하여 딸들이 그들에게 자식을 낳아 주던 때였다. 그들은 옛적의 용사들, 이름난 사람들이었다.", "en": "The Nephilim were on the earth in those days, and also afterward, when the sons of God would go in to the daughters of humankind and they bore children to them. These were the mighty men of old, the men of renown.", "es": "Los nefilim estaban en la tierra en aquellos días, y también después, cuando los hijos de Dios se unían a las hijas de los seres humanos y ellas les daban hijos. Esos fueron los héroes de antaño, los hombres de renombre."} 현재 후보에 대한 새 승인 응답은 아니다.과거 신명 표기는 원기록 그대로 보존한다.

#### gemini-3.8-flash-medium

The Nephilim were on the earth in those days, and also afterward, when the sons of God came in to the daughters of man and they bore children to them. These were the mighty men who were of old, the men of renown.

Final opinion (Korean original): 'וְיָלְדוּ לָהֶם'의 출생 동작 주어가 문맥상 여성들임을 파악하여 한국어에서 '딸들이 그들에게 자녀를 낳아 주곤 하던 때였다'로 명시함으로써 초기안의 주어 모호성을 말끔히 해소했습니다. 미완료 'יָבֹאוּ'의 지속적 양태를 살렸고, 네피림과 출생 자손을 동일시하지 않으면서 '그들은'(הֵמָּה)의 지시 대상을 본문 수준에서 열어두었으므로 현재 후보를 채택합니다.

#### gpt-6.1-sol

The Nephilim were on the earth in those days, and also afterward, when the sons of God went in to the daughters of humankind and they bore children to them. They were the mighty men of old, men of renown.

Final opinion (Korean original): 네피림을 음역하고 그 뒤에도·반복적 상황·딸들의 출생주어·옛 용사/명성을 보존한다.그들은의 선행사는 확정하지 않는다.초기 GPT 한국어의 모호한 주어를 명료화했고 실제 Gemini 최종 스페인어 Esos fueron을 수용했다. 동침은 들어가다의 완곡어를 명시화한 번역이다.자녀는 생략 목적어 보충이며 원문에 별도 자녀 명사는 없다.관계절 연결과 그들은의 선행사는 논쟁적이며 네피림/출생자녀 등식을 확정하지 않는다.그리스어 거인들을 WLC에 치환하지 않는다.

Counterargument (Korean): 동침은 들어가다의 완곡어를 명시화한 번역이다.자녀는 생략 목적어 보충이며 원문에 별도 자녀 명사는 없다.관계절 연결과 그들은의 선행사는 논쟁적이며 네피림/출생자녀 등식을 확정하지 않는다.그리스어 거인들을 WLC에 치환하지 않는다.

Previous v0.4.23

The Nephilim were on the earth in those days, and also afterward, when the sons of God would go in to the daughters of humankind and they bore children to them. They were the mighty men of old, men of renown.

Previous v0.4.24

The Nephilim were on the earth in those days, and also afterward, when the sons of God would go in to the daughters of humankind and they bore children to them. They were the mighty men of old, men of renown.

Previous v0.4.25

The Nephilim were on the earth in those days, and also afterward, when the sons of God would go in to the daughters of humankind and they bore children to them. They were the mighty men of old, men of renown.

Previous v0.4.26

The Nephilim were on the earth in those days, and also afterward, when the sons of God would go in to the daughters of humankind and they bore children to them. They were the mighty men of old, men of renown.

Previous v0.4.27

The Nephilim were on the earth in those days, and also afterward, when the sons of God would go in to the daughters of humankind and they bore children to them. They were the mighty men of old, men of renown.

Previous v0.4.28

The Nephilim were on the earth in those days, and also afterward, when the sons of God would go in to the daughters of humankind and they bore children to them. They were the mighty men of old, men of renown.

## 5 · HYB.GEN.006.005

Hebrew display (MT/WLC): וַיַּ֣רְא יְהוָ֔ה כִּ֥י רַבָּ֛ה רָעַ֥ת הָאָדָ֖ם בָּאָ֑רֶץ וְכָל־יֵ֨צֶר֙ מַחְשְׁבֹ֣ת לִבּ֔וֹ רַ֥ק רַ֖ע כָּל־הַיּֽוֹם׃

YHWH saw that the wickedness of humankind was great on the earth, and that everything the thoughts of their heart devised was only evil all the time.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.5

### Current best selected translation

마음의 생각이 빚어 내는 것과 모든/언제나/악할 뿐의 강도를 세 언어로 보존한다.고정WLC 명사구를 선택하고 직접 읽은 그리스어의 확장·통사 재구성을 역투사하지 않는다.

#### claude-sonnet-5-5

The LORD saw that the wickedness of humankind was great in the earth, and that every inclination of the thoughts of their hearts was only evil continually.

Final opinion (Korean original): "계획"을 잠정 채택하고 대안을 병기한다.

#### claude-opus-5-5

YHWH saw that the evil of humankind on the earth was great, and that everything the thoughts of their hearts devised was only evil continually.

Final opinion (Korean original): 과거 실제 난구 검토의 선호 번역: {"ko": "야훼는 땅에서 사람의 악이 크고, 그 마음의 생각이 빚어내는 모든 것이 언제나 오직 악할 뿐임을 보셨다.", "en": "YHWH saw that the evil of humankind on the earth was great, and that everything the thoughts of their hearts devised was only evil continually.", "es": "YHWH vio que la maldad del ser humano en la tierra era grande, y que todo lo que forjaban los pensamientos de su corazón era solamente malo todo el tiempo."} 현재 후보에 대한 새 승인 응답은 아니다.과거 신명 표기는 원기록 그대로 보존한다.

#### gemini-3.8-flash-medium

YHWH saw that the wickedness of man was great in the earth, and that every intention of the thoughts of his heart was only evil continually.

Final opinion (Korean original): 본문의 전칭 표현인 'כָּל־יֵצֶר'(모든 구상), 'רַק רַע'(오직 악함), 'כָּל־הַיּוֹם'(언제나)을 누락 없이 충실하게 반영했습니다. 'יֵצֶר'를 후대 랍비적 충동론으로 예단하지 않고 마음의 생각이 빚어내는 구상과 계획으로 옮겨 조형적 의미를 자연스럽게 살렸으며, 평서체 '보았다'를 지켰으므로 무수정 채택합니다.

#### gpt-6.1-sol

YHWH saw that the wickedness of humankind was great on the earth, and that every inclination of the thoughts of their heart was only evil all the time.

Final opinion (Korean original): 마음의 생각이 빚어 내는 것과 모든/언제나/악할 뿐의 강도를 세 언어로 보존한다.고정WLC 명사구를 선택하고 직접 읽은 그리스어의 확장·통사 재구성을 역투사하지 않는다. 산출물을 강조한 번역은 성향·지향이라는 대안보다 정적 의미를 약화할 수 있다.성향이 언제나 후대 교리를 뜻한다는 기존 모델의 단정도 채택하지 않는다.전칭 서술에서 후대의 인간론 교리를 자동 도출하지 않는다.

Counterargument (Korean): 산출물을 강조한 번역은 성향·지향이라는 대안보다 정적 의미를 약화할 수 있다.성향이 언제나 후대 교리를 뜻한다는 기존 모델의 단정도 채택하지 않는다.전칭 서술에서 후대의 인간론 교리를 자동 도출하지 않는다.

Previous v0.4.23

YHWH saw that the wickedness of humankind was great on the earth, and that everything the thoughts of their heart devised was only evil all the time.

Previous v0.4.24

YHWH saw that the wickedness of humankind was great on the earth, and that everything the thoughts of their heart devised was only evil all the time.

Previous v0.4.25

YHWH saw that the wickedness of humankind was great on the earth, and that everything the thoughts of their heart devised was only evil all the time.

Previous v0.4.26

YHWH saw that the wickedness of humankind was great on the earth, and that everything the thoughts of their heart devised was only evil all the time.

Previous v0.4.27

YHWH saw that the wickedness of humankind was great on the earth, and that everything the thoughts of their heart devised was only evil all the time.

Previous v0.4.28

YHWH saw that the wickedness of humankind was great on the earth, and that everything the thoughts of their heart devised was only evil all the time.

## 6 · HYB.GEN.006.006

Hebrew display (MT/WLC): וַיִּנָּ֣חֶם יְהוָ֔ה כִּֽי־עָשָׂ֥ה אֶת־הָֽאָדָ֖ם בָּאָ֑רֶץ וַיִּתְעַצֵּ֖ב אֶל־לִבּֽוֹ׃

YHWH regretted that he had made humankind on the earth, and he was grieved in his heart.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.6

### Current best selected translation

이미 사람을 만든 일에 대한 후회와 마음의 슬픔을 각각 옮긴다.직접 읽은 Swete의 생각·숙고 표현과 구별하여 고정WLC 정서 서술을 잠정 선택했다.신학적 불변성을 이유로 본문의 동사를 지우지 않는다.

#### claude-sonnet-5-5

And the LORD was sorry that he had made humankind on the earth, and it grieved him to his heart.

Final opinion (Korean original): 원문의 강도를 유지한다.

#### claude-opus-5-5

YHWH regretted that he had made humankind on the earth, and he was grieved to his heart.

Final opinion (Korean original): 과거 실제 난구 검토의 선호 번역: {"ko": "야훼는 땅 위에 사람을 만드신 것을 후회하시고, 마음 깊이 아파하셨다.", "en": "YHWH regretted that he had made humankind on the earth, and he was grieved to his heart.", "es": "A YHWH le pesó haber hecho al ser humano en la tierra, y sintió dolor en su corazón."} 현재 후보에 대한 새 승인 응답은 아니다.과거 신명 표기는 원기록 그대로 보존한다.

#### gemini-3.8-flash-medium

And YHWH regretted that he had made man on the earth, and it grieved him to his heart.

Final opinion (Korean original): 'וַיִּנָּחֶם'의 후회와 'וַיִּתְעַצֵּב אֶל־לִבּוֹ'의 마음의 슬픔을 신학적 완화나 작위적인 어원적 규정(위로를 구함 등) 없이 본문의 직관적 정서 서술 그대로 보존했습니다. 신적 불변성과의 교리적 조화를 위해 행위의 변경으로 환원하지 않고 성경 본문의 비통한 어조를 정직하게 반영하고 있으므로 그대로 채택합니다.

#### gpt-6.1-sol

YHWH regretted that he had made humankind on the earth, and he was grieved in his heart.

Final opinion (Korean original): 이미 사람을 만든 일에 대한 후회와 마음의 슬픔을 각각 옮긴다.직접 읽은 Swete의 생각·숙고 표현과 구별하여 고정WLC 정서 서술을 잠정 선택했다.신학적 불변성을 이유로 본문의 동사를 지우지 않는다. 그리스어가 다른 히브리어 전통을 보존할 가능성과 번역적 해석 가능성 모두 미해결이다.후회가 인간적 과오 인정과 동일하다는 교리적 결론도 내리지 않는다.형태만으로 깊은숨/위로를구함 어원을 단정하지 않는다.

Counterargument (Korean): 그리스어가 다른 히브리어 전통을 보존할 가능성과 번역적 해석 가능성 모두 미해결이다.후회가 인간적 과오 인정과 동일하다는 교리적 결론도 내리지 않는다.형태만으로 깊은숨/위로를구함 어원을 단정하지 않는다.

Previous v0.4.23

YHWH regretted that he had made humankind on the earth, and he was grieved in his heart.

Previous v0.4.24

YHWH regretted that he had made humankind on the earth, and he was grieved in his heart.

Previous v0.4.25

YHWH regretted that he had made humankind on the earth, and he was grieved in his heart.

Previous v0.4.26

YHWH regretted that he had made humankind on the earth, and he was grieved in his heart.

Previous v0.4.27

YHWH regretted that he had made humankind on the earth, and he was grieved in his heart.

Previous v0.4.28

YHWH regretted that he had made humankind on the earth, and he was grieved in his heart.

## 7 · HYB.GEN.006.007

Hebrew display (MT/WLC): וַיֹּ֣אמֶר יְהוָ֗ה אֶמְחֶ֨ה אֶת־הָאָדָ֤ם אֲשֶׁר־בָּרָ֨אתִי֙ מֵעַל֙ פְּנֵ֣י הָֽאֲדָמָ֔ה מֵֽאָדָם֙ עַד־בְּהֵמָ֔ה עַד־רֶ֖מֶשׂ וְעַד־ע֣וֹף הַשָּׁמָ֑יִם כִּ֥י נִחַ֖מְתִּי כִּ֥י עֲשִׂיתִֽם׃

YHWH said, “I will wipe from the face of the ground the human beings I created—from humans to beasts, to creeping things, and to the birds of the heavens—for I regret that I made them.”

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.7

### Current best selected translation

고정 WLC의 신명·창조하다/만들다·사람부터 동물들까지의 전체 목록과 복수 그들을 보존한다.초기 GPT의 한국어 목록 종결을 명료화하고 영어 the humankind를 자연스러운 human beings로 고쳤다.그리하겠다는 생략 동사 보충이며 별도 사건 추가가 아니다.נחמתי는 앞절과 과거 행위를 내용으로 하는 문맥상 후회하다로 잠정 선택한다.직접 읽은 Swete1901 인쇄9쪽의 신호칭·격분 표현과 구별하며 WLC를 교정하지 않는다.실제 Gemini 최종은 후보와 동일한 세언어 번역을 권고했다.

#### claude-sonnet-5-5

So the LORD said, "I will blot out from the earth the humans I have created—people together with animals and creeping things and birds of the air—for I am sorry that I have made them."

Final opinion (Korean original): 유지한다.

#### claude-opus-5-5

YHWH said, “I will wipe humankind, whom I created, from the face of the ground—from human to livestock, to creeping thing, and to the birds of the heavens—for I regret that I made them.”

Final opinion (Korean original): 과거 실제 선호 번역: {"ko": "야훼가 말씀하셨다. “내가 창조한 사람을 지면에서 지워 버리겠다. 사람으로부터 가축과 기는 것과 하늘의 새에 이르기까지 그리하겠다. 내가 그것들을 만든 것을 후회하기 때문이다.”", "en": "YHWH said, “I will wipe humankind, whom I created, from the face of the ground—from human to livestock, to creeping thing, and to the birds of the heavens—for I regret that I made them.”", "es": "YHWH dijo: «Borraré de la faz del suelo al ser humano que he creado: desde el ser humano hasta el ganado, hasta lo que se arrastra y hasta las aves de los cielos, porque me pesa haberlos hecho»."} 이번 후보에 대한 새 승인 응답 아님.과거 신명 표기는 원기록대로 보존.

#### gemini-3.8-flash-medium

And YHWH said, 'I will blot out man whom I have created from the face of the ground—from man to beast, to creeping thing, and to the bird of the heavens—for I regret that I have made them.'

Final opinion (Korean original): 1. 어휘 및 통사 검토:
 - ברא vs עשה: 본문은 '내가 창조한(בָּרָאתִי)' 사람과 '내가 그들을 만들었다(עֲשִׂיתִם)'로 두 동사를 구별합니다. 초기 분석에서 제시되었던 '무에서의 유(creatio ex nihilo)'나 '구체적 물질 조성/형상화'라는 신학적 범주 구분은 히브리어 형태론만으로는 도출되지 않으므로, 교리적 의미를 덧씌우지 않고 본문 그대로 '창조하다'와 '만들다'의 층위 차이만 직역 보존합니다.
 - אָדָם / אֲדָמָה: הָאָדָם은 집합적 단수 명사이며, הָאֲדָמָה는 일반적인 온 땅(אֶרֶץ)과 구별되는 '흙/경작지/지면(ground/soil)'을 뜻합니다. 한국어 후보의 '땅 위에서'는 '지면(흙의 표면)'의 함의를 다소 평이화했으나 문맥상 무난하며, 영어 'the face of the ground'와 스페인어 'la faz del suelo'가 이를 정확히 살리고 있습니다.
 - מחה: Qal 미완료 1인칭으로 서판이나 그릇을 씻어 지우듯 흔적을 없애는 행위이므로 '지워 버리겠다/wipe/borrar'가 매우 적절합니다.
 - 범위 목록의 비대칭 통사와 복수 접미사: אֶת־הָאָדָם이 직접목적어로 온 뒤, 별도의 동사 없이 전치사구(מֵאָדָם עַד־בְּהֵמָה עַד־רֶמֶשׂ וְעַד־עוֹף הַשָּׁמָיִם)로 이어지는 통사적 압축 구조입니다. 한국어 후보가 '...에 이르기까지 그리하겠다'로 조응 서술어를 보충한 것은 비대칭적 히브리어 구문의 의미를 한국어 통사에서 파탄 없이 전달하기 위한 허용 가능한 보충입니다. עֲשִׂיתִם의 3인칭 남성 복수 접미사(-ם)는 앞서 열거된 사람과 모든 동물 목록을 포괄적으로 받습니다. 생태계 연대책임이나 수중생물 제외 등은 주석적 추론이므로 본문 번역에 개입시키지 않습니다.
 - בְּהֵמָה: 길들인 '가축(livestock)'과 네 발 달린 '짐승(beasts)'의 의미를 공유하나, 뒤따르는 기는 것(רֶמֶשׂ) 및 새(עוֹף)와의 대조를 고려할 때 '짐승' 또는 '가축' 모두 방어 가능하며, 후보의 '짐승' 번역은 포괄적 동물군 지칭으로 타당합니다.
 - נחמתי: Niphal 완료 1인칭으로, 하나님을 주어로 한 직접 발화입니다. 이를 교리적 무오성을 위해 '사역적 의지 전환'이나 '언약적 슬픔' 등으로 완화·변증하지 않고, 본문 언어 그대로 '후회하기 때문이다(regret / lamento)'로 직시하여 번역합니다.

2. 저본 및 사본 관측 한계 명시:
 - 편집자가 직접 열람한 Swete 인쇄본 p.9 관측 결과, 칠십인역은 신명을 'ὁ θεός'로, 창조 동사를 'ὃν ἐποίησα'(ברא와 עשה 구별 없음)로, 목록을 두 쌍의 구조(ἀπὸ... ἕως / καὶ ἀπὸ... ἕως)로 나누었으며, 결정적으로 נִחַמְתִּי를 'ἐθυμώθην(내가 격분했다/노했다)'로 번역하여 히브리어의 슬픔/후회와 뚜렷한 정서적 차이를 보입니다.
 - 이는 단일 그리스어 인쇄판 관측일 뿐 고대 사본 및 비평장치 전면 대조가 아니므로 새 저본으로 삼지 않고, 고정 WLC를 잠정 저본으로 유지합니다.

3. 결론: 현재 후보는 신명 규칙(한국어 '여호와', 영/서 'YHWH'), 두 창조 동사의 구별, 비대칭 범위 목록의 적절한 처리, 후회 동사의 무완화 원칙을 고르게 충족하므로 채택(adopt)합니다.

#### gpt-6.1-sol

YHWH said, “I will wipe the humankind I created from the face of the ground—from humankind to beasts, creeping things, and the birds of the heavens—for I regret that I made them.”

Final opinion (Korean original): 고정 WLC의 신명·창조하다/만들다·사람부터 동물들까지의 전체 목록과 복수 그들을 보존한다.초기 GPT의 한국어 목록 종결을 명료화하고 영어 the humankind를 자연스러운 human beings로 고쳤다.그리하겠다는 생략 동사 보충이며 별도 사건 추가가 아니다.נחמתי는 앞절과 과거 행위를 내용으로 하는 문맥상 후회하다로 잠정 선택한다.직접 읽은 Swete1901 인쇄9쪽의 신호칭·격분 표현과 구별하며 WLC를 교정하지 않는다.실제 Gemini 최종은 후보와 동일한 세언어 번역을 권고했다. 반론: 짐승/가축,땅/지면,집합명사를 복수 인간들로 풀어쓴 영어 및 한국어 생략 동사 보충에는 대안이 남는다.그들을은 목록 전체를 받는 해석이 자연스럽지만 형태만으로 선행사 범위를 절대 확정하지 않는다.그리스어 격분 표현이 번역적 해석인지 다른 히브리어 전통인지 현재 근거로 결정할 수 없다.BHS/BHQ·괴팅겐장치와 관련 히브리어 사본·고대역본 직접 대조 및 인간 전문가 검수는 미완료다.

Counterargument (Korean): 짐승/가축,땅/지면,집합명사를 복수 인간들로 풀어쓴 영어 및 한국어 생략 동사 보충에는 대안이 남는다.그들을은 목록 전체를 받는 해석이 자연스럽지만 형태만으로 선행사 범위를 절대 확정하지 않는다.그리스어 격분 표현이 번역적 해석인지 다른 히브리어 전통인지 현재 근거로 결정할 수 없다.BHS/BHQ·괴팅겐장치와 관련 히브리어 사본·고대역본 직접 대조 및 인간 전문가 검수는 미완료다.

Previous v0.4.24

YHWH said, “I will wipe from the face of the ground the human beings I created—from humans to beasts, to creeping things, and to the birds of the heavens—for I regret that I made them.”

Previous v0.4.25

YHWH said, “I will wipe from the face of the ground the human beings I created—from humans to beasts, to creeping things, and to the birds of the heavens—for I regret that I made them.”

Previous v0.4.26

YHWH said, “I will wipe from the face of the ground the human beings I created—from humans to beasts, to creeping things, and to the birds of the heavens—for I regret that I made them.”

Previous v0.4.27

YHWH said, “I will wipe from the face of the ground the human beings I created—from humans to beasts, to creeping things, and to the birds of the heavens—for I regret that I made them.”

Previous v0.4.28

YHWH said, “I will wipe from the face of the ground the human beings I created—from humans to beasts, to creeping things, and to the birds of the heavens—for I regret that I made them.”

## 8 · HYB.GEN.006.008

Hebrew display (MT/WLC): וְנֹ֕חַ מָ֥צָא חֵ֖ן בְּעֵינֵ֥י יְהוָֽה׃

But Noah found favor in the eyes of YHWH.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.8

### Current best selected translation

고정WLC의 대조와 호의 관용구를 보존한다. 독립GPT의 눈에 호의를 얻었다 및 Gemini의 눈에서 은혜를 입었다는 한국어가 생경하여 여호와께 은혜를 입었다로 자연스럽게 옮긴다. 히브리어 눈에라는 신체 관용구는 주석·영어·스페인어에 남긴다. 은혜는 여기서 호의의 의미이며 공로·구원론의 원인을 삽입하지 않는다. Swete의 신호칭 확대는 별도 증거로 남기고 WLC 신명을 유지한다.

#### claude-sonnet-5-5

But Noah found favor in the sight of the LORD.

Final opinion (Korean original): 유지한다.

#### claude-opus-5-5

But Noah found favor in the eyes of YHWH.

Final opinion (Korean original): 당시 실제 선호안: {"ko": "그러나 노아는 야훼의 눈에 은혜를 입었다.", "en": "But Noah found favor in the eyes of YHWH.", "es": "Pero Noé halló gracia ante los ojos de YHWH."} 이번 후보에 대한 새 승인 아님.

#### gemini-3.8-flash-medium

But Noah found favor in the eyes of YHWH.

Final opinion (Korean original): 관용구 'מָצָא חֵן בְּעֵינֵי'를 한국어 독자에게 부자연스러운 '눈에 호의를 얻었다'로 과도하게 직역하기보다, 구약의 확립된 표현이자 상위자의 주권적 호의를 뜻하는 '여호와의 눈에서 은혜를 입었다'로 정리하는 것이 타당합니다. 신명은 프로젝트 규칙에 따라 한국어 '여호와', 영어/스페인어 'YHWH'를 엄격히 준수합니다. Swete 인쇄판에 기록된 칠십인역의 신호칭 확대(Κυρίου τοῦ θεοῦ)는 그리스어 번역 전통의 확장일 뿐이므로 히브리어 저본 수정 근거로 삼지 않습니다.

#### gpt-6.1-sol

But Noah found favor in the eyes of YHWH.

Final opinion (Korean original): 고정WLC의 대조와 호의 관용구를 보존한다. 독립GPT의 눈에 호의를 얻었다 및 Gemini의 눈에서 은혜를 입었다는 한국어가 생경하여 여호와께 은혜를 입었다로 자연스럽게 옮긴다. 히브리어 눈에라는 신체 관용구는 주석·영어·스페인어에 남긴다. 은혜는 여기서 호의의 의미이며 공로·구원론의 원인을 삽입하지 않는다. Swete의 신호칭 확대는 별도 증거로 남기고 WLC 신명을 유지한다. 반론: 눈에라는 히브리어 은유가 한국어 표면에서 생략되며 은혜에는 후대 신학적 연상이 있을 수 있다. 호의라는 대안과 직역을 주석에 남긴다. 그리스어 신호칭이 단순 확장인지 다른 저본인지는 직접 사본·장치 미검증 상태다.

Counterargument (Korean): 눈에라는 히브리어 은유가 한국어 표면에서 생략되며 은혜에는 후대 신학적 연상이 있을 수 있다. 호의라는 대안과 직역을 주석에 남긴다. 그리스어 신호칭이 단순 확장인지 다른 저본인지는 직접 사본·장치 미검증 상태다. 현대장치·관련사본·인간전문가 검수 미완료.

Previous v0.4.25

But Noah found favor in the eyes of YHWH.

Previous v0.4.26

But Noah found favor in the eyes of YHWH.

Previous v0.4.27

But Noah found favor in the eyes of YHWH.

Previous v0.4.28

But Noah found favor in the eyes of YHWH.

## 9 · HYB.GEN.006.009

Hebrew display (MT/WLC): אֵ֚לֶּה תּוֹלְדֹ֣ת נֹ֔חַ נֹ֗חַ אִ֥ישׁ צַדִּ֛יק תָּמִ֥ים הָיָ֖ה בְּדֹֽרֹתָ֑יו אֶת־הָֽאֱלֹהִ֖ים הִֽתְהַלֶּךְ־נֹֽחַ׃

This is the account of Noah. Noah was a righteous man, blameless among his generations. Noah walked with God.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.9

### Current best selected translation

תולדות는 후손 명단을 포함하는 이야기 도입이므로 내력/account/historia를 선택한다. 의로움과 흠없음, 복수 세대들, 하나님과 함께 걷는 삶의 은유를 보존한다. Gemini 최종의 복수 명시를 수용하되 한국어 기존 문체의 세 문장 구조는 유지한다. 그리스어 단수 세대·기쁘게 함으로 히브리어를 대체하지 않는다.

#### claude-sonnet-5-5

These are the descendants of Noah. Noah was a righteous man, blameless in his generation; Noah walked with God.

Final opinion (Korean original): "당대에"를 유지한다.

#### gemini-3.8-flash-medium

These are the generations of Noah. Noah was a righteous man, blameless in his generations; with God Noah walked.

Final opinion (Korean original): 'תּוֹלְדֹת'는 족보 명단을 넘어 인물의 행적과 사건을 포괄하므로 '내력'으로 유지합니다. 복수형 'בְּדֹרֹתָיו'는 Swete 칠십인역의 단수 번역(ἐν τῇ γενεᾷ αὐτοῦ)과 대조되는 마소라 본문의 고유 특징이므로 '그의 세대들 가운데'로 복수성을 보존합니다. 'תָּמִים'은 제의적·도덕적 성실성을 뜻하므로 '혈통적 순수성'이나 '절대적 무죄'로 비약하지 않고 '흠 없는'으로 번역합니다. 'הִתְהַלֶּךְ' 역시 칠십인역의 해석적 번역인 '기쁘게 했다(εὐηρέστησεν)'에 휩쓸리지 않고 히브리어의 삶의 동행 은유인 '걸었다'를 충실히 보존합니다.

#### gpt-6.1-sol

These are the generations of Noah. Noah was a righteous man, blameless among his generations. Noah walked with God.

Final opinion (Korean original): תולדות는 후손 명단을 포함하는 이야기 도입이므로 내력/account/historia를 선택한다. 의로움과 흠없음, 복수 세대들, 하나님과 함께 걷는 삶의 은유를 보존한다. Gemini 최종의 복수 명시를 수용하되 한국어 기존 문체의 세 문장 구조는 유지한다. 그리스어 단수 세대·기쁘게 함으로 히브리어를 대체하지 않는다. 반론: 여러 세대에 걸친 삶/동시대인 사이의 성실성과 상대적 평가/절대적 평가가 논쟁적이다. 흠없음을 절대무죄나 혈통 순수성으로 확정하지 않고 걷기를 실제 물리적 동행 사건으로 단정하지 않는다. 그리스어 해석의 배경은 미검증이다.

Counterargument (Korean): 여러 세대에 걸친 삶/동시대인 사이의 성실성과 상대적 평가/절대적 평가가 논쟁적이다. 흠없음을 절대무죄나 혈통 순수성으로 확정하지 않고 걷기를 실제 물리적 동행 사건으로 단정하지 않는다. 그리스어 해석의 배경은 미검증이다. 현대장치·관련사본·인간전문가 검수 미완료.

Previous v0.4.25

This is the account of Noah. Noah was a righteous man, blameless among his generations. Noah walked with God.

Previous v0.4.26

This is the account of Noah. Noah was a righteous man, blameless among his generations. Noah walked with God.

Previous v0.4.27

This is the account of Noah. Noah was a righteous man, blameless among his generations. Noah walked with God.

Previous v0.4.28

This is the account of Noah. Noah was a righteous man, blameless among his generations. Noah walked with God.

## 10 · HYB.GEN.006.010

Hebrew display (MT/WLC): וַיּ֥וֹלֶד נֹ֖חַ שְׁלֹשָׁ֣ה בָנִ֑ים אֶת־שֵׁ֖ם אֶת־חָ֥ם וְאֶת־יָֽפֶת׃

Noah fathered three sons: Shem, Ham, and Japheth.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.10

### Current best selected translation

히필 아버지됨과 세 아들의 수·목록 순서를 그대로 보존한다. 셈·함·야벳 표기는 이전판 문맥과 맞춘다. 실제Gemini최종도 후보를 유지하도록 권고했다.

#### claude-sonnet-5-5

And Noah had three sons: Shem, Ham, and Japheth.

Final opinion (Korean original): 현재 번역을 잠정 의견으로 유지한다.

#### gemini-3.8-flash-medium

And Noah fathered three sons: Shem, Ham, and Japheth.

Final opinion (Korean original): 히필 와우연속형 'וַיּוֹלֶד'와 수사 'שְׁלֹשָׁה בָנִים', 그리고 직접목적격 표지 'אֶת'으로 대등하게 연결된 세 아들의 이름 목록이 원문에 충실하게 번역되었습니다. 이 열거 순서를 출생 연령 순서나 동시 출생으로 교조화하지 않는 한, 기존 채택 후보안의 간결하고 정확한 한국어·영어·스페인어 문장을 그대로 유지하는 것이 최선입니다.

#### gpt-6.1-sol

Noah fathered three sons: Shem, Ham, and Japheth.

Final opinion (Korean original): 히필 아버지됨과 세 아들의 수·목록 순서를 그대로 보존한다. 셈·함·야벳 표기는 이전판 문맥과 맞춘다. 실제Gemini최종도 후보를 유지하도록 권고했다. 반론: 열거 순서가 출생 연령순인지, 모두 같은 해에 태어났는지는 이 절로 확정할 수 없다. 그리스어 장치의 개별 철자와 사본 귀속은 미검증이다.

Counterargument (Korean): 열거 순서가 출생 연령순인지, 모두 같은 해에 태어났는지는 이 절로 확정할 수 없다. 그리스어 장치의 개별 철자와 사본 귀속은 미검증이다. 현대장치·관련사본·인간전문가 검수 미완료.

Previous v0.4.25

Noah fathered three sons: Shem, Ham, and Japheth.

Previous v0.4.26

Noah fathered three sons: Shem, Ham, and Japheth.

Previous v0.4.27

Noah fathered three sons: Shem, Ham, and Japheth.

Previous v0.4.28

Noah fathered three sons: Shem, Ham, and Japheth.

## 11 · HYB.GEN.006.011

Hebrew display (MT/WLC): וַתִּשָּׁחֵ֥ת הָאָ֖רֶץ לִפְנֵ֣י הָֽאֱלֹהִ֑ים וַתִּמָּלֵ֥א הָאָ֖רֶץ חָמָֽס׃

The earth was corrupt before God, and the earth was filled with violence.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.11

### Current best selected translation

땅의 반복과 니팔 부패 상태, 가득함 및 חמס의 폭력을 보존한다. 불의·강포 대안을 남긴다. 앞에서라는 관계구를 하나님 법정이라는 별도 장면으로 확장하지 않으며 생태계 또는 지리 범위를 본문만으로 배제·확정하지 않는다.

#### claude-sonnet-5-5

Now the earth was corrupt in God's sight, and the earth was filled with violence.

Final opinion (Korean original): "부패"로 쓰고 13절과 말놀이를 주석으로 남긴다.

#### gemini-3.8-flash-medium

Now the earth was corrupt before God, and the earth was filled with violence.

Final opinion (Korean original): 니팔 'וַתִּשָּׁחֵת'(부패했다)와 'וַתִּמָּלֵא'(가득했다)의 수동적·상태적 묘사와 '땅(הָאָרֶץ)'의 2회 반복 배치를 명확히 살렸습니다. 'חָמָס'는 Swete 칠십인역의 포괄적 '불의(ἀδικία)'에 비해 더욱 노골적인 무법적 사회적 폭력을 의미하므로 '폭력'으로 유지하는 것이 원문의 심각성을 충실히 반영합니다. 생태계 자체가 아닌 부패한 인간 사회를 가리키는 문맥이 명료합니다.

#### gpt-6.1-sol

The earth was corrupt before God, and the earth was filled with violence.

Final opinion (Korean original): 땅의 반복과 니팔 부패 상태, 가득함 및 חמס의 폭력을 보존한다. 불의·강포 대안을 남긴다. 앞에서라는 관계구를 하나님 법정이라는 별도 장면으로 확장하지 않으며 생태계 또는 지리 범위를 본문만으로 배제·확정하지 않는다. 반론: 폭력은 물리적 폭행으로만 좁게 들릴 수 있고 חמס의 부정·강탈·불의 범위가 충분히 드러나지 않을 수 있다. 땅은 인간 사회의 환유 외에 더 넓은 파괴 상태를 포함할 가능성이 있다.

Counterargument (Korean): 폭력은 물리적 폭행으로만 좁게 들릴 수 있고 חמס의 부정·강탈·불의 범위가 충분히 드러나지 않을 수 있다. 땅은 인간 사회의 환유 외에 더 넓은 파괴 상태를 포함할 가능성이 있다. 현대장치·관련사본·인간전문가 검수 미완료.

Previous v0.4.25

The earth was corrupt before God, and the earth was filled with violence.

Previous v0.4.26

The earth was corrupt before God, and the earth was filled with violence.

Previous v0.4.27

The earth was corrupt before God, and the earth was filled with violence.

Previous v0.4.28

The earth was corrupt before God, and the earth was filled with violence.

## 12 · HYB.GEN.006.012

Hebrew display (MT/WLC): וַיַּ֧רְא אֱלֹהִ֛ים אֶת־הָאָ֖רֶץ וְהִנֵּ֣ה נִשְׁחָ֑תָה כִּֽי־הִשְׁחִ֧ית כָּל־בָּשָׂ֛ר אֶת־דַּרְכּ֖וֹ עַל־הָאָֽרֶץ׃

God saw the earth, and behold, it was corrupt, for all flesh had corrupted its way on the earth.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.12

### Current best selected translation

보시니/보라의 주의환기와 니팔 부패 상태·히필 부패 행위의 동일어근 대응, 모든 육체와 단수 자기 길을 유지한다. 한국어 부패하게 했다를 부패시켰다로 고치라는 실제Gemini최종 권고를 수용한다. 영어는 초기후보 on the earth를 유지하고 스페인어도 길 은유를 보존한다. 모든 육체의 범위는 본문에서 좁히지 않는다.

#### claude-sonnet-5-5

And God saw that the earth was corrupt; for all flesh had corrupted its ways upon the earth.

Final opinion (Korean original): 유지한다.

#### gemini-3.8-flash-medium

And God saw the earth, and behold, it was corrupt; for all flesh had corrupted its way upon the earth.

Final opinion (Korean original): 11절의 니팔 상태 서술에 이어 본 절의 'נִשְׁחָתָה'(니팔 완결, 부패해 있었다)와 'הִשְׁחִית'(히필 완결, 부패시켰다)의 능동적 언어유희 대비를 극대화해야 합니다. 초기 채택 후보의 '부패하게 했다'보다 '부패시켰다'가 히필의 직접적 파괴 행위를 생생하게 전달합니다. '자기 길(דַּרְכּוֹ)'은 단순한 행실로 의역하여 은유를 훼손하지 않되 한국어로 어색하지 않게 보존하며, '모든 육체'가 쓰였으나 '길을 부패시켰다'는 행위 서술은 도덕적 행위 주체성을 전제하므로 동물에게 도덕적 죄책을 억지로 부과하지 않도록 번역의 외연을 중립적으로 지킵니다.

#### gpt-6.1-sol

God saw the earth, and behold, it was corrupt, for all flesh had corrupted its way on the earth.

Final opinion (Korean original): 보시니/보라의 주의환기와 니팔 부패 상태·히필 부패 행위의 동일어근 대응, 모든 육체와 단수 자기 길을 유지한다. 한국어 부패하게 했다를 부패시켰다로 고치라는 실제Gemini최종 권고를 수용한다. 영어는 초기후보 on the earth를 유지하고 스페인어도 길 은유를 보존한다. 모든 육체의 범위는 본문에서 좁히지 않는다. 반론: 자기 길을 부패시켰다는 현대 한국어에서 낯설며 행실을 타락시켰다 대안이 있다. 모든 육체가 인간 중심인지 동물까지인지 미결이고 동물의 도덕적 죄책을 도출하지 않는다. 형태의 히필만으로 직접성·강도를 단정하지 않는다.

Counterargument (Korean): 자기 길을 부패시켰다는 현대 한국어에서 낯설며 행실을 타락시켰다 대안이 있다. 모든 육체가 인간 중심인지 동물까지인지 미결이고 동물의 도덕적 죄책을 도출하지 않는다. 형태의 히필만으로 직접성·강도를 단정하지 않는다. 현대장치·관련사본·인간전문가 검수 미완료.

Previous v0.4.25

God saw the earth, and behold, it was corrupt, for all flesh had corrupted its way on the earth.

Previous v0.4.26

God saw the earth, and behold, it was corrupt, for all flesh had corrupted its way on the earth.

Previous v0.4.27

God saw the earth, and behold, it was corrupt, for all flesh had corrupted its way on the earth.

Previous v0.4.28

God saw the earth, and behold, it was corrupt, for all flesh had corrupted its way on the earth.

## 13 · HYB.GEN.006.013

Hebrew display (MT/WLC): וַיֹּ֨אמֶר אֱלֹהִ֜ים לְנֹ֗חַ קֵ֤ץ כָּל־בָּשָׂר֙ בָּ֣א לְפָנַ֔י כִּֽי־מָלְאָ֥ה הָאָ֛רֶץ חָמָ֖ס מִפְּנֵיהֶ֑ם וְהִנְנִ֥י מַשְׁחִיתָ֖ם אֶת־הָאָֽרֶץ׃

God said to Noah, “The end of all flesh has come before me, for the earth is filled with violence because of them. Behold, I am about to destroy them with the earth.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.13

### Current best selected translation

모든 육체의 끝·내 앞·그들 때문에·폭력·보라를 유지한다. 마지막 את는 OSHB의 동반전치사 분석과 문맥에 따라 땅과 함께로 잠정 선택한다. Swete의 인간/그들 및 땅은 별도 고대번역 해석이며 같은히브리어 또는 다른저본 여부를 단정하지 않는다.13절에서 시작한 인용은 이후 담화로 이어져 닫지 않는다.

#### claude-sonnet-5-5

And God said to Noah, "The end of all flesh has come before me, for the earth is filled with violence because of them; now I am going to destroy them along with the earth.

Final opinion (Korean original): en을 "The end of all flesh has come before me"로 고친다.

#### gemini-3.8-flash-medium

God said to Noah, “The end of all flesh has come before me, for the earth is filled with violence because of them. And behold, I am destroying them with the earth.

Final opinion (Korean original): LXX 오귀속 주장을 공식 철회하고, 고정 WLC 본문의 동반 전치사 독해('땅과 함께')를 온전히 살린 후보안 번역을 잠정 채택 권고합니다.

#### gpt-6.1-sol

God said to Noah, “The end of all flesh has come before me, for the earth is filled with violence because of them. Behold, I am about to destroy them with the earth.

Final opinion (Korean original): 모든 육체의 끝·내 앞·그들 때문에·폭력·보라를 유지한다. 마지막 את는 OSHB의 동반전치사 분석과 문맥에 따라 땅과 함께로 잠정 선택한다. Swete의 인간/그들 및 땅은 별도 고대번역 해석이며 같은히브리어 또는 다른저본 여부를 단정하지 않는다.13절에서 시작한 인용은 이후 담화로 이어져 닫지 않는다. 반론: את를 목적격으로 읽은 그들 및 땅 또는 땅에서라는 대안이 있다. 모든육체의 범위를 인간만으로 좁히거나 지리적 전멸 방식까지 확정하지 않는다. Swete와 현대비평장치·사본 전면대조 미완료.

Counterargument (Korean): את를 목적격으로 읽은 그들 및 땅 또는 땅에서라는 대안이 있다. 모든육체의 범위를 인간만으로 좁히거나 지리적 전멸 방식까지 확정하지 않는다. Swete와 현대비평장치·사본 전면대조 미완료.

Previous v0.4.26

God said to Noah, “The end of all flesh has come before me, for the earth is filled with violence because of them. Behold, I am about to destroy them with the earth.

Previous v0.4.27

God said to Noah, “The end of all flesh has come before me, for the earth is filled with violence because of them. Behold, I am about to destroy them with the earth.

Previous v0.4.28

God said to Noah, “The end of all flesh has come before me, for the earth is filled with violence because of them. Behold, I am about to destroy them with the earth.

## 14 · HYB.GEN.006.014

Hebrew display (MT/WLC): עֲשֵׂ֤ה לְךָ֙ תֵּבַ֣ת עֲצֵי־גֹ֔פֶר קִנִּ֖ים תַּֽעֲשֶׂ֣ה אֶת־הַתֵּבָ֑ה וְכָֽפַרְתָּ֥ אֹתָ֛הּ מִבַּ֥יִת וּמִח֖וּץ בַּכֹּֽפֶר׃

Make yourself an ark of gopher wood. Make compartments in the ark, and coat it inside and out with pitch.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.14

### Current best selected translation

수종이 확정되지 않은 גפר를 고페르로 음역한다. קנים는 둥지의 구획 의미를 칸들로,כפר 동사·명사는 도포와 역청으로 옮긴다. Swete의 각진 목재를 수종 확정 근거로 바꾸지 않는다. 한국어 너는으로 명령대상을 드러내되 너를 위하여라는 수혜 표현은 영어·스페인어보다 덜 명시적이다.

#### claude-sonnet-5-5

Make yourself an ark of gopher wood; make rooms in the ark, and cover it inside and out with pitch.

Final opinion (Korean original): 음역한다.

#### gemini-3.8-flash-medium

Make for yourself an ark of gopher wood. You shall make rooms in the ark, and cover it inside and outside with pitch.

Final opinion (Korean original): 외래 어원이나 본문 교정 가설에 기대지 않고, 고페르 음역과 칸(격실), 역청 안팎 도포라는 마소라 텍스트의 직관적 직역을 취한 후보안을 잠정 채택 권고합니다.

#### gpt-6.1-sol

Make yourself an ark of gopher wood. Make compartments in the ark, and coat it inside and out with pitch.

Final opinion (Korean original): 수종이 확정되지 않은 גפר를 고페르로 음역한다. קנים는 둥지의 구획 의미를 칸들로,כפר 동사·명사는 도포와 역청으로 옮긴다. Swete의 각진 목재를 수종 확정 근거로 바꾸지 않는다. 한국어 너는으로 명령대상을 드러내되 너를 위하여라는 수혜 표현은 영어·스페인어보다 덜 명시적이다. 반론: 고페르가 나무 종류인지 가공재 지칭인지도 불확실하며 음역은 의미 설명을 미룬다. 둥지·칸 해석 외 갈대 가설과 그리스어의 각진목재를 구별한다. 모든방수재료를 현대화학성분으로 특정하지 않는다.

Counterargument (Korean): 고페르가 나무 종류인지 가공재 지칭인지도 불확실하며 음역은 의미 설명을 미룬다. 둥지·칸 해석 외 갈대 가설과 그리스어의 각진목재를 구별한다. 모든방수재료를 현대화학성분으로 특정하지 않는다.

Previous v0.4.26

Make yourself an ark of gopher wood. Make compartments in the ark, and coat it inside and out with pitch.

Previous v0.4.27

Make yourself an ark of gopher wood. Make compartments in the ark, and coat it inside and out with pitch.

Previous v0.4.28

Make yourself an ark of gopher wood. Make compartments in the ark, and coat it inside and out with pitch.

## 15 · HYB.GEN.006.015

Hebrew display (MT/WLC): וְזֶ֕ה אֲשֶׁ֥ר תַּֽעֲשֶׂ֖ה אֹתָ֑הּ שְׁלֹ֧שׁ מֵא֣וֹת אַמָּ֗ה אֹ֚רֶךְ הַתֵּבָ֔ה חֲמִשִּׁ֤ים אַמָּה֙ רָחְבָּ֔הּ וּשְׁלֹשִׁ֥ים אַמָּ֖ה קוֹמָתָֽהּ׃

This is how you shall make it: the length of the ark three hundred cubits, its width fifty cubits, and its height thirty cubits.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.15

### Current best selected translation

300·50·30과 장·폭·고,규빗 단위를 보존한다. 현대 길이를 확정 환산하지 않는다. 한국어는 일반적 표기 규빗을 사용하며 명사절을 명령문 문맥에 맞게 연결한다.

#### claude-sonnet-5-5

This is how you are to make it: the length of the ark three hundred cubits, its width fifty cubits, and its height thirty cubits.

Final opinion (Korean original): "암마"로 표기하고 환산은 주석에 둔다.

#### gemini-3.8-flash-medium

And this is how you shall make it: the length of the ark three hundred cubits, its breadth fifty cubits, and its height thirty cubits.

Final opinion (Korean original): 치수의 논리적 구조와 수량 나열을 왜곡 없이 간결하게 전달하므로 후보안을 잠정 채택 권고합니다.

#### gpt-6.1-sol

This is how you shall make it: the length of the ark three hundred cubits, its width fifty cubits, and its height thirty cubits.

Final opinion (Korean original): 300·50·30과 장·폭·고,규빗 단위를 보존한다. 현대 길이를 확정 환산하지 않는다. 한국어는 일반적 표기 규빗을 사용하며 명사절을 명령문 문맥에 맞게 연결한다. 반론: 규빗의 실제 길이·시대·측정관행과 건조 가능성은 이 수치만으로 확정할 수 없다. Swete하단 이문 약호와 사본귀속 미검증.

Counterargument (Korean): 규빗의 실제 길이·시대·측정관행과 건조 가능성은 이 수치만으로 확정할 수 없다. Swete하단 이문 약호와 사본귀속 미검증.

Previous v0.4.26

This is how you shall make it: the length of the ark three hundred cubits, its width fifty cubits, and its height thirty cubits.

Previous v0.4.27

This is how you shall make it: the length of the ark three hundred cubits, its width fifty cubits, and its height thirty cubits.

Previous v0.4.28

This is how you shall make it: the length of the ark three hundred cubits, its width fifty cubits, and its height thirty cubits.

## 16 · HYB.GEN.006.016

Hebrew display (MT/WLC): צֹ֣הַר ׀ תַּֽעֲשֶׂ֣ה לַתֵּבָ֗ה וְאֶל־אַמָּה֙ תְּכַלֶ֣נָּה מִלְמַ֔עְלָה וּפֶ֥תַח הַתֵּבָ֖ה בְּצִדָּ֣הּ תָּשִׂ֑ים תַּחְתִּיִּ֛ם שְׁנִיִּ֥ם וּשְׁלִשִׁ֖ים תַּֽעֲשֶֽׂהָ׃

Make a light opening for the ark, and finish it to a cubit at the top. Set the door of the ark in its side; make it with lower, second, and third decks.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.16

### Current best selected translation

Gemini 최종의견의 구체적 한국어·스페인어 수정안을 수용하여 위로부터/그것을을 드러낸다. 채광구는 잠정 선택이며 지붕 대안과 한규빗 구절의 지시대상 불확실성을 주석에서 공개한다. 확정된 창높이나 건축도를 제시하지 않는다.

#### gemini-3.8-flash-medium

You shall make a window for light for the ark, and finish it to a cubit from above; and set the door of the ark in its side; you shall make it with lower, second, and third decks.

Final opinion (Korean original): 후보안의 기본 방향은 유지하되, 통사적 목적격 접미사(-נָּה)와 '위로부터'(מִלְמַעְלָה)의 직역성을 높이기 위해 한국어 및 스페인어 번역을 정밀 수정할 것을 권고합니다.
* 수정 대체 문구:
- ko: "방주에 채광구를 만들되, 위로부터 한 규빗으로 그것을 마무리하여라. 방주의 문은 옆면에 내고, 아래층과 둘째 층과 셋째 층을 만들어라."
- es: "Haz una abertura de luz para el arca, y termínala a un codo desde arriba. Pon la puerta del arca en su costado; hazla con un piso inferior, un segundo y un tercero."

#### gpt-6.1-sol

Make a light opening for the ark, and finish it to a cubit at the top. Set the door of the ark in its side; make it with lower, second, and third decks.

Final opinion (Korean original): Gemini 최종의견의 구체적 한국어·스페인어 수정안을 수용하여 위로부터/그것을을 드러낸다. 채광구는 잠정 선택이며 지붕 대안과 한규빗 구절의 지시대상 불확실성을 주석에서 공개한다. 확정된 창높이나 건축도를 제시하지 않는다. 반론: 지붕 해석과 Swete의 상단을 모으는 제작표현은 채광구 선택에 대한 강한 반론이다. 1규빗이 높이·위쪽틈·지붕마감 중 무엇을 수식하는지,여성목적어가 방주/채광구 중 무엇인지 미결이다. BHS·괴팅겐 및 사본 직접대조 없이 도면확정 불가.

Counterargument (Korean): 지붕 해석과 Swete의 상단을 모으는 제작표현은 채광구 선택에 대한 강한 반론이다. 1규빗이 높이·위쪽틈·지붕마감 중 무엇을 수식하는지,여성목적어가 방주/채광구 중 무엇인지 미결이다. BHS·괴팅겐 및 사본 직접대조 없이 도면확정 불가.

Previous v0.4.26

Make a light opening for the ark, and finish it to a cubit at the top. Set the door of the ark in its side; make it with lower, second, and third decks.

Previous v0.4.27

Make a light opening for the ark, and finish it to a cubit at the top. Set the door of the ark in its side; make it with lower, second, and third decks.

Previous v0.4.28

Make a light opening for the ark, and finish it to a cubit at the top. Set the door of the ark in its side; make it with lower, second, and third decks.

## 17 · HYB.GEN.006.017

Hebrew display (MT/WLC): וַאֲנִ֗י הִנְנִי֩ מֵבִ֨יא אֶת־הַמַּבּ֥וּל מַ֨יִם֙ עַל־הָאָ֔רֶץ לְשַׁחֵ֣ת כָּל־בָּשָׂ֗ר אֲשֶׁר־בּוֹ֙ ר֣וּחַ חַיִּ֔ים מִתַּ֖חַת הַשָּׁמָ֑יִם כֹּ֥ל אֲשֶׁר־בָּאָ֖רֶץ יִגְוָֽע׃

Behold, I myself am bringing a flood of water upon the earth to destroy all flesh under heaven that has the breath of life in it. Everything on the earth shall perish.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.17

### Current best selected translation

ואני הנני의 강조,물의 홍수·생명의 숨·하늘 아래·모든 육체·땅에 있는 모든 것과 죽음을 보존한다. 물의 부연과 수식범위는 통사적 해석이며 미검증 삽입설·사본귀속·과도한 신학적 확장은 본문에 넣지 않는다.

#### gemini-3.8-flash-medium

And behold, I am bringing the floodwaters upon the earth to destroy all flesh in which is the breath of life from under heaven; everything that is on the earth shall expire.

Final opinion (Korean original): 미검증 삽입설이나 외부 사본 추정을 번역에 투영하지 않고, 고정 WLC의 '물의 홍수'와 '생명의 숨', '숨을 거두다'의 직역 구조를 균형 있게 구현한 후보안을 잠정 채택 권고합니다.

#### gpt-6.1-sol

Behold, I myself am bringing a flood of water upon the earth to destroy all flesh under heaven that has the breath of life in it. Everything on the earth shall perish.

Final opinion (Korean original): ואני הנני의 강조,물의 홍수·생명의 숨·하늘 아래·모든 육체·땅에 있는 모든 것과 죽음을 보존한다. 물의 부연과 수식범위는 통사적 해석이며 미검증 삽입설·사본귀속·과도한 신학적 확장은 본문에 넣지 않는다. 반론: 물의 동격부연·하늘 아래의 수식범위·땅의 지리범위 해석이 남는다. Swete 인쇄판에서 해당 문구를 읽었으나 히브리어사본·현대장치 전면대조나 최초원문 확정이 아니다.

Counterargument (Korean): 물의 동격부연·하늘 아래의 수식범위·땅의 지리범위 해석이 남는다. Swete 인쇄판에서 해당 문구를 읽었으나 히브리어사본·현대장치 전면대조나 최초원문 확정이 아니다.

Previous v0.4.26

Behold, I myself am bringing a flood of water upon the earth to destroy all flesh under heaven that has the breath of life in it. Everything on the earth shall perish.

Previous v0.4.27

Behold, I myself am bringing a flood of water upon the earth to destroy all flesh under heaven that has the breath of life in it. Everything on the earth shall perish.

Previous v0.4.28

Behold, I myself am bringing a flood of water upon the earth to destroy all flesh under heaven that has the breath of life in it. Everything on the earth shall perish.

## 18 · HYB.GEN.006.018

Hebrew display (MT/WLC): וַהֲקִמֹתִ֥י אֶת־בְּרִיתִ֖י אִתָּ֑ךְ וּבָאתָ֙ אֶל־הַתֵּבָ֔ה אַתָּ֕ה וּבָנֶ֛יךָ וְאִשְׁתְּךָ֥ וּנְשֵֽׁי־בָנֶ֖יךָ אִתָּֽךְ׃

But I will establish my covenant with you. You shall enter the ark, you and your sons and your wife and your sons’ wives with you.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.18

### Current best selected translation

언약을 세우다는 수립과 확립을 열어두는 번역이다.그리고/그러나 중 심판선언과의 대조를 택하되 갱신·창조언약을 추가하지 않는다.너와 가족의 열거 및 함께를 보존하고 한국어는 지시 기능을 옮긴다.אתך의2fs 태그와 남성노아 수신자를 구별한다.

#### claude-sonnet-5-5

But I will establish my covenant with you; and you shall come into the ark, you, your sons, your wife, and your sons' wives with you.

Final opinion (Korean original): "세우다"로 잠정 번역한다.

#### gemini-3.8-flash-medium

But I will establish my covenant with you, and you shall enter the ark—you, your sons, your wife, and your sons' wives with you.

Final opinion (Korean original): 원문 자음과 모음 부호를 인위적으로 교정하지 않고 고정 WLC를 보존하되, 번역상 '내 언약을 세우겠다'로 수립/확립의 다의성을 유지하고 가족 구성원의 질서 있는 입장 지시를 드러낸 candidate 번역(ko/en/es)을 잠정 채택 권고합니다. 이는 원문 확정이나 최종 배포판 채택이 아니며 전문가 정밀 대조를 위한 작업 후보입니다.

#### gpt-6.1-sol

But I will establish my covenant with you. You shall enter the ark, you and your sons and your wife and your sons’ wives with you.

Final opinion (Korean original): 언약을 세우다는 수립과 확립을 열어두는 번역이다.그리고/그러나 중 심판선언과의 대조를 택하되 갱신·창조언약을 추가하지 않는다.너와 가족의 열거 및 함께를 보존하고 한국어는 지시 기능을 옮긴다.אתך의2fs 태그와 남성노아 수신자를 구별한다. 반론: 세우다/확립하다와 입장예고/명령의 해석차이가 남는다.형태주석을 고치거나 특이모음의 역사적설명까지 직접 검증했다고 주장하지 않는다.히브리어사본·현대장치와 인간전문가 검수대기.

Counterargument (Korean): 세우다/확립하다와 입장예고/명령의 해석차이가 남는다.형태주석을 고치거나 특이모음의 역사적설명까지 직접 검증했다고 주장하지 않는다.히브리어사본·현대장치와 인간전문가 검수대기.

Previous v0.4.27

But I will establish my covenant with you. You shall enter the ark, you and your sons and your wife and your sons’ wives with you.

Previous v0.4.28

But I will establish my covenant with you. You shall enter the ark, you and your sons and your wife and your sons’ wives with you.

## 19 · HYB.GEN.006.019

Hebrew display (MT/WLC): וּמִכָּל־הָ֠חַי מִֽכָּל־בָּשָׂ֞ר שְׁנַ֧יִם מִכֹּ֛ל תָּבִ֥יא אֶל־הַתֵּבָ֖ה לְהַחֲיֹ֣ת אִתָּ֑ךְ זָכָ֥ר וּנְקֵבָ֖ה יִֽהְיֽוּ׃

From every living thing, from all flesh, you shall bring two of each into the ark to keep them alive with you; they shall be male and female.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.19

### Current best selected translation

살아있는모든것·모든육체의 반복,각각둘씩,방주반입,함께살게하는 목적,수컷암컷을 보존한다.스페인어 de cada uno로 현대종분류를 확정하지 않는다.그리스어확장 동물목록이나 후속장의수량을 삽입하지 않는다.

#### claude-sonnet-5-5

And of every living thing, of all flesh, you shall bring two of every kind into the ark, to keep them alive with you; they shall be male and female.

Final opinion (Korean original): "둘씩, 암수"를 유지한다.

#### gemini-3.8-flash-medium

And of every living thing of all flesh, two of every sort you shall bring into the ark to keep them alive with you; they shall be male and female.

Final opinion (Korean original): LXX의 확장 목록이나 후속 장(7장)과의 수량 조화, 현대 생물학적 종 구분을 원문에 무리하게 투영하지 않고, WLC의 두 포괄적 생명체 표현과 최소 생명 보존 지시를 정직하게 반영한 candidate 번역(ko/en/es)을 잠정 채택 권고합니다. 본 권고는 독자 열람용 잠정안일 뿐 공인 판본으로서의 확정이 아닙니다.

#### gpt-6.1-sol

From every living thing, from all flesh, you shall bring two of each into the ark to keep them alive with you; they shall be male and female.

Final opinion (Korean original): 살아있는모든것·모든육체의 반복,각각둘씩,방주반입,함께살게하는 목적,수컷암컷을 보존한다.스페인어 de cada uno로 현대종분류를 확정하지 않는다.그리스어확장 동물목록이나 후속장의수량을 삽입하지 않는다. 반론: 그리스어의 구체적범주확장과 먹여기르기 독법은 중요한비교자료다.그러나 다른히브리어저본을 자동역복원하지 않는다.모든의 담화범위와 생물분류는 미확정이며 짝의 생물학적의미를 넘어 번식목적을 본문에 보충하지 않는다.

Counterargument (Korean): 그리스어의 구체적범주확장과 먹여기르기 독법은 중요한비교자료다.그러나 다른히브리어저본을 자동역복원하지 않는다.모든의 담화범위와 생물분류는 미확정이며 짝의 생물학적의미를 넘어 번식목적을 본문에 보충하지 않는다.

Previous v0.4.27

From every living thing, from all flesh, you shall bring two of each into the ark to keep them alive with you; they shall be male and female.

Previous v0.4.28

From every living thing, from all flesh, you shall bring two of each into the ark to keep them alive with you; they shall be male and female.

## 20 · HYB.GEN.006.020

Hebrew display (MT/WLC): מֵהָע֣וֹף לְמִינֵ֗הוּ וּמִן־הַבְּהֵמָה֙ לְמִינָ֔הּ מִכֹּ֛ל רֶ֥מֶשׂ הָֽאֲדָמָ֖ה לְמִינֵ֑הוּ שְׁנַ֧יִם מִכֹּ֛ל יָבֹ֥אוּ אֵלֶ֖יךָ לְהַֽחֲיֽוֹת׃

From the birds according to their kinds, from the animals according to their kinds, and from every creeping thing of the ground according to its kind, two of each shall come to you to be kept alive.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.20

### Current best selected translation

세 동물 범주와 각기 반복되는 למין,동물들이 네게 온다는 주어·방향,생명보존 목적을 유지한다. בהמה는 가축으로만 제한하지 않는 짐승/animals/animales를 택한다.

#### claude-sonnet-5-5

Of the birds according to their kinds, and of the animals according to their kinds, and of every creeping thing of the ground according to its kind, two of each shall come in to you, to keep them alive.

Final opinion (Korean original): 유지한다.

#### gemini-3.8-flash-medium

Of the birds according to their kind, and of the beasts according to their kind, of every creeping thing of the ground according to its kind, two of every sort shall come to you to keep them alive.

Final opinion (Korean original): 주인님, 본 구절은 기적적 이동 기제나 자발적 의지 추론을 억지로 덧붙이지 않고 능동형 문면 그대로 '네게 와서'로 번역한 현 후보안을 잠정 채택 권고합니다. 고대 역본(Swete)의 암수 추가 등은 저본 교정이 아닌 해석적 명시화 가능성으로 주석에 유보합니다.

#### gpt-6.1-sol

From the birds according to their kinds, from the animals according to their kinds, and from every creeping thing of the ground according to its kind, two of each shall come to you to be kept alive.

Final opinion (Korean original): 세 동물 범주와 각기 반복되는 למין,동물들이 네게 온다는 주어·방향,생명보존 목적을 유지한다. בהמה는 가축으로만 제한하지 않는 짐승/animals/animales를 택한다. 반론: בהמה는 문맥상 가축 또는 큰 육상짐승으로 더 좁게 읽을 수도 있다. רמש는 파충류만이 아니며 기는 모든 것은 현대 동물분류와 일치하지 않는다. 영어·스페인어의 수동 생명보존은 히브리어 사역부정사의 목적어를 문맥에서 풀어쓴 것이다. 스페인어 especie는 현대 종 개념으로 오해될 수 있어 주석이 필요하다. 고정WLC와Swete차이를구별하고인간전문가검수대기.

Counterargument (Korean): בהמה는 문맥상 가축 또는 큰 육상짐승으로 더 좁게 읽을 수도 있다. רמש는 파충류만이 아니며 기는 모든 것은 현대 동물분류와 일치하지 않는다. 영어·스페인어의 수동 생명보존은 히브리어 사역부정사의 목적어를 문맥에서 풀어쓴 것이다. 스페인어 especie는 현대 종 개념으로 오해될 수 있어 주석이 필요하다.

Previous v0.4.28

From the birds according to their kinds, from the animals according to their kinds, and from every creeping thing of the ground according to its kind, two of each shall come to you to be kept alive.

## 21 · HYB.GEN.006.021

Hebrew display (MT/WLC): וְאַתָּ֣ה קַח־לְךָ֗ מִכָּל־מַֽאֲכָל֙ אֲשֶׁ֣ר יֵֽאָכֵ֔ל וְאָסַפְתָּ֖ אֵלֶ֑יךָ וְהָיָ֥ה לְךָ֛ וְלָהֶ֖ם לְאָכְלָֽה׃

As for you, take some of every kind of food that is eaten and gather it to yourself; it shall be food for you and for them.”

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.21

### Current best selected translation

ואתה의 화제 전환,קח 명령과 수혜적 לך,מכל의 부분적 취함,먹히는 음식이라는 관계절,수집과 사람·동물을 위한 음식이라는 결과를 보존한다.6:13에서 시작한 발화를 이 절 끝에서 닫는다.

#### claude-sonnet-5-5

And you, take for yourself some of every food that is eaten, and gather it to yourself; it shall be food for you and for them.

Final opinion (Korean original): 현재 번역을 잠정안으로 둔다.

#### gemini-3.8-flash-medium

And as for you, take for yourself of all food that is eaten, and gather it to you; and it shall be food for you and for them.”

Final opinion (Korean original): 식량 비축의 물리적 분량이나 기술적 저장성을 사변적으로 본문에 덧붙이지 않고, 원문의 부분성과 가식성 범주를 있는 그대로 옮긴 현 후보안을 잠정 채택 권고합니다. 6:21 끝의 인용 닫힘 구조도 확증되었습니다.

#### gpt-6.1-sol

As for you, take some of every kind of food that is eaten and gather it to yourself; it shall be food for you and for them.”

Final opinion (Korean original): ואתה의 화제 전환,קח 명령과 수혜적 לך,מכל의 부분적 취함,먹히는 음식이라는 관계절,수집과 사람·동물을 위한 음식이라는 결과를 보존한다.6:13에서 시작한 발화를 이 절 끝에서 닫는다. 반론: 모든 먹을것을 전량 가져가라는 뜻으로 오해하지 않도록 en some of/es de로 부분성을 드러낸다. 한국어 먹을 수 있는은 수동 관계절의 자연스러운 표현이나 가능성 해석이 보탠다. 동물 식성·채식 규범·보관 기술과 실제 양을 확정하지 않는다. 고정WLC와Swete차이를구별하고인간전문가검수대기.

Counterargument (Korean): 모든 먹을것을 전량 가져가라는 뜻으로 오해하지 않도록 en some of/es de로 부분성을 드러낸다. 한국어 먹을 수 있는은 수동 관계절의 자연스러운 표현이나 가능성 해석이 보탠다. 동물 식성·채식 규범·보관 기술과 실제 양을 확정하지 않는다.

Previous v0.4.28

As for you, take some of every kind of food that is eaten and gather it to yourself; it shall be food for you and for them.”

## 22 · HYB.GEN.006.022

Hebrew display (MT/WLC): וַיַּ֖עַשׂ נֹ֑חַ כְּ֠כֹל אֲשֶׁ֨ר צִוָּ֥ה אֹת֛וֹ אֱלֹהִ֖ים כֵּ֥ן עָשָֽׂה׃

Noah did this; according to all that God commanded him, so he did.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.22

### Current best selected translation

עשה 반복과 ככל의 전면성,명령의 주체 하나님과 수령자 노아를 보존한다. 설명적 순종 심리나 역사성 판단을 보충하지 않는다.

#### claude-sonnet-5-5

Noah did according to all that God had commanded him; so he did.

Final opinion (Korean original): 현재 번역을 잠정안으로 둔다.

#### gemini-3.8-flash-medium

Thus Noah did; according to all that God commanded him, so he did.

Final opinion (Korean original): Vqw 형태소 식별 오류를 배제하고 WLC의 'אֱלֹהִים'에 충실하게 '하나님'으로 표기하며, 서술문으로서 인용부호 없이 담백하게 대구 순종 구조를 살린 현 후보안을 잠정 채택 권고합니다.

#### gpt-6.1-sol

Noah did this; according to all that God commanded him, so he did.

Final opinion (Korean original): עשה 반복과 ככל의 전면성,명령의 주체 하나님과 수령자 노아를 보존한다. 설명적 순종 심리나 역사성 판단을 보충하지 않는다. 반론: 한국어의 그렇게/그대로와 영어 this는 생략된 목적어를 문맥으로 풀어쓴다. 스페인어 과거완료는 담화에서 앞선 명령을 나타내는 시제 선택이다. 실제 행위의 세부·시점을 확정하는 문장이 아니다. 고정WLC와Swete차이를구별하고인간전문가검수대기.

Counterargument (Korean): 한국어의 그렇게/그대로와 영어 this는 생략된 목적어를 문맥으로 풀어쓴다. 스페인어 과거완료는 담화에서 앞선 명령을 나타내는 시제 선택이다. 실제 행위의 세부·시점을 확정하는 문장이 아니다.

Previous v0.4.28

Noah did this; according to all that God commanded him, so he did.

## Notes

The temporal clause in verse 1 leads into verse 2. The identity of the sons of God and coercion in the marriages are not settled by the wording. Inspected Swete p.9 reads angels, distinguished from WLC sons.

Verse 3 provisionally uses remain for uncertain yadon; contend/judge remain alternatives. The 120 years are not fixed as lifespan or reprieve. Verse 4 transliterates Nephilim and leaves the referent of they open. Daughters are clarified as bearing children; children supplies an implicit object.

Verse 5 retains every, only evil and all the time without importing a later doctrine. Devising and inclination are translation alternatives. Verse 6 follows WLC regret and grief, distinguished from the inspected Greek wording of thought. Doctrinal resolutions are not inserted.

Input is pinned WLC/OSHB. Inspected Swete1901 p.9 is a printed edition. BHS/BHQ and Göttingen apparatus, Samaritan and relevant Dead Sea witnesses, other ancient versions and full Leningrad4r collation remain uninspected. Model agreement is not manuscript evidence.

Verse 7 preserves create/make, the list from humans to beasts, creeping things and birds, and the plural them. The Hebrew compresses the list; the Korean supplies an implicit verb. Beast/livestock remains a lexical alternative. WLC regret and the wording of anger in inspected Swete1901 p.9 are distinguished without reconstructing a different Hebrew text. Critical apparatus and manuscript collation remain incomplete.

Verse 8 uses an idiom of favor in the eyes of YHWH. Korean expresses the idiom naturally and explains the eye metaphor here. The order of narration alone does not settle doctrines of merit or grace. The expanded Greek divine designation is distinguished from WLC.

The account in verse 9 includes genealogy and narrative. The plural generations is retained; blameless does not establish absolute sinlessness or bloodline purity. Walking with God is a life metaphor. Inspected Swete uses a singular generation and pleasing God. Verse 10 does not establish simultaneous births or age order.

Verses 11–12 retain the repeated root for corruption in state and action. Violence may include injustice. All flesh and singular its way are retained; conduct is an interpretive gloss. The scope of flesh and earth remains open without assigning moral guilt to animals. Greek injustice and the expanded divine title remain separate evidence.

Verses 13–17 distinguish all flesh from human beings, with the earth from them and the earth, gopher wood from squared timber, and a light opening from a roof. The wood species is uncertain; compartments interpret the nest term. Cubits are retained without fixing a metric conversion or a construction plan. The quotation in verse 13 continues.

In verse 16 a light opening is provisional; roof is a significant alternative. The one-cubit clause and its referent are uncertain, so no exact window height, continuous upper gap, or roof angle is fixed. Swete describes gathering the ark upward, without establishing a different Hebrew text. The upstream comment on the verb form is preserved separately, without claiming independent verification of BHS or the manuscript.

Verses 18–19 retain establishing a covenant without deciding between a new commitment and confirmation, and distinguish predicted entry from instruction. The digital feminine tag is preserved separately; context addresses Noah. Swete lists more animal categories and uses feeding language in verse 19. This does not establish a different Hebrew source. WLC wording remains provisional. Two of each and male and female are retained without adding modern taxonomy, a breeding purpose or later numbers. Full manuscript, apparatus and Masoretic-note collation remains pending.

Verses 20–22 retain animal categories, kinds, preservation, food for both recipients and repeated action. Active arrival does not establish voluntary intent. The Greek edition adds male/female wording, uses feeding language and expands the divine designation in verse 22. WLC remains provisional; diet and storage quantities are not added. Limited Hebrew phrase inspection is distinguished from full collation.

## Citation

Hansam Yang. Original Bible: Genesis 6:1–22 (en), research pilot v0.4.29. https://yangs777.github.io/hansam-bible/en/genesis-6/

Editorial material: CC BY 4.0 to the extent rights are held. Ancient WLC text: public domain. OSHB morphology: CC BY 4.0, Open Scriptures Hebrew Bible.

No human specialist approval is claimed.

Source transformation: OSHB separators removed; original vowel/accent codepoints preserved; punctuation spacing adapted.
