# 신명기 32:8

Hansam Yang · Original Bible · v0.3.0

AI 보조 번역 초안 · 원어·모국어 전문가 검수 전

이 판본은 연구 초안입니다. 자필원본의 발견이나 완전한 본문 복원을 주장하지 않습니다.

현재 채택 번역은 ‘하나님의 아들들’ 독법입니다. 함께 보이는 완전한 히브리어는 MT 표시문이며 끝부분이 ‘이스라엘 자손들’로 다릅니다. 채택문 전체는 MT의 나머지 문장과 보고된 4Q37 이문구를 결합한 현대 편집 재구성입니다. 4Q37에 절 전체가 남았다는 뜻은 아닙니다.

Basis: MT remainder plus reported 4Q37 divine-sons phrase; editorial reconstruction

Decision: Current best: divine-sons reading; full translation is an editorial reconstruction, revisable

## 8 · HYB.DEUT.032.008

Hebrew display (MT/WLC): בְּהַנְחֵ֤ל עֶלְיוֹן֙ גּוֹיִ֔ם בְּהַפְרִיד֖וֹ בְּנֵ֣י אָדָ֑ם יַצֵּב֙ גְּבֻלֹ֣ת עַמִּ֔ים לְמִסְפַּ֖ר בְּנֵ֥י יִשְׂרָאֵֽל׃

지극히 높으신 이께서 민족들에게 기업을 나누어 주실 때, 인류를 갈라놓으실 때, 백성들의 경계를 하나님의 아들들의 수에 따라 정하셨다.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Deut.xml · Deut.32.8

### 현재 최선의 채택 번역

현재 채택은 신적 존재들 계열이다. 보고된 4Q37과 그리스어 전승의 대응 및 32:9의 몫 배분 문맥을 함께 고려한다. 절 전체는 MT 나머지 문장과 보고된 이문구를 결합한 현대 편집 재구성이다. Claude의 표현을 채택해 한국어 인류·수여 표현과 세 언어의 배분·경계 표현을 정돈했다. 모델들의 동의 자체는 사본 증거로 계산하지 않는다.

#### claude-opus-4-6-thinking

지극히 높으신 이께서 민족들에게 기업을 나누어 주실 때, 인류를 갈라놓으실 때, 백성들의 경계를 하나님의 아들들의 수에 따라 정하셨다.

Final opinion (Korean original): 제안된 선택(신적 아들들 계열)에 동의하되 유보를 둔다. 보고된 4Q37·그리스어 증거와 32:9 문맥의 수렴은 MT의 '이스라엘 자손들'보다 '하나님의 아들들'이 이른 독법일 개연성을 높인다. 그러나 세 가지 유보가 있다: (1) 4Q37 직접 대조가 미완이므로 보고된 독법의 확실성을 독립 검증하지 못했다, (2) 그리스어 내부에서 ἀγγέλων과 υἱῶν의 분기는 역본 Vorlage가 단일하지 않았을 가능성을 남긴다, (3) MT 전승은 독자적 가치가 있으며 '이스라엘 자손들'이 원래적일 논리적 가능성이 완전히 배제되지 않는다. 번역 문구는 전체적으로 양호하나, 한국어에서 소폭 조정을 제안한다.

#### gemini-3.8-flash-medium

[편집 재구성: MT 본문에 보고된 4Q37 이문 적용] 지존하신 분께서 민족들에게 유산을 나누어 주실 때, 아담의 자손들을 흩으실 때, 하나님의 아들들의 수효대로 뭇 백성의 경계들을 세우셨도다.

Final opinion (Korean original): 제시된 3개 언어 번역을 현시점의 '잠정적 최선안(revisable best choice)'으로 지지함. 다만 두 가지 본질적 유보 사항을 유지함: (1) 문헌비평적 유보: 실물 사본 사진의 직접 대조 없이 토브의 학술 보고에 의존한 '편집 재구성(MT 잔여부 + 보고된 4Q37 어구)'이며, MT의 '이스라엘 자손들'이 지닌 단단한 사본 전승사 및 70인 민족 모티프(창 10장, 출 1:5)의 강력한 반론을 결코 간과할 수 없음. (2) 문체적 유보: בְּנֵי אָדָם을 '인류'로 집합화하면서 후반부 בְּנֵי אֱלֹהִים(하나님의 아들들)과의 시적 대구(사람의 아들들 vs 신의 아들들)가 다소 약화된 점은 주석에서 명시해야 함.

#### gpt-6.1-sol

지극히 높으신 이께서 민족들에게 기업을 나누실 때, 사람들을 나누실 때, 백성들의 경계를 하나님의 아들들의 수에 따라 세우셨다.

Final opinion (Korean original): Claude의 세 언어 표현을 현재 채택한다. 인류를 갈라놓다·기업을 나누어 주다·경계를 정하다는 문맥에 맞고 전승 근거를 새로 주장하지 않는다. 하나님의 아들들 독법의 잠정 우선과 편집 재구성 표시는 유지한다. 직접 사본 대조가 없다는 유보와 MT 반론은 여전히 유효하다.

MT 표시문의 번역

지극히 높으신 이께서 민족들에게 기업을 나누실 때, 사람의 자손들을 나누실 때, 백성들의 경계를 이스라엘 자손들의 수에 따라 세우셨다.

Counterargument (Korean): MT의 이스라엘 자손들은 70인 전승과 연결될 수 있다. 직접 사본 대조를 완료하지 않았으므로 선택을 자필원본의 확정으로 부르지 않는다. בני אל을 직접 증거 없이 채택하지 않는다. 인류라는 집합적 표현은 사람의 아들들/하나님의 아들들의 어휘적 대구를 약화하므로 그 손실을 각 언어 주석에 남긴다.

Previous v0.1.0

지극히 높으신 이께서 민족들에게 기업을 나누실 때, 사람의 자손들을 나누실 때, 백성들의 경계를 이스라엘 자손들의 수에 따라 세우셨다.

Previous v0.2.0

지극히 높으신 이께서 민족들에게 기업을 나누어 주실 때, 인류를 갈라놓으실 때, 백성들의 경계를 하나님의 아들들의 수에 따라 정하셨다.

## Reported comparison reading — NOT a complete 4Q37 verse

בני אלוהים

하나님의 아들들

Reported in published scholarship; direct image verification pending

https://www.thetorah.com/article/the-sons-of-israel-or-god-deuteronomy-32-8

## Notes

Emanuel Tov의 2023년 비교는 MT·사마리아오경의 ‘이스라엘 자손들’과 4Q37의 ‘하나님의 아들들’을 구분합니다. 이는 해당 연구자의 증거 보고이며 이번 작업의 사본 사진 직접 판독 결과가 아닙니다.

고대 그리스어 전승에도 여러 표현이 있습니다. 번역문에서 단 하나의 히브리어 원형을 자동으로 역산할 수는 없습니다. 이문구 자체와 절 전체의 보존 여부도 구분해야 합니다.

현재는 보고된 4Q37·그리스어 전승과 32:9의 분배 문맥을 고려해 신적 존재들 계열을 채택합니다. MT의 이스라엘 자손들 독법과 70인 전승은 강한 반대 근거로 남깁니다. 직접 판독과 전승 대조가 선택을 바꿀 수 있습니다.

בני אדם은 문자적으로 사람의 아들들이며 여기서는 인류로 옮겼습니다. 뜻은 집합적으로 전달되지만 뒤의 하나님의 아들들과 이루는 어휘적 대구는 약해집니다. 원문의 시적 대구를 우선하는 번역은 사람의 자손들로 옮길 수 있습니다.

## Citation

Hansam Yang. Original Bible: Deuteronomy 32:8 (ko), research pilot v0.3.0. https://yangs777.github.io/hansam-bible/ko/deuteronomy-32-8/

Editorial material: CC BY 4.0 to the extent rights are held. Ancient WLC text: public domain. OSHB morphology: CC BY 4.0, Open Scriptures Hebrew Bible.

No human specialist approval is claimed.

Source transformation: OSHB separators removed; original vowel/accent codepoints preserved; punctuation spacing adapted.
