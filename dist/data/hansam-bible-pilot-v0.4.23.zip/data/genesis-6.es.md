# Génesis 6:1–6

Hansam Yang · Original Bible · v0.4.23

Borrador de traducción asistido por IA · pendiente de revisión especializada y nativa

Este es un borrador de investigación. No afirma haber descubierto un autógrafo ni reconstruido por completo el texto más antiguo.

Traducciones provisionales de los vv.1–6 basadas en WLC. Se conservan propuestas independientes, opiniones finales, diferencias griegas y límites de acceso. Revisión especializada y cotejo completo pendientes.

Basis: 고정 WLC/OSHB 잠정 선택. 독립 GPT·Gemini 제안과 실제 최종 의견·반론, 기존 Claude 초안 및6:1 난구 검토, 직접 읽은 Swete1901 인쇄9쪽을 구분한다. 최초 원문·전면 사본 대조·인간 전문가 검수 완료 아님.

Decision: Current best selected — revisable with stronger evidence

## 1 · HYB.GEN.006.001

Hebrew display (MT/WLC): וַֽיְהִי֙ כִּֽי־הֵחֵ֣ל הָֽאָדָ֔ם לָרֹ֖ב עַל־פְּנֵ֣י הָֽאֲדָמָ֑ה וּבָנ֖וֹת יֻלְּד֥וּ לָהֶֽם׃

Cuando la humanidad comenzó a multiplicarse sobre la faz de la tierra y les nacieron hijas,

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.1

### Traducción seleccionada: mejor opción actual

집합적 사람들과 복수 그들에게, 수동 출생을 보존한다. 독립 GPT초기의 때였다 종결을 철회하고 기존 Claude 난구와 실제 Gemini 의견을 수용해 다음 절로 이어지는 시간절을 세 언어 쉼표로 유지한다.

#### claude-sonnet-5-5

Cuando los hombres comenzaron a multiplicarse sobre la faz de la tierra y les nacieron hijas,

Final opinion (Korean original): 유지한다.

#### claude-opus-5-5

Cuando los seres humanos comenzaron a multiplicarse sobre la faz de la tierra y les nacieron hijas,

Final opinion (Korean original): 저장된 독립 초기안과 preferred_wording은 다음 절로 이어지는 시간절을 유지한다. 현재 후보에 대한 새 승인 응답은 아니다.

#### gemini-3.8-flash-medium

Y aconteció que cuando los hombres comenzaron a multiplicarse sobre la faz de la tierra, y les nacieron hijas,

Final opinion (Korean original): 'וַיְהִי כִּי' 구문은 6:2의 주절로 이어지는 전형적인 시간 종속절이므로, 독립 종결형(GPT 초안 '때였다.')을 지양하고 쉼표로 열어두는 것이 원문 통사론에 정확히 부합함. 편집자가 기록한 바와 같이 그리스어 역본(Swete)의 복수 표기 관측은 고대 번역 전통의 해석 증거이며, 히브리어 집합명사 'הָאָדָם'과 복수 대명사 'לָהֶם'의 호응을 한국어 '사람들이... 그들에게'로 살리고 쉼표로 종결한 selected 번역을 확정함.

#### gpt-6.1-sol

Cuando la humanidad comenzó a multiplicarse sobre la faz de la tierra y les nacieron hijas,

Final opinion (Korean original): 집합적 사람들과 복수 그들에게, 수동 출생을 보존한다. 독립 GPT초기의 때였다 종결을 철회하고 기존 Claude 난구와 실제 Gemini 의견을 수용해 다음 절로 이어지는 시간절을 세 언어 쉼표로 유지한다. 한 절만 읽으면 문법적으로 미완결이다. 이는 뒤 절을 미리 번역해 보충하는 근거가 아니다. 땅을 지구 전체로 확대하거나 사람을 특정 계보·남성 집단으로 좁히지 않는다. 사람/땅의 원어 말놀이는 번역에서 온전히 재현되지 않는다.

Counterargument (Korean): 한 절만 읽으면 문법적으로 미완결이다. 이는 뒤 절을 미리 번역해 보충하는 근거가 아니다. 땅을 지구 전체로 확대하거나 사람을 특정 계보·남성 집단으로 좁히지 않는다. 사람/땅의 원어 말놀이는 번역에서 온전히 재현되지 않는다.

Previous v0.4.22

Cuando la humanidad comenzó a multiplicarse sobre la faz de la tierra y les nacieron hijas,

## 2 · HYB.GEN.006.002

Hebrew display (MT/WLC): וַיִּרְא֤וּ בְנֵי־הָֽאֱלֹהִים֙ אֶת־בְּנ֣וֹת הָֽאָדָ֔ם כִּ֥י טֹבֹ֖ת הֵ֑נָּה וַיִּקְח֤וּ לָהֶם֙ נָשִׁ֔ים מִכֹּ֖ל אֲשֶׁ֥ר בָּחָֽרוּ׃

Los hijos de Dios vieron que las hijas de la humanidad eran hermosas y tomaron para sí esposas de entre todas las que escogieron.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.2

### Traducción seleccionada: mejor opción actual

하나님의 아들들/사람의 딸들 및 고른 모든 이들 가운데서라는 범위를 보존한다.직접 읽은 Swete1901 인쇄9쪽의 천사들과 고정WLC 아들들을 구별하고 후자를 잠정 선택한다.집단 정체와 강제혼인 여부를 삽입하지 않는다.

#### claude-sonnet-5-5

los hijos de Dios vieron que las hijas de los hombres eran hermosas, y tomaron para sí mujeres de entre todas las que escogieron.

Final opinion (Korean original): 직역하고 정체는 주석으로 돌린다.

#### claude-opus-5-5

los hijos de Dios vieron que las hijas de los seres humanos eran hermosas, y tomaron para sí mujeres de entre todas las que escogieron.

Final opinion (Korean original): 과거 실제 난구 검토의 선호 번역: {"ko": "하나님의 아들들이 사람의 딸들을 보니 아름다웠다. 그들은 자기들이 고른 모든 여자를 아내로 맞아들였다.", "en": "the sons of God saw that the daughters of humankind were beautiful, and they took for themselves wives from all whom they chose.", "es": "los hijos de Dios vieron que las hijas de los seres humanos eran hermosas, y tomaron para sí mujeres de entre todas las que escogieron."} 현재 후보에 대한 새 승인 응답은 아니다.과거 신명 표기는 원기록 그대로 보존한다.

#### gemini-3.8-flash-medium

Los hijos de Dios vieron que las hijas de los hombres eran hermosas, y tomaron para sí mujeres de todas las que eligieron.

Final opinion (Korean original): 현재 후보는 'מִכֹּל אֲשֶׁר בָּחָרוּ'를 '자기들이 고른 모든 이들 가운데서'로 옮겨 전치사 מִן(부분/선택)과 כֹּל(전체)의 통사적 범위를 정확하게 살렸습니다. '하나님의 아들들'과 '사람의 딸들'의 정체를 천상 존재나 특정 혈통으로 닫아두지 않고 원문의 대칭 구조를 그대로 보존했으며, 평서체 서술 규칙을 유지하고 있으므로 수정 없이 채택합니다.

#### gpt-6.1-sol

Los hijos de Dios vieron que las hijas de la humanidad eran hermosas y tomaron para sí esposas de entre todas las que escogieron.

Final opinion (Korean original): 하나님의 아들들/사람의 딸들 및 고른 모든 이들 가운데서라는 범위를 보존한다.직접 읽은 Swete1901 인쇄9쪽의 천사들과 고정WLC 아들들을 구별하고 후자를 잠정 선택한다.집단 정체와 강제혼인 여부를 삽입하지 않는다. 그리스어 천사들이 다른 초기 히브리어 전통을 보존할 수 있다.전치사와 결혼 관용구만으로 선택의 자의성·일부다처·폭력을 확정할 수 없으며 현대 비평장치·해당 사본 전면 대조는 미완료다.

Counterargument (Korean): 그리스어 천사들이 다른 초기 히브리어 전통을 보존할 수 있다.전치사와 결혼 관용구만으로 선택의 자의성·일부다처·폭력을 확정할 수 없으며 현대 비평장치·해당 사본 전면 대조는 미완료다.

## 3 · HYB.GEN.006.003

Hebrew display (MT/WLC): וַיֹּ֣אמֶר יְהוָ֗ה לֹֽא־יָד֨וֹן רוּחִ֤י בָֽאָדָם֙ לְעֹלָ֔ם בְּשַׁגַּ֖ם ה֣וּא בָשָׂ֑ר וְהָי֣וּ יָמָ֔יו מֵאָ֥ה וְעֶשְׂרִ֖ים שָׁנָֽה׃

YHWH dijo: «Mi espíritu no permanecerá en la humanidad para siempre, porque también es carne. Sus días serán ciento veinte años».

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.3

### Traducción seleccionada: mejor opción actual

고정WLC 자음을 유지하며 초기 GPT의 다투다를 머물다로 수정했다.위치구·문맥 및 직접 읽은 Swete καταμείνῃ를 참고한 잠정 어휘 선택이다.그도 육체와120년의 날들을 보존하고 수명/유예를 확정하지 않는다.

#### claude-sonnet-5-5

Entonces el SEÑOR dijo: «No permanecerá para siempre mi espíritu en el hombre, porque también él es carne; sus días serán ciento veinte años».

Final opinion (Korean original): "머물지 않을 것이다"를 잠정 채택하고 대안을 주석에 병기한다.

#### claude-opus-5-5

YHWH dijo: «Mi espíritu no permanecerá para siempre en el ser humano, porque también él es carne; sus días serán ciento veinte años».

Final opinion (Korean original): 과거 실제 난구 검토의 선호 번역: {"ko": "야훼가 말씀하셨다. “내 영이 사람 안에 영원히 머물지는 않을 것이다. 그도 육체이기 때문이다. 그의 날은 백이십 년이 될 것이다.”", "en": "YHWH said, “My spirit shall not remain in humankind forever, since they too are flesh; their days shall be one hundred and twenty years.”", "es": "YHWH dijo: «Mi espíritu no permanecerá para siempre en el ser humano, porque también él es carne; sus días serán ciento veinte años»."} 현재 후보에 대한 새 승인 응답은 아니다.과거 신명 표기는 원기록 그대로 보존한다.

#### gemini-3.8-flash-medium

YHWH dijo: "No contenderá mi espíritu con el hombre para siempre, porque ciertamente él es carne; y serán sus días ciento veinte años."

Final opinion (Korean original): 'יָד֨וֹן'에 대해 편집자가 인쇄면에서 관측한 고대 그리스어 독법(καταμείνῃ)과 문맥을 참조하여 '머물다'를 잠정 선택한 후보안의 태도를 지지합니다. 이는 확정된 어원 주장이 아닌 잠정 번역이며, '120년' 또한 본문의 '그의 날들'을 직역하여 개인 수명 단축과 심판 유예라는 양대 해석 가능성을 모두 열어두었습니다. 평서체 '말했다'를 준수하고 있으므로 그대로 채택합니다.

#### gpt-6.1-sol

YHWH dijo: «Mi espíritu no contenderá con la humanidad para siempre, porque también es carne. Sus días serán ciento veinte años».

Final opinion (Korean original): 고정WLC 자음을 유지하며 초기 GPT의 다투다를 머물다로 수정했다.위치구·문맥 및 직접 읽은 Swete καταμείνῃ를 참고한 잠정 어휘 선택이다.그도 육체와120년의 날들을 보존하고 수명/유예를 확정하지 않는다. ידון의 뜻은 불확실하며 다투다/판단하다 대안이 남는다.그리스어 해석에 의존하는 위험이 있다.다른 모음 분석·어원·고대 셈어 병행은 미검증이고 모델 합의는 어휘 확증이 아니다.

Counterargument (Korean): ידון의 뜻은 불확실하며 다투다/판단하다 대안이 남는다.그리스어 해석에 의존하는 위험이 있다.다른 모음 분석·어원·고대 셈어 병행은 미검증이고 모델 합의는 어휘 확증이 아니다.

## 4 · HYB.GEN.006.004

Hebrew display (MT/WLC): הַנְּפִלִ֞ים הָי֣וּ בָאָרֶץ֮ בַּיָּמִ֣ים הָהֵם֒ וְגַ֣ם אַֽחֲרֵי־כֵ֗ן אֲשֶׁ֨ר יָבֹ֜אוּ בְּנֵ֤י הָֽאֱלֹהִים֙ אֶל־בְּנ֣וֹת הָֽאָדָ֔ם וְיָלְד֖וּ לָהֶ֑ם הֵ֧מָּה הַגִּבֹּרִ֛ים אֲשֶׁ֥ר מֵעוֹלָ֖ם אַנְשֵׁ֥י הַשֵּֽׁם׃

Los nefilim estaban en la tierra en aquellos días, y también después, cuando los hijos de Dios se unían a las hijas de la humanidad y ellas les daban hijos. Esos fueron los poderosos de antaño, hombres de renombre.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.4

### Traducción seleccionada: mejor opción actual

네피림을 음역하고 그 뒤에도·반복적 상황·딸들의 출생주어·옛 용사/명성을 보존한다.그들은의 선행사는 확정하지 않는다.초기 GPT 한국어의 모호한 주어를 명료화했고 실제 Gemini 최종 스페인어 Esos fueron을 수용했다.

#### claude-sonnet-5-5

En esos días había nefilim en la tierra, y también después, cuando los hijos de Dios se unían a las hijas de los hombres y ellas les daban hijos. Esos eran los héroes de la antigüedad, hombres de renombre.

Final opinion (Korean original): 음역하고 정체는 주석 사항으로 둔다.

#### claude-opus-5-5

Los nefilim estaban en la tierra en aquellos días, y también después, cuando los hijos de Dios se unían a las hijas de los seres humanos y ellas les daban hijos. Esos fueron los héroes de antaño, los hombres de renombre.

Final opinion (Korean original): 과거 실제 난구 검토의 선호 번역: {"ko": "그 시대에, 그리고 그 뒤에도, 땅에는 네피림이 있었다. 하나님의 아들들이 사람의 딸들과 동침하여 딸들이 그들에게 자식을 낳아 주던 때였다. 그들은 옛적의 용사들, 이름난 사람들이었다.", "en": "The Nephilim were on the earth in those days, and also afterward, when the sons of God would go in to the daughters of humankind and they bore children to them. These were the mighty men of old, the men of renown.", "es": "Los nefilim estaban en la tierra en aquellos días, y también después, cuando los hijos de Dios se unían a las hijas de los seres humanos y ellas les daban hijos. Esos fueron los héroes de antaño, los hombres de renombre."} 현재 후보에 대한 새 승인 응답은 아니다.과거 신명 표기는 원기록 그대로 보존한다.

#### gemini-3.8-flash-medium

Había nefilim en la tierra en aquellos días, y también después, cuando los hijos de Dios se unieron a las hijas de los hombres y ellas les engendraron hijos. Estos fueron los valientes que desde la antigüedad fueron varones de renombre.

Final opinion (Korean original): 'וְיָלְדוּ לָהֶם'의 출생 동작 주어가 문맥상 여성들임을 파악하여 한국어에서 '딸들이 그들에게 자녀를 낳아 주곤 하던 때였다'로 명시함으로써 초기안의 주어 모호성을 말끔히 해소했습니다. 미완료 'יָבֹאוּ'의 지속적 양태를 살렸고, 네피림과 출생 자손을 동일시하지 않으면서 '그들은'(הֵמָּה)의 지시 대상을 본문 수준에서 열어두었으므로 현재 후보를 채택합니다.

#### gpt-6.1-sol

Los nefilim estaban en la tierra en aquellos días, y también después, cuando los hijos de Dios se unían a las hijas de la humanidad y ellas les daban hijos. Ellos eran los poderosos de antaño, hombres de renombre.

Final opinion (Korean original): 네피림을 음역하고 그 뒤에도·반복적 상황·딸들의 출생주어·옛 용사/명성을 보존한다.그들은의 선행사는 확정하지 않는다.초기 GPT 한국어의 모호한 주어를 명료화했고 실제 Gemini 최종 스페인어 Esos fueron을 수용했다. 동침은 들어가다의 완곡어를 명시화한 번역이다.자녀는 생략 목적어 보충이며 원문에 별도 자녀 명사는 없다.관계절 연결과 그들은의 선행사는 논쟁적이며 네피림/출생자녀 등식을 확정하지 않는다.그리스어 거인들을 WLC에 치환하지 않는다.

Counterargument (Korean): 동침은 들어가다의 완곡어를 명시화한 번역이다.자녀는 생략 목적어 보충이며 원문에 별도 자녀 명사는 없다.관계절 연결과 그들은의 선행사는 논쟁적이며 네피림/출생자녀 등식을 확정하지 않는다.그리스어 거인들을 WLC에 치환하지 않는다.

## 5 · HYB.GEN.006.005

Hebrew display (MT/WLC): וַיַּ֣רְא יְהוָ֔ה כִּ֥י רַבָּ֛ה רָעַ֥ת הָאָדָ֖ם בָּאָ֑רֶץ וְכָל־יֵ֨צֶר֙ מַחְשְׁבֹ֣ת לִבּ֔וֹ רַ֥ק רַ֖ע כָּל־הַיּֽוֹם׃

YHWH vio que la maldad de la humanidad era grande en la tierra y que todo lo que forjaban los pensamientos de su corazón era solo maldad todo el tiempo.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.5

### Traducción seleccionada: mejor opción actual

마음의 생각이 빚어 내는 것과 모든/언제나/악할 뿐의 강도를 세 언어로 보존한다.고정WLC 명사구를 선택하고 직접 읽은 그리스어의 확장·통사 재구성을 역투사하지 않는다.

#### claude-sonnet-5-5

El SEÑOR vio que la maldad del hombre era mucha en la tierra, y que todo designio de los pensamientos de su corazón era de continuo solo el mal.

Final opinion (Korean original): "계획"을 잠정 채택하고 대안을 병기한다.

#### claude-opus-5-5

YHWH vio que la maldad del ser humano en la tierra era grande, y que todo lo que forjaban los pensamientos de su corazón era solamente malo todo el tiempo.

Final opinion (Korean original): 과거 실제 난구 검토의 선호 번역: {"ko": "야훼는 땅에서 사람의 악이 크고, 그 마음의 생각이 빚어내는 모든 것이 언제나 오직 악할 뿐임을 보셨다.", "en": "YHWH saw that the evil of humankind on the earth was great, and that everything the thoughts of their hearts devised was only evil continually.", "es": "YHWH vio que la maldad del ser humano en la tierra era grande, y que todo lo que forjaban los pensamientos de su corazón era solamente malo todo el tiempo."} 현재 후보에 대한 새 승인 응답은 아니다.과거 신명 표기는 원기록 그대로 보존한다.

#### gemini-3.8-flash-medium

Y vio YHWH que la maldad del hombre era mucha en la tierra, y que todo designio de los pensamientos de su corazón era de continuo solamente el mal.

Final opinion (Korean original): 본문의 전칭 표현인 'כָּל־יֵצֶר'(모든 구상), 'רַק רַע'(오직 악함), 'כָּל־הַיּוֹם'(언제나)을 누락 없이 충실하게 반영했습니다. 'יֵצֶר'를 후대 랍비적 충동론으로 예단하지 않고 마음의 생각이 빚어내는 구상과 계획으로 옮겨 조형적 의미를 자연스럽게 살렸으며, 평서체 '보았다'를 지켰으므로 무수정 채택합니다.

#### gpt-6.1-sol

YHWH vio que la maldad de la humanidad era grande en la tierra y que toda inclinación de los pensamientos de su corazón era solo maldad todo el tiempo.

Final opinion (Korean original): 마음의 생각이 빚어 내는 것과 모든/언제나/악할 뿐의 강도를 세 언어로 보존한다.고정WLC 명사구를 선택하고 직접 읽은 그리스어의 확장·통사 재구성을 역투사하지 않는다. 산출물을 강조한 번역은 성향·지향이라는 대안보다 정적 의미를 약화할 수 있다.성향이 언제나 후대 교리를 뜻한다는 기존 모델의 단정도 채택하지 않는다.전칭 서술에서 후대의 인간론 교리를 자동 도출하지 않는다.

Counterargument (Korean): 산출물을 강조한 번역은 성향·지향이라는 대안보다 정적 의미를 약화할 수 있다.성향이 언제나 후대 교리를 뜻한다는 기존 모델의 단정도 채택하지 않는다.전칭 서술에서 후대의 인간론 교리를 자동 도출하지 않는다.

## 6 · HYB.GEN.006.006

Hebrew display (MT/WLC): וַיִּנָּ֣חֶם יְהוָ֔ה כִּֽי־עָשָׂ֥ה אֶת־הָֽאָדָ֖ם בָּאָ֑רֶץ וַיִּתְעַצֵּ֖ב אֶל־לִבּֽוֹ׃

YHWH lamentó haber hecho a la humanidad en la tierra y se afligió en su corazón.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.6.6

### Traducción seleccionada: mejor opción actual

이미 사람을 만든 일에 대한 후회와 마음의 슬픔을 각각 옮긴다.직접 읽은 Swete의 생각·숙고 표현과 구별하여 고정WLC 정서 서술을 잠정 선택했다.신학적 불변성을 이유로 본문의 동사를 지우지 않는다.

#### claude-sonnet-5-5

Y se arrepintió el SEÑOR de haber hecho al hombre en la tierra, y le dolió en su corazón.

Final opinion (Korean original): 원문의 강도를 유지한다.

#### claude-opus-5-5

A YHWH le pesó haber hecho al ser humano en la tierra, y sintió dolor en su corazón.

Final opinion (Korean original): 과거 실제 난구 검토의 선호 번역: {"ko": "야훼는 땅 위에 사람을 만드신 것을 후회하시고, 마음 깊이 아파하셨다.", "en": "YHWH regretted that he had made humankind on the earth, and he was grieved to his heart.", "es": "A YHWH le pesó haber hecho al ser humano en la tierra, y sintió dolor en su corazón."} 현재 후보에 대한 새 승인 응답은 아니다.과거 신명 표기는 원기록 그대로 보존한다.

#### gemini-3.8-flash-medium

Y YHWH se arrepintió de haber hecho al hombre en la tierra, y le dolió en su corazón.

Final opinion (Korean original): 'וַיִּנָּחֶם'의 후회와 'וַיִּתְעַצֵּב אֶל־לִבּוֹ'의 마음의 슬픔을 신학적 완화나 작위적인 어원적 규정(위로를 구함 등) 없이 본문의 직관적 정서 서술 그대로 보존했습니다. 신적 불변성과의 교리적 조화를 위해 행위의 변경으로 환원하지 않고 성경 본문의 비통한 어조를 정직하게 반영하고 있으므로 그대로 채택합니다.

#### gpt-6.1-sol

YHWH lamentó haber hecho a la humanidad en la tierra y se afligió en su corazón.

Final opinion (Korean original): 이미 사람을 만든 일에 대한 후회와 마음의 슬픔을 각각 옮긴다.직접 읽은 Swete의 생각·숙고 표현과 구별하여 고정WLC 정서 서술을 잠정 선택했다.신학적 불변성을 이유로 본문의 동사를 지우지 않는다. 그리스어가 다른 히브리어 전통을 보존할 가능성과 번역적 해석 가능성 모두 미해결이다.후회가 인간적 과오 인정과 동일하다는 교리적 결론도 내리지 않는다.형태만으로 깊은숨/위로를구함 어원을 단정하지 않는다.

Counterargument (Korean): 그리스어가 다른 히브리어 전통을 보존할 가능성과 번역적 해석 가능성 모두 미해결이다.후회가 인간적 과오 인정과 동일하다는 교리적 결론도 내리지 않는다.형태만으로 깊은숨/위로를구함 어원을 단정하지 않는다.

## Notes

La cláusula temporal del v.1 desemboca en el v.2. La identidad de los hijos de Dios y la coerción no quedan fijadas por el texto. Swete p.9 examinado dice ángeles, distinto de hijos en WLC.

El v.3 usa provisionalmente permanecer para yadon, de sentido incierto; contender/juzgar siguen siendo alternativas. Los 120 años no se fijan como vida o plazo. El v.4 translitera nefilim sin fijar el referente del pronombre. Hijos suple un objeto implícito.

El v.5 conserva todo, solo mal y todo el tiempo sin imponer doctrina posterior. El v.6 sigue el pesar y dolor de WLC, distinguidos del lenguaje griego de reflexión. No añade resoluciones doctrinales.

La entrada es WLC/OSHB fijado; Swete1901 p.9 es una edición impresa. El examen de aparatos BHS/BHQ y Gotinga, testigos samaritanos y del Mar Muerto, otras versiones antiguas y cotejo completo de Leningrado4r sigue pendiente. El acuerdo de modelos no es testimonio manuscrito.

## Citation

Hansam Yang. Original Bible: Genesis 6:1–6 (es), research pilot v0.4.23. https://yangs777.github.io/hansam-bible/es/genesis-6/

Editorial material: CC BY 4.0 to the extent rights are held. Ancient WLC text: public domain. OSHB morphology: CC BY 4.0, Open Scriptures Hebrew Bible.

No human specialist approval is claimed.

Source transformation: OSHB separators removed; original vowel/accent codepoints preserved; punctuation spacing adapted.
