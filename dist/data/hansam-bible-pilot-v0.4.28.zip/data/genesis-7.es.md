# Génesis 7:1–2

Hansam Yang · Original Bible · v0.4.28

Borrador de traducción asistido por IA · pendiente de revisión especializada y nativa

Este es un borrador de investigación. No afirma haber descubierto un autógrafo ni reconstruido por completo el texto más antiguo.

Selecciones provisionales de los primeros dos versículos con propuestas independientes, opiniones finales, observaciones limitadas y vacíos de acceso. Revisión especializada y cotejo completo pendientes.

Basis: 고정WLC4.20/OSHB잠정저본.독립GPT·Gemini초기안및실제최종의견·반론·난구검토보존.과거Claude다섯절초안재사용.Swete1901인쇄10쪽직접열람,레닌그라드4v핵심자음어구한정대조.현대장치·사본전면대조·인간전문가검수대기.

Decision: Current best selected — revisable with stronger evidence

## 1 · HYB.GEN.007.001

Hebrew display (MT/WLC): וַיֹּ֤אמֶר יְהוָה֙ לְנֹ֔חַ בֹּֽא־אַתָּ֥ה וְכָל־בֵּיתְךָ֖ אֶל־הַתֵּבָ֑ה כִּֽי־אֹתְךָ֥ רָאִ֛יתִי צַדִּ֥יק לְפָנַ֖י בַּדּ֥וֹר הַזֶּֽה׃

YHWH dijo a Noé: «Entra en el arca, tú y toda tu casa, porque he visto que eres justo ante mí en esta generación.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.7.1

### Traducción seleccionada: mejor opción actual

화자 여호와와 노아수신자,명령,온집안,이유 כי,앞세운 목적어너,보았다와 의롭다·내앞에서·이세대를 보존한다.집은 건물이아닌 구성원으로 읽는다.

#### claude-sonnet-5-5

El SEÑOR dijo a Noé: «Entra en el arca, tú y toda tu casa, porque he visto que eres justo delante de mí en esta generación.

Final opinion (Korean original): 현재 번역을 잠정안으로 둔다.

#### gemini-3.8-flash-medium

Entonces YHWH dijo a Noé: “Entra en el arca, tú y toda tu casa, porque a ti he visto justo delante de mí en esta generación.

Final opinion (Korean original): 노아 1인에 대한 구체적 평가와 가구 전체의 방주 승선 연대성을 원문 어순대로 공존시키고, 신명 '여호와'를 확고히 지킨 현 후보안을 잠정 채택 권고합니다. 신적 발화가 계속되므로 절 끝 따옴표는 닫지 않습니다.

#### gpt-6.1-sol

YHWH dijo a Noé: «Entra en el arca, tú y toda tu casa, porque he visto que eres justo ante mí en esta generación.

Final opinion (Korean original): 화자 여호와와 노아수신자,명령,온집안,이유 כי,앞세운 목적어너,보았다와 의롭다·내앞에서·이세대를 보존한다.집은 건물이아닌 구성원으로 읽는다. 반론: 의롭게 인정했다는 평가적번역도 가능하나 보았다를남긴다.명령은단수노아에게 주어졌지만 가구전체가포함된다.너의전면배치가 오직너만이라는 배타적무죄를뜻한다고단정하지않는다.의로움의신학적기준·완전무죄·가족의동일평가를보충하지않는다. 고정WLC와Swete차이를구별하고인간전문가검수대기.

Counterargument (Korean): 의롭게 인정했다는 평가적번역도 가능하나 보았다를남긴다.명령은단수노아에게 주어졌지만 가구전체가포함된다.너의전면배치가 오직너만이라는 배타적무죄를뜻한다고단정하지않는다.의로움의신학적기준·완전무죄·가족의동일평가를보충하지않는다.

## 2 · HYB.GEN.007.002

Hebrew display (MT/WLC): מִכֹּ֣ל ׀ הַבְּהֵמָ֣ה הַטְּהוֹרָ֗ה תִּֽקַּח־לְךָ֛ שִׁבְעָ֥ה שִׁבְעָ֖ה אִ֣ישׁ וְאִשְׁתּ֑וֹ וּמִן־הַבְּהֵמָ֡ה אֲ֠שֶׁר לֹ֣א טְהֹרָ֥ה הִ֛וא שְׁנַ֖יִם אִ֥ישׁ וְאִשְׁתּֽוֹ׃

De todo animal puro toma siete por siete, un macho y su pareja; y de los animales que no son puros, dos, un macho y su pareja.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.7.2

### Traducción seleccionada: mejor opción actual

반복수사 שבעה שבעה의 분배형태와 사람용어인 איש ואשתו의동물짝 적용을 드러낸다.한국어 일곱씩은 반복수사의분배기능을 자연스럽게옮긴다.뒤의둘은 수컷과짝을 이룬다.정결하지않은이라는부정을지켜 부정형범주를동일어휘로유지한다. 7:2의짝·수량논쟁은공개주석에유보.

#### claude-sonnet-5-5

De todo animal limpio toma siete parejas, el macho y su hembra; y de los animales que no son limpios, dos, el macho y su hembra;

Final opinion (Korean original): '암수 일곱 쌍'으로 잠정 정리한다.

#### gemini-3.8-flash-medium

De todo animal limpio tomarás para ti de siete en siete, el macho y su hembra; y de los animales que no son limpios, dos, el macho y su hembra;

Final opinion (Korean original): 사본 교정(텍스트 변경)과 번역 선택(해석적 어휘 결정)을 엄격히 구분하여, 본문은 분배형 직역 '일곱씩, 수컷과 그 짝'으로 원문의 불명확성을 그대로 열어두고, '일곱 쌍(14마리)' 및 '총 7마리' 해석의 긴장은 접힌 주석에 객관적으로 명시하는 방안으로 잠정 채택 권고합니다.

#### gpt-6.1-sol

De todo animal puro toma siete por siete, un macho y su pareja; y de los animales que no son puros, dos, un macho y su pareja.

Final opinion (Korean original): 반복수사 שבעה שבעה의 분배형태와 사람용어인 איש ואשתו의동물짝 적용을 드러낸다.한국어 일곱씩은 반복수사의분배기능을 자연스럽게옮긴다.뒤의둘은 수컷과짝을 이룬다.정결하지않은이라는부정을지켜 부정형범주를동일어휘로유지한다. 반론: 정결한동물은 일곱쌍(14마리)인지 총일곱인지 논쟁이있다.수컷과그짝의분배를일곱에적용하면 일곱쌍이자연스러우나 반복수사만으로 숫자를곱하지는않는다.직역후보는 현대독자에게 수량을불명확하게할수있다.정결은 위생이나후대음식법 전체를뜻한다고확정못한다.בהמה범위를가축만으로 제한할지도유보. 고정WLC와Swete차이를구별하고인간전문가검수대기.

Counterargument (Korean): 정결한동물은 일곱쌍(14마리)인지 총일곱인지 논쟁이있다.수컷과그짝의분배를일곱에적용하면 일곱쌍이자연스러우나 반복수사만으로 숫자를곱하지는않는다.직역후보는 현대독자에게 수량을불명확하게할수있다.정결은 위생이나후대음식법 전체를뜻한다고확정못한다.בהמה범위를가축만으로 제한할지도유보.

## Notes

El v.1 conserva he visto, justo, ante mí y esta generación, e incluye toda la casa. El v.2 mantiene siete por siete con un macho y su pareja. Siete parejas (catorce animales) es una lectura fuerte al distribuir la pareja, pero siete en total sigue siendo alternativa; no se fija una suma. La repetición griega con macho y hembra no resuelve la cuestión. No se añaden criterios de pureza, sacrificios posteriores ni armonización con el capítulo 6.

La entrada es WLC4.20/OSHB fijado. Swete1901 p.10 es una edición moderna de una versión antigua. Se examinaron frases consonánticas limitadas de Leningrado4v, no todas las vocales, acentos o notas masoréticas. El cotejo completo queda pendiente.

## Citation

Hansam Yang. Original Bible: Genesis 7:1–2 (es), research pilot v0.4.28. https://yangs777.github.io/hansam-bible/es/genesis-7/

Editorial material: CC BY 4.0 to the extent rights are held. Ancient WLC text: public domain. OSHB morphology: CC BY 4.0, Open Scriptures Hebrew Bible.

No human specialist approval is claimed.

Source transformation: OSHB separators removed; original vowel/accent codepoints preserved; punctuation spacing adapted.
