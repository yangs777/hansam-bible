# Genesis 3:1–24

Hansam Yang · Original Bible · v0.4.11

AI-assisted translation draft · specialist and native-language review pending

This is a research draft. It does not claim discovery of an autograph or a complete reconstruction of the earliest text.

All 24 verses of Genesis 3 have selections in three languages and actual GPT/Gemini comparisons, with Claude Code reviews for difficult subsets. Alternatives remain in notes; full manuscript collation and human specialist review are pending.

Basis: MT-WLC display; no independent full critical collation completed

Decision: Current best selected — revisable with stronger evidence

## 1 · HYB.GEN.003.001

Hebrew display (MT/WLC): וְהַנָּחָשׁ֙ הָיָ֣ה עָר֔וּם מִכֹּל֙ חַיַּ֣ת הַשָּׂדֶ֔ה אֲשֶׁ֥ר עָשָׂ֖ה יְהוָ֣ה אֱלֹהִ֑ים וַיֹּ֨אמֶר֙ אֶל־הָ֣אִשָּׁ֔ה אַ֚ף כִּֽי־אָמַ֣ר אֱלֹהִ֔ים לֹ֣א תֹֽאכְל֔וּ מִכֹּ֖ל עֵ֥ץ הַגָּֽן׃

The serpent was craftier than any wild animal that YHWH God had made. It said to the woman, “Did God really say, ‘You must not eat from any tree of the garden’?”

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.1

### Current best selected translation

꾀가 많았다는 비교와 복수 너희를 보존하고, 하나님이 정말로라고 묻는 반문 및 어떤 나무에서도라는 전면 금지 인용을 현재 채택한다.

#### claude-opus-5-5

Now the serpent was shrewder than any wild animal that the LORD God had made. It said to the woman, “Did God really say, ‘You [pl.] shall not eat from any tree of the garden’?”

Final opinion (Korean original): 채택되지 않은 초안으로 위 번역을 제안한다. 각주 필수 사항은 세 가지다. ① אַף כִּי는 반문/감탄/미완결로 읽을 수 있다. ② לֹא … מִכֹּל은 '어떤 나무도'와 '모든 나무는 아님' 모두로 읽힌다. ③ עָרוּם은 2:25와 말놀이를 이룬다. 뱀의 정체에 대한 신학적 동일시는 본문에 넣지 않는다.

#### gemini-3.8-flash-medium

Now the serpent was craftier than any beast of the field which the LORD God had made. And he said to the woman, "Did God really say, 'You [plural] shall not eat from any tree of the garden'?"

Final opinion (Korean original): 뱀을 피조물 들짐승의 범주에 두고 화자 표기 및 2인칭 복수를 충실히 반영했습니다. BDB 637(אַף כִּי, 2항)에 등재된 의문형 용례(‘has God really said?’)와 부합하게 수사적 의문문으로 구성되었으며, ‘לֹא ... מִכֹּל’ 구문을 전면 금지(‘어떤 나무에서도 먹지 말라 / from any tree / de ningún árbol’)로 처리한 선택은 담화 문맥상 타당합니다. 스페인어 ‘No coman’(ustedes 복수) 및 한국어 ‘너희’도 복수 청자를 정확히 지시합니다.

#### gpt-6.1-sol

The serpent was craftier than any wild animal that YHWH God had made. It said to the woman, “Did God really say, ‘You must not eat from any tree of the garden’?”

Final opinion (Korean original): 꾀가 많았다는 비교와 복수 너희를 보존하고, 하나님이 정말로라고 묻는 반문 및 어떤 나무에서도라는 전면 금지 인용을 현재 채택한다. אף כי의 감탄·미완결 발화, 모든 나무에서는 아님이라는 부정 범위 대안은 남긴다. 문법만으로 예외 없음이나 뱀의 심리를 확정하지 않고 사탄이라는 이름을 보충하지 않는다.

Counterargument (Korean): אף כי의 감탄·미완결 발화, 모든 나무에서는 아님이라는 부정 범위 대안은 남긴다. 문법만으로 예외 없음이나 뱀의 심리를 확정하지 않고 사탄이라는 이름을 보충하지 않는다.

Previous v0.4.10

The serpent was craftier than any wild animal that YHWH God had made. It said to the woman, “Did God really say, ‘You must not eat from any tree of the garden’?”

Previous v0.4.5

The serpent was craftier than any wild animal that YHWH God had made. It said to the woman, “Did God really say, ‘You must not eat from any tree of the garden’?”

Previous v0.4.6

The serpent was craftier than any wild animal that YHWH God had made. It said to the woman, “Did God really say, ‘You must not eat from any tree of the garden’?”

Previous v0.4.7

The serpent was craftier than any wild animal that YHWH God had made. It said to the woman, “Did God really say, ‘You must not eat from any tree of the garden’?”

Previous v0.4.8

The serpent was craftier than any wild animal that YHWH God had made. It said to the woman, “Did God really say, ‘You must not eat from any tree of the garden’?”

Previous v0.4.9

The serpent was craftier than any wild animal that YHWH God had made. It said to the woman, “Did God really say, ‘You must not eat from any tree of the garden’?”

## 2 · HYB.GEN.003.002

Hebrew display (MT/WLC): וַתֹּ֥אמֶר הָֽאִשָּׁ֖ה אֶל־הַנָּחָ֑שׁ מִפְּרִ֥י עֵֽץ־הַגָּ֖ן נֹאכֵֽל׃

The woman said to the serpent, “We may eat the fruit of the trees of the garden.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.2

### Current best selected translation

우리의 허용 답변으로 먹어도 된다를 선택한다. 나무의 총칭을 복수로 풀고 인용을 다음 절까지 잇는다.

#### gemini-3.8-flash-medium

And the woman said to the serpent, "From the fruit of the trees of the garden we may eat;"

Final opinion (Korean original): 화자 표기와 1인칭 공성 복수 허용상(‘먹어도 된다 / We may eat / Podemos comer’)을 직관적이고 정확하게 전달합니다. 2~3절로 이어지는 인용 부호 열림(따옴표 미종결) 처리는 여자의 단일 연속 발화를 나타내기 위한 의도적이고 정당한 편집적 문장부호 처리입니다.

#### gpt-6.1-sol

The woman said to the serpent, “We may eat the fruit of the trees of the garden.

Final opinion (Korean original): 우리의 허용 답변으로 먹어도 된다를 선택한다. 나무의 총칭을 복수로 풀고 인용을 다음 절까지 잇는다. 먹는다·먹을 것이다도 양태 대안이다. 앞 장과의 표현 차이만으로 여자의 심리적 약화나 의도적 축소를 단정하지 않는다.

Counterargument (Korean): 먹는다·먹을 것이다도 양태 대안이다. 앞 장과의 표현 차이만으로 여자의 심리적 약화나 의도적 축소를 단정하지 않는다.

Previous v0.4.10

The woman said to the serpent, “We may eat the fruit of the trees of the garden.

Previous v0.4.5

The woman said to the serpent, “We may eat the fruit of the trees of the garden.

Previous v0.4.6

The woman said to the serpent, “We may eat the fruit of the trees of the garden.

Previous v0.4.7

The woman said to the serpent, “We may eat the fruit of the trees of the garden.

Previous v0.4.8

The woman said to the serpent, “We may eat the fruit of the trees of the garden.

Previous v0.4.9

The woman said to the serpent, “We may eat the fruit of the trees of the garden.

## 3 · HYB.GEN.003.003

Hebrew display (MT/WLC): וּמִפְּרִ֣י הָעֵץ֮ אֲשֶׁ֣ר בְּתוֹךְ־הַגָּן֒ אָמַ֣ר אֱלֹהִ֗ים לֹ֤א תֹֽאכְלוּ֙ מִמֶּ֔נּוּ וְלֹ֥א תִגְּע֖וּ בּ֑וֹ פֶּן־תְּמֻתֽוּן׃

But concerning the fruit of the tree in the middle of the garden, God said, ‘You must not eat from it or touch it, lest you die.’”

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.3

### Current best selected translation

먹지 말라와 만지지 말라를 여자가 전하는 말로 그대로 보존한다. פן은 피하려는 결과로 옮기며 ממנו는 문맥상 그것에서로 읽는다.

#### gemini-3.8-flash-medium

"but of the fruit of the tree that is in the middle of the garden, God said, 'You [plural] shall not eat from it, neither shall you [plural] touch it, lest you [plural] die.'"

Final opinion (Korean original): 창세기 2:17의 원명령에 기대어 여자의 발화를 사후 조화시키지 않고, 본문에 기록된 대로 만짐 금지(‘만지지도 말라 / or touch it / ni lo toquen’)를 온전히 보존했습니다. OSHB에서 ‘מִמֶּנּוּ’가 1인칭 복수(1cp)로 오태깅되어 있으나 문맥에 맞게 3인칭 단수 ‘그것을 / from it / de él’로 정확히 번역되었습니다. ‘פֶּן(lest / para que no / 죽지 않도록)’ 역시 여자의 주관적 심리(의심·과장)를 예단하지 않고 행위의 부정적 귀결을 막기 위한 접속사 본연의 통사적 기능대로 번역되었습니다. 다만 한국어의 경우 ‘죽지 않도록 먹지도 만지지도 말라’는 어순으로 인해 접속절이 금지 명령의 사전 목적처럼 읽힐 수 있으므로, ‘먹지도 만지지도 말라. 그렇지 않으면 죽을 것이다/죽지 않도록 하여라’ 형태와의 긴장이 존재합니다.

#### gpt-6.1-sol

But concerning the fruit of the tree in the middle of the garden, God said, ‘You must not eat from it or touch it, lest you die.’”

Final opinion (Korean original): 먹지 말라와 만지지 말라를 여자가 전하는 말로 그대로 보존한다. פן은 피하려는 결과로 옮기며 ממנו는 문맥상 그것에서로 읽는다. 왜 접촉 금지가 앞 장의 기록과 다른지는 확정하지 않는다. 수입 형태분석 1cp 태그는 그대로 남기며, 파라고긱 눈에 필수적인 엄중함을 부여하지 않는다. Gemini가 지적한 목적절 선행의 경고 효과 차이를 기록하되 세 언어의 피하려는 결과라는 현재 선택을 유지한다.

Counterargument (Korean): 왜 접촉 금지가 앞 장의 기록과 다른지는 확정하지 않는다. 수입 형태분석 1cp 태그는 그대로 남기며, 파라고긱 눈에 필수적인 엄중함을 부여하지 않는다. 한국어 목적절을 앞에 둔 선택은 경고의 강도를 덜 드러낼 수 있으며, 금지 뒤에 경고를 두는 어순도 대안이다.

Previous v0.4.10

But concerning the fruit of the tree in the middle of the garden, God said, ‘You must not eat from it or touch it, lest you die.’”

Previous v0.4.5

But concerning the fruit of the tree in the middle of the garden, God said, ‘You must not eat from it or touch it, lest you die.’”

Previous v0.4.6

But concerning the fruit of the tree in the middle of the garden, God said, ‘You must not eat from it or touch it, lest you die.’”

Previous v0.4.7

But concerning the fruit of the tree in the middle of the garden, God said, ‘You must not eat from it or touch it, lest you die.’”

Previous v0.4.8

But concerning the fruit of the tree in the middle of the garden, God said, ‘You must not eat from it or touch it, lest you die.’”

Previous v0.4.9

But concerning the fruit of the tree in the middle of the garden, God said, ‘You must not eat from it or touch it, lest you die.’”

## 4 · HYB.GEN.003.004

Hebrew display (MT/WLC): וַיֹּ֥אמֶר הַנָּחָ֖שׁ אֶל־הָֽאִשָּׁ֑ה לֹֽא־מ֖וֹת תְּמֻתֽוּן׃

The serpent said to the woman, “You certainly will not die.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.4

### Current best selected translation

죽음 표현의 반복을 뱀의 강한 부정으로 옮기고 복수 너희와 발화자를 보존한다.

#### claude-opus-5-5

The serpent said to the woman, “You [pl.] will certainly not die!”

Final opinion (Korean original): 강조 부정으로 옮긴 이 번역을 채택되지 않은 초안으로 제안한다. 각주에는 두 가지를 적는다. 어순상 '반드시 죽는다'는 표현 자체를 부정하는 메아리로 읽을 수 있다는 점, 그리고 첨가된 נ의 의미는 확정할 수 없다는 점이다.

#### gemini-3.8-flash-medium

And the serpent said to the woman, "You [plural] will surely not die!"

Final opinion (Korean original): 부정사 ‘לֹא’와 절대무한사 ‘מוֹת’ 및 미완료 복수동사를 엄밀히 구분하여 하나님의 선언(2:17)에 맞선 단호한 부정(‘결코 죽지 않을 것이다 / certainly will not die / Ciertamente no morirán’)을 잘 살렸습니다. 4~5절로 이어지는 닫는 따옴표 생략도 뱀의 연속 담화를 표시하는 타당한 편집입니다.

#### gpt-6.1-sol

The serpent said to the woman, “You certainly will not die.

Final opinion (Korean original): 죽음 표현의 반복을 뱀의 강한 부정으로 옮기고 복수 너희와 발화자를 보존한다. 반드시 죽는다는 확실성을 부정하는 메아리 독법도 가능하다. 즉사·지연·영생 같은 시간표를 번역에 추가하지 않는다. 검증되지 않은 평행구절이나 예외 없는 통사 법칙을 근거로 삼지 않는다.

Counterargument (Korean): 반드시 죽는다는 확실성을 부정하는 메아리 독법도 가능하다. 즉사·지연·영생 같은 시간표를 번역에 추가하지 않는다. 검증되지 않은 평행구절이나 예외 없는 통사 법칙을 근거로 삼지 않는다.

Previous v0.4.10

The serpent said to the woman, “You certainly will not die.

Previous v0.4.5

The serpent said to the woman, “You certainly will not die.

Previous v0.4.6

The serpent said to the woman, “You certainly will not die.

Previous v0.4.7

The serpent said to the woman, “You certainly will not die.

Previous v0.4.8

The serpent said to the woman, “You certainly will not die.

Previous v0.4.9

The serpent said to the woman, “You certainly will not die.

## 5 · HYB.GEN.003.005

Hebrew display (MT/WLC): כִּ֚י יֹדֵ֣עַ אֱלֹהִ֔ים כִּ֗י בְּיוֹם֙ אֲכָלְכֶ֣ם מִמֶּ֔נּוּ וְנִפְקְח֖וּ עֵֽינֵיכֶ֑ם וִהְיִיתֶם֙ כֵּֽאלֹהִ֔ים יֹדְעֵ֖י ט֥וֹב וָרָֽע׃

For God knows that on the day you eat from it your eyes will be opened, and you will be like God, knowing good and evil.”

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.5

### Current best selected translation

같은 절 앞부분의 단수 일치와 문맥을 따라 하나님처럼을 현재 선택하고, 복수 아는 이들이라는 상태를 드러낸다.

#### claude-opus-5-5

“For God knows that on the day you [pl.] eat from it your eyes will be opened, and you will be like God, knowing good and evil.”

Final opinion (Korean original): 위 번역을 채택되지 않은 초안으로 제안한다. 각주 필수 사항은 다음과 같다. ① כֵּאלֹהִים은 '하나님처럼'과 '신들/신적 존재들처럼'으로 읽을 수 있다. ② 복수 분사 יֹדְעֵי가 '너희'와 אֱלֹהִים 중 어느 쪽과 일치하는지 모호하다. ③ 첫 כִּי는 '왜냐하면'과 '오히려'로 읽을 수 있다. ④ טוֹב וָרָע는 merism일 수 있다. 확정적 신학 해석은 덧붙이지 않는다.

#### gemini-3.8-flash-medium

"For God knows that in the day you [plural] eat of it your eyes will be opened, and you will be like God [or divine beings], knowing good and evil."

Final opinion (Korean original): 앞부분의 단수 분사 ‘יֹדֵעַ’를 하나님의 인지 상태로, 뒷부분의 복수 분사 ‘יֹדְעֵי’를 상태적 속성(한국어 ‘아는 이들’, 스페인어 명사화 ‘conocedores’)으로 훌륭하게 전환하여 번역했습니다. BDB 430(4a)에서 창 3:5의 ‘כֵּאלֹהִים’을 단수 ‘God’으로 분류한 잠정적 선택을 주 번역으로 채택하면서도, 3:22과의 연계성 및 복수 분사 수식 관계를 열어둔 상태로 번역문이 자연스럽게 완결되었습니다.

#### gpt-6.1-sol

For God knows that on the day you eat from it your eyes will be opened, and you will be like God, knowing good and evil.”

Final opinion (Korean original): 같은 절 앞부분의 단수 일치와 문맥을 따라 하나님처럼을 현재 선택하고, 복수 아는 이들이라는 상태를 드러낸다. 신들·신적 존재들처럼 및 복수 분사의 다른 부착 대안이 있다. 처음 כי의 오히려 독법, 날/때, 선악의 지식 범위는 추가 검토 대상이며 교리나 생물학적 순서를 확정하지 않는다.

Counterargument (Korean): 신들·신적 존재들처럼 및 복수 분사의 다른 부착 대안이 있다. 처음 כי의 오히려 독법, 날/때, 선악의 지식 범위는 추가 검토 대상이며 교리나 생물학적 순서를 확정하지 않는다.

Previous v0.4.10

For God knows that on the day you eat from it your eyes will be opened, and you will be like God, knowing good and evil.”

Previous v0.4.5

For God knows that on the day you eat from it your eyes will be opened, and you will be like God, knowing good and evil.”

Previous v0.4.6

For God knows that on the day you eat from it your eyes will be opened, and you will be like God, knowing good and evil.”

Previous v0.4.7

For God knows that on the day you eat from it your eyes will be opened, and you will be like God, knowing good and evil.”

Previous v0.4.8

For God knows that on the day you eat from it your eyes will be opened, and you will be like God, knowing good and evil.”

Previous v0.4.9

For God knows that on the day you eat from it your eyes will be opened, and you will be like God, knowing good and evil.”

## 6 · HYB.GEN.003.006

Hebrew display (MT/WLC): וַתֵּ֣רֶא הָֽאִשָּׁ֡ה כִּ֣י טוֹב֩ הָעֵ֨ץ לְמַאֲכָ֜ל וְכִ֧י תַֽאֲוָה־ה֣וּא לָעֵינַ֗יִם וְנֶחְמָ֤ד הָעֵץ֙ לְהַשְׂכִּ֔יל וַתִּקַּ֥ח מִפִּרְי֖וֹ וַתֹּאכַ֑ל וַתִּתֵּ֧ן גַּם־לְאִישָׁ֛הּ עִמָּ֖הּ וַיֹּאכַֽל׃

The woman saw that the tree was good for food, a delight to the eyes, and desirable for gaining wisdom. She took some of its fruit and ate, and she also gave some to her husband who was with her, and he ate.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.6

### Current best selected translation

세 평가와 먹고 주는 행동을 보존하고 להשכיל은 지혜를 얻기로 현재 선택한다. 함께 있던 남편은 해당 장면의 자연스러운 관계 표현이다.

#### claude-opus-5-5

The woman saw that the tree was good for food and that it was a delight to the eyes, and the tree was desirable for gaining insight. She took some of its fruit and ate, and she also gave to her husband with her, and he ate.

Final opinion (Korean original): 채택 후보 초안으로 제출한다. עִמָּהּ의 범위와 לְהַשְׂכִּיל의 의미 폭은 GPT/Gemini 비교와 편집 판단이 필요한 쟁점으로 남긴다.

#### gemini-3.8-flash-medium

And the woman saw that the tree was good for food, and that it was a delight to the eyes, and that the tree was desirable to gain insight, and she took of its fruit and ate; and she gave also to her husband with her, and he ate.

Final opinion (Korean original): 선정된 한·영·스 번역은 인지적 측면('지혜를 얻기에', 'gaining wisdom', 'adquirir sabiduría')을 주 텍스트로 채택하고 있으나, BDB(7919) 힙필 항목에서 창 3:6을 '바라보다(look at)' 아래에 분류하면서 '지혜롭게 하다/통찰을 얻다'의 가능성을 병기하고 있음을 주석에서 반드시 명시해야 합니다. 'שׂכל'의 시각적 관조 의미를 배제되거나 반증된 것으로 단정해서는 안 되며, 두 독법의 개방성을 대등하게 유지해야 합니다. 또한 '자기와 함께 있던 남편(עִמָּהּ)'은 열매를 건네는 시점의 공간적 인접성을 기술할 뿐, 뱀과의 이전 대화 전체 과정에 남편이 계속 동석하고 있었음을 확증하지 않는다는 점을 주석에 분명히 남겨야 합니다.

#### gpt-6.1-sol

The woman saw that the tree was good for food, a delight to the eyes, and desirable for becoming wise. She took some of its fruit and ate, and she also gave some to her husband who was with her, and he ate.

Final opinion (Korean original): 세 평가와 먹고 주는 행동을 보존하고 להשכיל은 지혜를 얻기로 현재 선택한다. 함께 있던 남편은 해당 장면의 자연스러운 관계 표현이다. 바라보기에라는 시각적 대안도 BDB에 명시되어 있으며 인지 독법만 확정하지 않는다. 세 번째 평가절의 통사 범위도 논의 대상이다. 함께 있었다는 말로 앞선 대화 내내의 동석을 단정하지 않는다.

Counterargument (Korean): 바라보기에라는 시각적 대안도 BDB에 명시되어 있으며 인지 독법만 확정하지 않는다. 세 번째 평가절의 통사 범위도 논의 대상이다. 함께 있었다는 말로 앞선 대화 내내의 동석을 단정하지 않는다.

Previous v0.4.10

The woman saw that the tree was good for food, a delight to the eyes, and desirable for gaining wisdom. She took some of its fruit and ate, and she also gave some to her husband who was with her, and he ate.

Previous v0.4.6

The woman saw that the tree was good for food, a delight to the eyes, and desirable for gaining wisdom. She took some of its fruit and ate, and she also gave some to her husband who was with her, and he ate.

Previous v0.4.7

The woman saw that the tree was good for food, a delight to the eyes, and desirable for gaining wisdom. She took some of its fruit and ate, and she also gave some to her husband who was with her, and he ate.

Previous v0.4.8

The woman saw that the tree was good for food, a delight to the eyes, and desirable for gaining wisdom. She took some of its fruit and ate, and she also gave some to her husband who was with her, and he ate.

Previous v0.4.9

The woman saw that the tree was good for food, a delight to the eyes, and desirable for gaining wisdom. She took some of its fruit and ate, and she also gave some to her husband who was with her, and he ate.

## 7 · HYB.GEN.003.007

Hebrew display (MT/WLC): וַתִּפָּקַ֨חְנָה֙ עֵינֵ֣י שְׁנֵיהֶ֔ם וַיֵּ֣דְע֔וּ כִּ֥י עֵֽירֻמִּ֖ם הֵ֑ם וַֽיִּתְפְּרוּ֙ עֲלֵ֣ה תְאֵנָ֔ה וַיַּעֲשׂ֥וּ לָהֶ֖ם חֲגֹרֹֽת׃

Then the eyes of both of them were opened, and they knew that they were naked. They sewed fig leaves together and made waist coverings for themselves.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.7

### Current best selected translation

눈이 열림·벌거벗음의 인식·잎을 꿰맴을 보존하고 חגורות는 BDB의 해당 용례에 따라 허리 가리개를 현재 선택한다.

#### gemini-3.8-flash-medium

Then the eyes of both of them were opened, and they knew that they were naked; and they sewed fig leaves together and made girdles for themselves.

Final opinion (Korean original): 선정본의 '허리 가리개', 'waist coverings', 'cubiertas para la cintura'는 BDB(2290)의 'girdle, loin-covering' 범주에 부합하는 적절하고 절제된 번역입니다. 특정한 복식 형태(스커트, 앞치마 등)나 재봉의 정교성, 크기, 어원적 절대성을 규정하지 않고, 허리 둘레를 두르는 최소한의 가림 장치라는 물리적 기능에 국한하여 번역된 점이 타당합니다.

#### gpt-6.1-sol

Then the eyes of both of them were opened, and they knew that they were naked. They sewed fig leaves together and made waist coverings for themselves.

Final opinion (Korean original): 눈이 열림·벌거벗음의 인식·잎을 꿰맴을 보존하고 חגורות는 BDB의 해당 용례에 따라 허리 가리개를 현재 선택한다. 띠·앞치마도 대안이다. 정확한 크기·재단·의복 형태를 확정하지 않는다. עלה는 수입 형태분석의 단수 태그를 보존하며 번역에서는 집합적 잎을 자연스럽게 표현한다.

Counterargument (Korean): 띠·앞치마도 대안이다. 정확한 크기·재단·의복 형태를 확정하지 않는다. עלה는 수입 형태분석의 단수 태그를 보존하며 번역에서는 집합적 잎을 자연스럽게 표현한다.

Previous v0.4.10

Then the eyes of both of them were opened, and they knew that they were naked. They sewed fig leaves together and made waist coverings for themselves.

Previous v0.4.6

Then the eyes of both of them were opened, and they knew that they were naked. They sewed fig leaves together and made waist coverings for themselves.

Previous v0.4.7

Then the eyes of both of them were opened, and they knew that they were naked. They sewed fig leaves together and made waist coverings for themselves.

Previous v0.4.8

Then the eyes of both of them were opened, and they knew that they were naked. They sewed fig leaves together and made waist coverings for themselves.

Previous v0.4.9

Then the eyes of both of them were opened, and they knew that they were naked. They sewed fig leaves together and made waist coverings for themselves.

## 8 · HYB.GEN.003.008

Hebrew display (MT/WLC): וַֽיִּשְׁמְע֞וּ אֶת־ק֨וֹל יְהוָ֧ה אֱלֹהִ֛ים מִתְהַלֵּ֥ךְ בַּגָּ֖ן לְר֣וּחַ הַיּ֑וֹם וַיִּתְחַבֵּ֨א הָֽאָדָ֜ם וְאִשְׁתּ֗וֹ מִפְּנֵי֙ יְהוָ֣ה אֱלֹהִ֔ים בְּת֖וֹךְ עֵ֥ץ הַגָּֽן׃

They heard the sound of YHWH God walking about in the garden in the day's breeze. The man and his wife hid from YHWH God among the trees of the garden.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.8

### Current best selected translation

קול은 소리로, מתהלך는 하나님이 거니심으로, לרוח היום은 그날의 바람이라는 표현으로 현재 선택한다. 나무의 집합 의미를 복수로 풀었다.

#### claude-opus-5-5

They heard the sound of the LORD God walking about in the garden at the breezy time of the day, and the man and his wife hid themselves from the presence of the LORD God among the trees of the garden.

Final opinion (Korean original): 채택 후보 초안으로 제출한다. לְרוּחַ הַיּוֹם의 시간/현상 해석과 מִתְהַלֵּךְ의 수식 대상은 쟁점으로 남긴다. 폭풍이나 신현은 확정하지 않는다.

#### gemini-3.8-flash-medium

And they heard the sound of YHWH God walking in the garden at the breeze of the day, and the man and his wife hid themselves from the presence of YHWH God among the trees of the garden.

Final opinion (Korean original): 선정본의 '소리/sound/sonido'와 '그날의 바람/day's breeze/brisa del día'는 원문의 다의성을 해치지 않는 건실한 번역입니다. 'קוֹל'은 음성과 물리적 발소리 모두로 수정·재고될 수 있으며, 분사 'מִתְהַלֵּךְ'의 수식 대상 역시 하나님 자신인지 혹은 진동하는 소리인지 문법적으로 확정되지 않았음을 주석에 명시해야 합니다. 아울러 BDB(7307 2a)가 창 3:8을 '낮의 바람/저녁 바람'으로 병기하듯, 이는 특정 시각(정오, 저녁), 기온, 폭풍 신현, 혹은 일상적 관습을 확증하는 표현이 아니므로 단정적 해석을 배제해야 합니다.

#### gpt-6.1-sol

They heard the sound of YHWH God walking about in the garden in the day's breeze. The man and his wife hid from YHWH God among the trees of the garden.

Final opinion (Korean original): קול은 소리로, מתהלך는 하나님이 거니심으로, לרוח היום은 그날의 바람이라는 표현으로 현재 선택한다. 나무의 집합 의미를 복수로 풀었다. 목소리 및 소리가 움직인다는 구문 대안, 저녁/서늘한 때라는 시간 해석을 남긴다. BDB는 낮의 바람·저녁 바람을 병기한다. breeze/brisa는 현재 역어이며 강도·기온·정오·폭풍·습관을 본문만으로 확정하지 않는다.

Counterargument (Korean): 목소리 및 소리가 움직인다는 구문 대안, 저녁/서늘한 때라는 시간 해석을 남긴다. BDB는 낮의 바람·저녁 바람을 병기한다. breeze/brisa는 현재 역어이며 강도·기온·정오·폭풍·습관을 본문만으로 확정하지 않는다.

Previous v0.4.10

They heard the sound of YHWH God walking about in the garden in the day's breeze. The man and his wife hid from YHWH God among the trees of the garden.

Previous v0.4.6

They heard the sound of YHWH God walking about in the garden in the day's breeze. The man and his wife hid from YHWH God among the trees of the garden.

Previous v0.4.7

They heard the sound of YHWH God walking about in the garden in the day's breeze. The man and his wife hid from YHWH God among the trees of the garden.

Previous v0.4.8

They heard the sound of YHWH God walking about in the garden in the day's breeze. The man and his wife hid from YHWH God among the trees of the garden.

Previous v0.4.9

They heard the sound of YHWH God walking about in the garden in the day's breeze. The man and his wife hid from YHWH God among the trees of the garden.

## 9 · HYB.GEN.003.009

Hebrew display (MT/WLC): וַיִּקְרָ֛א יְהוָ֥ה אֱלֹהִ֖ים אֶל־הָֽאָדָ֑ם וַיֹּ֥אמֶר ל֖וֹ אַיֶּֽכָּה׃

YHWH God called to the man and said to him, “Where are you?”

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.9

### Current best selected translation

관사 있는 האדם을 그 사람으로, 단수 남성 대상의 질문을 네가 어디 있느냐로 현재 옮긴다.

#### gemini-3.8-flash-medium

And YHWH God called to the man and said to him, “Where are you?”

Final opinion (Korean original): 정관사가 결합된 'הָאָדָם'을 '그 사람/the man/el hombre'이라는 보통명사로 번역한 선정본은 충실합니다. 다만 주석 기술 시 '정관사가 붙었으므로 고유명사 용법이 절대적으로 불가능하다'는 보편 문법 규칙을 주장해서는 안 되며, 후기 셈어 및 본문 전승에서 정관사 형태가 고유명사로 이행해 가는 과도기적 용례 가능성도 열어두어야 합니다. 'אַיֶּכָּה'의 2인칭 단수 남성 호격은 남성 당사자를 특정하여 부르는 구조를 가감 없이 보존하고 있습니다.

#### gpt-6.1-sol

YHWH God called to the man and said to him, “Where are you?”

Final opinion (Korean original): 관사 있는 האדם을 그 사람으로, 단수 남성 대상의 질문을 네가 어디 있느냐로 현재 옮긴다. 아담이라는 이름으로 옮기는 대안도 있다. 관사 때문에 고유명사가 항상 불가능하다는 보편 규칙을 주장하지 않는다. 질문만으로 화자의 지식·법정 의도를 확정하지 않는다.

Counterargument (Korean): 아담이라는 이름으로 옮기는 대안도 있다. 관사 때문에 고유명사가 항상 불가능하다는 보편 규칙을 주장하지 않는다. 질문만으로 화자의 지식·법정 의도를 확정하지 않는다.

Previous v0.4.10

YHWH God called to the man and said to him, “Where are you?”

Previous v0.4.6

YHWH God called to the man and said to him, “Where are you?”

Previous v0.4.7

YHWH God called to the man and said to him, “Where are you?”

Previous v0.4.8

YHWH God called to the man and said to him, “Where are you?”

Previous v0.4.9

YHWH God called to the man and said to him, “Where are you?”

## 10 · HYB.GEN.003.010

Hebrew display (MT/WLC): וַיֹּ֕אמֶר אֶת־קֹלְךָ֥ שָׁמַ֖עְתִּי בַּגָּ֑ן וָאִירָ֛א כִּֽי־עֵירֹ֥ם אָנֹ֖כִי וָאֵחָבֵֽא׃

He said, “I heard the sound of you in the garden, and I was afraid because I was naked, so I hid.”

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.10

### Current best selected translation

화자의 일인칭 듣기·두려움·벌거벗음·숨음을 보존한다. 영어 sound of you는 소리/음성을 열어 두고 스페인어 Te oí는 청각 사건을 자연스럽게 표현하는 현재 선택이다.

#### claude-opus-5-5

He said, “I heard the sound of you in the garden, and I was afraid because I am naked, and I hid myself.”

Final opinion (Korean original): 채택 후보 초안으로 제출한다. קוֹל의 소리/음성 선택과 하나님에 대한 한국어 2인칭 표현은 편집 규약에 따라 결정할 쟁점이다. 두려움과 벗음 외의 죄책·연대기는 덧붙이지 않았다.

#### gemini-3.8-flash-medium

And he said, “I heard the sound of you in the garden, and I was afraid because I was naked; and I hid myself.”

Final opinion (Korean original): 스페인어 'Te oí'(당신을 들었다)는 히브리어 'אֶת־קֹלְךָ שָׁמַעְתִּי'의 'קוֹל'을 명시적 명사로 드러내지 않고 목적어 대명사로 흡수한 스페인어 관용적 표현으로서 자연스럽고 충분히 타당합니다. 반면 영어의 'sound of you'는 소리와 음성의 이중성을 보존하려는 축자적 배려를 잘 보여줍니다. 화자의 진술('내가 벗었으므로 두려워하여 숨었다')에 심리적 죄책감이나 회개의 단계, 시간적 심리 분석을 투영하지 않고 본문 그대로의 원인-결과 진술을 유지한 점이 적합합니다.

#### gpt-6.1-sol

He said, “I heard the sound of you in the garden, and I was afraid because I was naked, so I hid.”

Final opinion (Korean original): 화자의 일인칭 듣기·두려움·벌거벗음·숨음을 보존한다. 영어 sound of you는 소리/음성을 열어 두고 스페인어 Te oí는 청각 사건을 자연스럽게 표현하는 현재 선택이다. 스페인어는 קול 명사를 암시적으로 처리한다. 당신의 음성/your voice/tu voz도 대안이다. 히브리어 무동사절을 현재의 벌거벗음으로 읽는 대안과 영어·스페인어 과거 시제의 문맥상 조응을 구분하며 죄책감·회개·옷의 효과나 시간표를 보충하지 않는다.

Counterargument (Korean): 스페인어는 קול 명사를 암시적으로 처리한다. 당신의 음성/your voice/tu voz도 대안이다. 히브리어 무동사절을 현재의 벌거벗음으로 읽는 대안과 영어·스페인어 과거 시제의 문맥상 조응을 구분하며 죄책감·회개·옷의 효과나 시간표를 보충하지 않는다.

Previous v0.4.10

He said, “I heard the sound of you in the garden, and I was afraid because I was naked, so I hid.”

Previous v0.4.6

He said, “I heard the sound of you in the garden, and I was afraid because I was naked, so I hid.”

Previous v0.4.7

He said, “I heard the sound of you in the garden, and I was afraid because I was naked, so I hid.”

Previous v0.4.8

He said, “I heard the sound of you in the garden, and I was afraid because I was naked, so I hid.”

Previous v0.4.9

He said, “I heard the sound of you in the garden, and I was afraid because I was naked, so I hid.”

## 11 · HYB.GEN.003.011

Hebrew display (MT/WLC): וַיֹּ֕אמֶר מִ֚י הִגִּ֣יד לְךָ֔ כִּ֥י עֵירֹ֖ם אָ֑תָּה הֲמִן־הָעֵ֗ץ אֲשֶׁ֧ר צִוִּיתִ֛יךָ לְבִלְתִּ֥י אֲכָל־מִמֶּ֖נּוּ אָכָֽלְתָּ׃

He said, “Who told you that you were naked? Have you eaten from the tree from which I commanded you not to eat?”

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.11

### Current best selected translation

벌거벗음의 정보 출처와 금지한 나무에서 먹었는지를 두 질문으로 옮긴다. 부정은 먹지 말라는 명령 내용에 속하며 주절 질문 자체의 부정이 아니다.

#### gemini-3.8-flash-medium

And he said, “Who told you that you were naked? Have you eaten from the tree from which I commanded you not to eat?”

Final opinion (Korean original): 선택된 3개 언어 번역은 원문의 2인칭 남성 단수 대명사 및 접미사, 그리고 부정 명령의 내용(לְבִלְתִּי אֲכָל)을 문맥에 맞게 정확히 살렸습니다. 이전 응답에서 לְךָ(le-kha)를 '대격(accusative)'으로 표기했던 설명은 중대한 문법적 과오이며, 전치사 lamed가 결합된 '여격(dative/간접목적어)'으로 명확히 정정합니다. 부정 의문 형식(הֲמִן־הָעֵץ... אָכָלְתָּ)은 정황 확인과 추궁의 긴장을 잘 보존하고 있습니다.

#### gpt-6.1-sol

He said, “Who told you that you were naked? Have you eaten from the tree from which I commanded you not to eat?”

Final opinion (Korean original): 벌거벗음의 정보 출처와 금지한 나무에서 먹었는지를 두 질문으로 옮긴다. 부정은 먹지 말라는 명령 내용에 속하며 주절 질문 자체의 부정이 아니다. ממנו의 수입 1cp 형태 태그는 보존하고 문맥상 그 나무에서로 옮긴다. לך는 네게라는 여격이다. 질문만으로 화자의 지식·법정 의도·질책의 정도를 확정하지 않는다.

Counterargument (Korean): ממנו의 수입 1cp 형태 태그는 보존하고 문맥상 그 나무에서로 옮긴다. לך는 네게라는 여격이다. 질문만으로 화자의 지식·법정 의도·질책의 정도를 확정하지 않는다.

Previous v0.4.10

He said, “Who told you that you were naked? Have you eaten from the tree from which I commanded you not to eat?”

Previous v0.4.7

He said, “Who told you that you were naked? Have you eaten from the tree from which I commanded you not to eat?”

Previous v0.4.8

He said, “Who told you that you were naked? Have you eaten from the tree from which I commanded you not to eat?”

Previous v0.4.9

He said, “Who told you that you were naked? Have you eaten from the tree from which I commanded you not to eat?”

## 12 · HYB.GEN.003.012

Hebrew display (MT/WLC): וַיֹּ֖אמֶר הָֽאָדָ֑ם הָֽאִשָּׁה֙ אֲשֶׁ֣ר נָתַ֣תָּה עִמָּדִ֔י הִ֛וא נָֽתְנָה־לִּ֥י מִן־הָעֵ֖ץ וָאֹכֵֽל׃

The man said, “The woman whom you gave to be with me—she gave me some from the tree, and I ate.”

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.12

### Current best selected translation

당신이 주신/그 여자가 주었다의 반복과 강조적 그녀, 내가 먹었다를 보존하고 한국어 연결은 주었고로 다듬었다.

#### claude-opus-5-5

And the man said, “The woman whom you gave to be with me—she gave me from the tree, and I ate.”

Final opinion (Korean original): 미채택 초안으로 제출한다. 그 사람이 하나님이 주신 일과 여자가 준 일을 언급하는 말은 그대로 살리고, 그의 동기는 판정하지 않는다.

#### gemini-3.8-flash-medium

And the man said, “The woman whom you placed with me, she gave to me from the tree, and I ate.”

Final opinion (Korean original): 선택본은 '주셨다(נָתַתָּה)'와 '주었다(נָתְנָה)'의 동사 반복 및 3인칭 여성 단수 강조 대명사 'הִוא(그 여자가 / she / ella)'를 명확히 보존했습니다. 한국어 번역의 '그 나무에서 난 것을'은 히브리어 'מִן־הָעֵץ' 뒤에 생략된 목적어를 우리말 어법에 맞게 보충한 '명시적 생략 보충(disclosed ellipsis expansion)'으로 적절하며, 영어의 'some from the tree' 역시 같은 취지를 잘 살렸습니다. 남자의 진술에 대해 주관적 죄책 회피나 심리적 책임 전가의 동기를 본문 외적으로 단정하지 않고 객관적 진술 형태로 유지한 점이 타당합니다.

#### gpt-6.1-sol

The man said, “The woman whom you gave to be with me—she gave me some from the tree, and I ate.”

Final opinion (Korean original): 당신이 주신/그 여자가 주었다의 반복과 강조적 그녀, 내가 먹었다를 보존하고 한국어 연결은 주었고로 다듬었다. 함께 있도록은 עם의 관계를 자연스럽게 푼 선택이며 목적 해석이 포함된다. 나무에서 난 것은 생략된 먹을 것을 푼 편집적 보충이다. 책임 전가·원망은 담화 해석으로 가능하지만 화자의 동기를 번역에 확정하지 않는다.

Counterargument (Korean): 함께 있도록은 עם의 관계를 자연스럽게 푼 선택이며 목적 해석이 포함된다. 나무에서 난 것은 생략된 먹을 것을 푼 편집적 보충이다. 책임 전가·원망은 담화 해석으로 가능하지만 화자의 동기를 번역에 확정하지 않는다.

Previous v0.4.10

The man said, “The woman whom you gave to be with me—she gave me some from the tree, and I ate.”

Previous v0.4.7

The man said, “The woman whom you gave to be with me—she gave me some from the tree, and I ate.”

Previous v0.4.8

The man said, “The woman whom you gave to be with me—she gave me some from the tree, and I ate.”

Previous v0.4.9

The man said, “The woman whom you gave to be with me—she gave me some from the tree, and I ate.”

## 13 · HYB.GEN.003.013

Hebrew display (MT/WLC): וַיֹּ֨אמֶר יְהוָ֧ה אֱלֹהִ֛ים לָאִשָּׁ֖ה מַה־זֹּ֣את עָשִׂ֑ית וַתֹּ֨אמֶר֙ הָֽאִשָּׁ֔ה הַנָּחָ֥שׁ הִשִּׁיאַ֖נִי וָאֹכֵֽל׃

YHWH God said to the woman, “What is this you have done?” The woman said, “The serpent deceived me, and I ate.”

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.13

### Current best selected translation

무엇을 했느냐는 질문과 뱀이 속였다는 여자의 진술 및 내가 먹었다를 화자별로 보존한다.

#### gemini-3.8-flash-medium

And Yahweh God said to the woman, “What is this that you have done?” And the woman said, “The serpent deceived me, and I ate.”

Final opinion (Korean original): 동사 הִשִּׁיאַנִי(Hifil 완료 3인칭 남성 단수)를 '속였다/deceived/engañó'로 명료하게 번역하였고, 여자의 2인칭 여성 단수 형태(עָשִׂית)를 충실히 반영했습니다. 텍스트에 나타나지 않는 사탄이나 초자연적 악마의 명칭을 본문에 삽입하지 않고 '그 뱀(הַנָּחָשׁ)'의 기만 행위로 한정한 처리가 엄밀합니다.

#### gpt-6.1-sol

YHWH God said to the woman, “What is this you have done?” The woman said, “The serpent deceived me, and I ate.”

Final opinion (Korean original): 무엇을 했느냐는 질문과 뱀이 속였다는 여자의 진술 및 내가 먹었다를 화자별로 보존한다. 속여서라는 한국어 연결은 자연스러운 관계 표현이다. 유혹하다도 대안이지만 사탄·강제·무죄·회개를 본문에 보충하지 않는다.

Counterargument (Korean): 속여서라는 한국어 연결은 자연스러운 관계 표현이다. 유혹하다도 대안이지만 사탄·강제·무죄·회개를 본문에 보충하지 않는다.

Previous v0.4.10

YHWH God said to the woman, “What is this you have done?” The woman said, “The serpent deceived me, and I ate.”

Previous v0.4.7

YHWH God said to the woman, “What is this you have done?” The woman said, “The serpent deceived me, and I ate.”

Previous v0.4.8

YHWH God said to the woman, “What is this you have done?” The woman said, “The serpent deceived me, and I ate.”

Previous v0.4.9

YHWH God said to the woman, “What is this you have done?” The woman said, “The serpent deceived me, and I ate.”

## 14 · HYB.GEN.003.014

Hebrew display (MT/WLC): וַיֹּאמֶר֩ יְהֹוָ֨ה אֱלֹהִ֥ים ׀ אֶֽל־הַנָּחָשׁ֮ כִּ֣י עָשִׂ֣יתָ זֹּאת֒ אָר֤וּר אַתָּה֙ מִכָּל־הַבְּהֵמָ֔ה וּמִכֹּ֖ל חַיַּ֣ת הַשָּׂדֶ֑ה עַל־גְּחֹנְךָ֣ תֵלֵ֔ךְ וְעָפָ֥ר תֹּאכַ֖ל כָּל־יְמֵ֥י חַיֶּֽיךָ׃

YHWH God said to the serpent, “Because you have done this, cursed are you above all livestock and all wild animals. On your belly you will go, and dust you will eat all the days of your life.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.14

### Current best selected translation

מכל의 비교를 현재 선택하여 모든 집짐승과 들짐승보다 더 저주받았다는 선언으로 옮기고, 배로 다님·평생 흙 먹음을 보존한다.

#### claude-opus-5-5

And the LORD God said to the serpent, “Because you have done this, cursed are you from among all the livestock and from among every animal of the field. On your belly you shall go, and dust you shall eat all the days of your life.

Final opinion (Korean original): 미채택 초안으로 제출한다. 저주 선언의 범위는 본문에 나열된 짐승 무리 안에서만 표현했다. 배와 흙에 관한 구절은 직역하고, 몸의 구조에 관한 추론은 배제한다.

#### gemini-3.8-flash-medium

And Yahweh God said to the serpent, “Because you have done this, cursed are you above all livestock and above all beasts of the field; upon your belly you shall go, and dust you shall eat all the days of your life.”

Final opinion (Korean original): 이전 응답에서 히브리어 원문 철자에 한글 '이'가 삽입되었던 오기(`חַיֶּֽ이ךָ` → `חַיֶּֽיךָ`)를 명확히 바로잡습니다. BDB 779에 근거한 수동분사 저주 양식(אָרוּר אַתָּה)을 충실히 반영하였으며, 전치사 מִן(מִכָּל...)에 대해 비교급 해석('~보다 더 / above all / más que')을 채택한 편집적 선택은 타당합니다(구별/분리의 의미인 '~가운데/among' 역시 동등한 번역 대안으로 공존함). 뱀의 다리 상실 등 입증되지 않은 고대 생물 해부학적 추정이나, '흙먼지를 먹는다'는 표현을 순수하게 은유적·상징적 굴욕으로만 제한하는 이분법적 단정을 배제하였습니다. 또한 14~15절은 뱀을 향한 단일한 신적 선고이므로 14절의 인용 부호는 닫지 않고 15절 끝에서 닫는 것이 정확하며, 16절(여자) 및 17~19절(남자)로 청자가 완전히 전환되므로 같은 연설이 19절까지 이어진다고 주장해서는 안 됩니다.

#### gpt-6.1-sol

YHWH God said to the serpent, “Because you have done this, cursed are you above all livestock and all wild animals. On your belly you will go, and dust you will eat all the days of your life.

Final opinion (Korean original): מכל의 비교를 현재 선택하여 모든 집짐승과 들짐승보다 더 저주받았다는 선언으로 옮기고, 배로 다님·평생 흙 먹음을 보존한다. 가운데서·구별되어라는 범위/분리 독법도 있다. 비교가 다른 모든 동물의 별도 저주를 확증하지 않는다. 이전 다리·해부학 변화나 흙 먹기의 문자적/상징적 의미를 확정하지 않는다. 14–15절을 뱀에게 하는 발화로 묶는다.

Counterargument (Korean): 가운데서·구별되어라는 범위/분리 독법도 있다. 비교가 다른 모든 동물의 별도 저주를 확증하지 않는다. 이전 다리·해부학 변화나 흙 먹기의 문자적/상징적 의미를 확정하지 않는다. 14–15절을 뱀에게 하는 발화로 묶는다.

Previous v0.4.10

YHWH God said to the serpent, “Because you have done this, cursed are you above all livestock and all wild animals. On your belly you will go, and dust you will eat all the days of your life.

Previous v0.4.7

YHWH God said to the serpent, “Because you have done this, cursed are you above all livestock and all wild animals. On your belly you will go, and dust you will eat all the days of your life.

Previous v0.4.8

YHWH God said to the serpent, “Because you have done this, cursed are you above all livestock and all wild animals. On your belly you will go, and dust you will eat all the days of your life.

Previous v0.4.9

YHWH God said to the serpent, “Because you have done this, cursed are you above all livestock and all wild animals. On your belly you will go, and dust you will eat all the days of your life.

## 15 · HYB.GEN.003.015

Hebrew display (MT/WLC): וְאֵיבָ֣ה ׀ אָשִׁ֗ית בֵּֽינְךָ֙ וּבֵ֣ין הָֽאִשָּׁ֔ה וּבֵ֥ין זַרְעֲךָ֖ וּבֵ֣ין זַרְעָ֑הּ ה֚וּא יְשׁוּפְךָ֣ רֹ֔אשׁ וְאַתָּ֖ה תְּשׁוּפֶ֥נּוּ עָקֵֽב׃

I will put enmity between you and the woman, and between your offspring and her offspring. That offspring will strike you on the head, and you will strike that offspring on the heel.”

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.15

### Current best selected translation

적의와 양쪽 후손을 반복하고 הוא를 앞의 여자의 후손으로 현재 읽는다. 두 שוף는 치다/strike/golpear로 맞춰 어휘 반복과 머리·발꿈치의 대비를 보존한다.

#### claude-opus-5-5

I will put enmity between you and the woman, and between your offspring and her offspring; it shall strike you on the head, and you shall strike it on the heel.

Final opinion (Korean original): 미채택 초안으로 제출한다. 미래 시제, 집합적 후손, 문법적 성 일치, 같은 동사의 대칭이라는 본문 근거를 보존하고, 특정 인물이나 신학 체계는 번역에 들이지 않는다.

#### gemini-3.8-flash-medium

And I will put enmity between you and the woman, and between your offspring and her offspring; he/they shall strike your head, and you shall strike his/their heel.”

Final opinion (Korean original): 뱀을 향한 신적 담화는 본 절(15절) 끝에서 마침 따옴표로 공식 종료됩니다. BDB 7779에 따른 שׁוּף(shuf)는 양 문장에 동일하게 사용되었으며, 현재 번역은 두 문장 모두 동일한 동사('치고/칠 것이다', strike/strike, golpeará/golpearás)로 처리하여 구문적 대칭성을 보존한 편집적 결정을 따랐습니다. 다만 동일 동사라 하여 양측의 부상 수위가 동일해야 한다는 절대적 증거는 없으며, 타격 부위(머리 vs 발꿈치) 및 문맥에 따른 차등적 동사 번역 역시 유효한 대안으로 존중됩니다. 명사 זֶרַע(BDB 2233)는 본문에서 집합적 후손의 용례(section 4)로 쓰였으나 다른 문맥에서 개별 자녀를 가리키기도 하므로, 문법적 남성 단수 대명사 הוּא가 개별 지시 대상을 원천적으로 배제한다고 과장해서는 안 됩니다. 스페인어 번역의 여성형 'Esa descendencia / la'는 스페인어 여성 명사 descendencia와의 문법적 성 일치에 따른 자연스러운 언어적 결과이며, 히브리어 주어가 여성임을 의미하지 않음을 각주에서 명시합니다. 특정 사본 확인 없는 막연한 칠십인역/불가타 통칭 주장을 지양하고, 예수/마리아/사탄의 명시적 본문 삽입 없이 뱀과 여자의 족속 간 지속적인 적대 관계로 서술한 현재 선택본을 확정합니다.

#### gpt-6.1-sol

I will put enmity between you and the woman, and between your offspring and her offspring. That offspring will strike you on the head, and you will strike that offspring on the heel.”

Final opinion (Korean original): 적의와 양쪽 후손을 반복하고 הוא를 앞의 여자의 후손으로 현재 읽는다. 두 שוף는 치다/strike/golpear로 맞춰 어휘 반복과 머리·발꿈치의 대비를 보존한다. BDB는 bruise와 집합적 후손 용례를 제시한다. 상하게 하다·으스러뜨리다·노리다와 문맥별 다른 동사도 재검토할 수 있다. 같은 동사가 같은 피해 정도나 특정 승패를 증명하지 않는다. 남성 단수와 집합명사는 특정 한 인물을 자동 확정하거나 불가능하게 하지 않는다. 스페인어 여성 일치는 원문의 여성 주어 주장이 아니며 후대 특정 인물의 이름을 보충하지 않는다.

Counterargument (Korean): BDB는 bruise와 집합적 후손 용례를 제시한다. 상하게 하다·으스러뜨리다·노리다와 문맥별 다른 동사도 재검토할 수 있다. 같은 동사가 같은 피해 정도나 특정 승패를 증명하지 않는다. 남성 단수와 집합명사는 특정 한 인물을 자동 확정하거나 불가능하게 하지 않는다. 스페인어 여성 일치는 원문의 여성 주어 주장이 아니며 후대 특정 인물의 이름을 보충하지 않는다.

Previous v0.4.10

I will put enmity between you and the woman, and between your offspring and her offspring. That offspring will strike you on the head, and you will strike that offspring on the heel.”

Previous v0.4.7

I will put enmity between you and the woman, and between your offspring and her offspring. That offspring will strike you on the head, and you will strike that offspring on the heel.”

Previous v0.4.8

I will put enmity between you and the woman, and between your offspring and her offspring. That offspring will strike you on the head, and you will strike that offspring on the heel.”

Previous v0.4.9

I will put enmity between you and the woman, and between your offspring and her offspring. That offspring will strike you on the head, and you will strike that offspring on the heel.”

## 16 · HYB.GEN.003.016

Hebrew display (MT/WLC): אֶֽל־הָאִשָּׁ֣ה אָמַ֗ר הַרְבָּ֤ה אַרְבֶּה֙ עִצְּבוֹנֵ֣ךְ וְהֵֽרֹנֵ֔ךְ בְּעֶ֖צֶב תֵּֽלְדִ֣י בָנִ֑ים וְאֶל־אִישֵׁךְ֙ תְּשׁ֣וּקָתֵ֔ךְ וְה֖וּא יִמְשָׁל־בָּֽךְ׃

To the woman he said, “I will greatly increase your pain in pregnancy. In pain you will bear children. Your desire will be toward your husband, and he will rule over you.”

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.16

### Current best selected translation

늘리다의 반복을 크게로 옮기고 고통과 임신의 두 명사를 현재는 임신의 고통이라는 결합 독법으로 읽는다. 갈망의 방향과 다스릴 것이다라는 예고를 보존한다.

#### claude-opus-5-5

To the woman he said, “I will greatly increase your pain and your pregnancy; in pain you will bear children. Your desire will be toward your husband, and he will rule over you.”

Final opinion (Korean original): 채택되지 않은 모델 초안이다. 강조 구문은 반영했고, 두 명사는 유지하고 중언법은 각주로 돌렸다. 갈망은 방향만 중립적으로 번역했고, 다스림은 명령이 아닌 결과 서술로 보았다. 편집 채택 전에 다른 모델 번역과 비교하고 인간 검토를 거쳐야 한다.

#### gemini-3.8-flash-medium

To the woman He said, “I will greatly multiply your toil and your conception; in pain you shall bear children. Your desire shall be for your husband, and he shall rule over you.”

Final opinion (Korean original): 주인님, 제안 번역 ‘임신의 고통’은 접속된 두 명사 ‘עִצְּבוֹנֵךְ וְהֵרֹנֵךְ’(BDB 6093 고통/수고, BDB 2032 수태/임신)을 중언법(hendiadys)으로 처리한 독법입니다. 그러나 이는 문자적 병렬인 ‘네 고통과 네 임신’이라는 대안적 번역 가능성을 배제할 수 없으며, 임신의 빈도나 특정 통사론을 필연적으로 단정하지 않습니다. 사전(BDB)의 정의가 중언법 채택이나 모든 신학적 쟁점을 홀로 입증하지는 못합니다. ‘הַרְבָּה אַרְבֶּה’의 부정사 절대형은 양적·수치적 배가가 아닌 관습적 강조(GKC 113n, o)를 나타냅니다. ‘תְּשׁוּקָתֵךְ’(BDB 8669 갈망)과 ‘יִמְשָׁל־בָּךְ’(BDB 4910 그가 너를 다스릴 것이다)의 미완료형은 형태론상 명령형 규범(imperative prescription)이 아닌 진술이지만, 문법 형태론만으로 규범 신학이나 타락으로 인한 왜곡된 권력 구조를 문법적으로 입증된 사실로 규정할 수는 없습니다. 인용 부호는 현대 편집적 요소입니다.

#### gpt-6.1-sol

To the woman he said, “I will greatly increase your pain and your pregnancies. In pain you will bear children. Your desire will be toward your husband, and he will rule over you.”

Final opinion (Korean original): 늘리다의 반복을 크게로 옮기고 고통과 임신의 두 명사를 현재는 임신의 고통이라는 결합 독법으로 읽는다. 갈망의 방향과 다스릴 것이다라는 예고를 보존한다. 두 명사를 고통과 임신으로 병렬 번역하는 GPT 초기·Claude 초안과 기존 클라우드 대안을 보존한다. 임신 횟수 증가나 중언법을 확정하지 않는다. 갈망을 오직 지배욕·성욕·적의로 좁히지 않는다. 문맥상 미래 진술을 선택하며 미완료 형태만으로 모든 규범적 신학을 판정하지 않는다.

Counterargument (Korean): 두 명사를 고통과 임신으로 병렬 번역하는 GPT 초기·Claude 초안과 기존 클라우드 대안을 보존한다. 임신 횟수 증가나 중언법을 확정하지 않는다. 갈망을 오직 지배욕·성욕·적의로 좁히지 않는다. 문맥상 미래 진술을 선택하며 미완료 형태만으로 모든 규범적 신학을 판정하지 않는다.

Previous v0.4.10

To the woman he said, “I will greatly increase your pain in pregnancy. In pain you will bear children. Your desire will be toward your husband, and he will rule over you.”

Previous v0.4.8

To the woman he said, “I will greatly increase your pain in pregnancy. In pain you will bear children. Your desire will be toward your husband, and he will rule over you.”

Previous v0.4.9

To the woman he said, “I will greatly increase your pain in pregnancy. In pain you will bear children. Your desire will be toward your husband, and he will rule over you.”

## 17 · HYB.GEN.003.017

Hebrew display (MT/WLC): וּלְאָדָ֣ם אָמַ֗ר כִּֽי־שָׁמַעְתָּ֮ לְק֣וֹל אִשְׁתֶּךָ֒ וַתֹּ֨אכַל֙ מִן־הָעֵ֔ץ אֲשֶׁ֤ר צִוִּיתִ֨יךָ֙ לֵאמֹ֔ר לֹ֥א תֹאכַ֖ל מִמֶּ֑נּוּ אֲרוּרָ֤ה הָֽאֲדָמָה֙ בַּֽעֲבוּרֶ֔ךָ בְּעִצָּבוֹן֙ תֹּֽאכֲלֶ֔נָּה כֹּ֖ל יְמֵ֥י חַיֶּֽיךָ׃

To Adam he said, “Because you listened to your wife and ate from the tree about which I commanded you, ‘You shall not eat from it,’ cursed is the ground because of you. Through painful toil you will eat from it all the days of your life.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.17

### Current best selected translation

아담/Adán이라는 현재 선택과 금지 위반의 이유절, 직접 저주의 주어인 땅, 평생 고된 수고를 보존한다.

#### claude-opus-5-5

And to Adam he said, “Because you listened to the voice of your wife and ate from the tree about which I commanded you, ‘You shall not eat from it,’ cursed is the ground because of you; in painful toil you will eat of it all the days of your life.

Final opinion (Korean original): 채택되지 않은 모델 초안이다. ‘아담’은 각주와 함께 사용했고, 금지 인용은 보존했으며, ‘너 때문에 땅이 저주받음’과 ‘평생의 고통스러운 수고’를 반영했다. מִמֶּנּוּ의 1cp 태그는 데이터를 보존한 채 오류 가능 분석으로 표시했다. 악센트 메모는 성경 본문이 아닌 메타데이터이다.

#### gemini-3.8-flash-medium

And to Adam He said, “Because you listened to the voice of your wife and ate from the tree about which I commanded you, saying, ‘You shall not eat of it,’ cursed is the ground because of you; in painful toil you shall eat of it all the days of your life.”

Final opinion (Korean original): 주인님, ‘וּלְאָדָם’은 관사가 없는 형태이므로 고유명사 ‘아담에게’뿐 아니라 ‘사람에게’로도 번역될 수 있습니다. 본문 내 ‘מִמֶּנּוּ’는 OSHB 태깅에 1인칭 복수(HR/Sp1cp)로 등록되어 있으나, GKC 103i에 제시된 바와 같이 ‘מִמֶּנּוּ’는 1인칭 복수(우리에게서)와 3인칭 남성 단수(그것에게서)의 완전한 동형이의(homography) 형태입니다. 따라서 기계적 오류로 단정하지 않고 기존 태깅 코드를 보존하되, 문맥상 선행사인 ‘그 나무’(הָעֵץ, 3ms)를 가리키는 것으로 설명해야 합니다. ‘너 때문에 땅이 저주받았다’는 진술에서 무죄한 땅이 활력을 상실했다거나 온 피조물이 탄식한다는 해석은 문법적으로 증명된 사실이 아닌 신학적 해석입니다. 17절 끝의 닫는 따옴표 부재는 19절까지 이어지는 신적 담화의 편집적 처리를 보여줍니다.

#### gpt-6.1-sol

To Adam he said, “Because you listened to your wife and ate from the tree about which I commanded you, ‘You shall not eat from it,’ cursed is the ground because of you. Through painful toil you will eat from it all the days of your life.

Final opinion (Korean original): 아담/Adán이라는 현재 선택과 금지 위반의 이유절, 직접 저주의 주어인 땅, 평생 고된 수고를 보존한다. 사람이라는 번역도 가능하다. 땅에서 먹을 것을 얻는다는 것은 먹다의 여성 목적어를 자연스럽게 푼 것이다. ממנו는1cp/3ms 동형이며 수입1cp 분석을 보존하고 문맥상 나무에서로 읽는다. 악센트 비교 주석은 이미 지원되는 별도 메타데이터이며 실물 BHS/L 대조 결과로 사칭하지 않는다.

Counterargument (Korean): 사람이라는 번역도 가능하다. 땅에서 먹을 것을 얻는다는 것은 먹다의 여성 목적어를 자연스럽게 푼 것이다. ממנו는1cp/3ms 동형이며 수입1cp 분석을 보존하고 문맥상 나무에서로 읽는다. 악센트 비교 주석은 이미 지원되는 별도 메타데이터이며 실물 BHS/L 대조 결과로 사칭하지 않는다.

Previous v0.4.10

To Adam he said, “Because you listened to your wife and ate from the tree about which I commanded you, ‘You shall not eat from it,’ cursed is the ground because of you. Through painful toil you will eat from it all the days of your life.

Previous v0.4.8

To Adam he said, “Because you listened to your wife and ate from the tree about which I commanded you, ‘You shall not eat from it,’ cursed is the ground because of you. Through painful toil you will eat from it all the days of your life.

Previous v0.4.9

To Adam he said, “Because you listened to your wife and ate from the tree about which I commanded you, ‘You shall not eat from it,’ cursed is the ground because of you. Through painful toil you will eat from it all the days of your life.

## 18 · HYB.GEN.003.018

Hebrew display (MT/WLC): וְק֥וֹץ וְדַרְדַּ֖ר תַּצְמִ֣יחַֽ לָ֑ךְ וְאָכַלְתָּ֖ אֶת־עֵ֥שֶׂב הַשָּׂדֶֽה׃

It will bring forth thorns and thistles for you, and you will eat the plants of the field.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.18

### Current best selected translation

앞 절의 땅을 주어로 명시하고 가시·엉겅퀴 및 들의 식물을 옮긴다.

#### gemini-3.8-flash-medium

Thorns and thistles it shall bring forth for you, and you shall eat the plants of the field.

Final opinion (Korean original): 주인님, ‘תַּצְמִיחַ לָךְ’에서 ‘לָךְ’는 제공된 태깅에 여성 2인칭(HR/Sp2fs)으로 기록되어 있으나, GKC 103f 표에 기술된 대로 남성 2인칭 대명사 접미사 ‘לְךָ’(le-kha)가 휴지형(pause)에서 ‘לָךְ’(la-kh)으로 실현된 것입니다. 따라서 기계적 오류로 추정하지 않고 원 태깅을 유지하면서 남성(아담)에 대한 휴지형 용례로 문맥을 설명해야 합니다. ‘עֵשֶׂב הַשָּׂדֶה’(들의 식물)는 배타적으로 인간의 손으로 경작된 농작물만을 의미하거나 생물학적으로 완전히 새로운 식물의 등장을 문법적으로 강제하지 않습니다.

#### gpt-6.1-sol

It will bring forth thorns and thistles for you, and you will eat the plants of the field.

Final opinion (Korean original): 앞 절의 땅을 주어로 명시하고 가시·엉겅퀴 및 들의 식물을 옮긴다. 특정 식물 종·농작물에만 한정하거나 식물이 이때 처음 생겼다고 단정하지 않는다. לך의 수입2fs 태그는 보존하고 GKC103f의 남성 휴지형과 남자 대상 담화에 따라 너로 옮긴다.

Counterargument (Korean): 특정 식물 종·농작물에만 한정하거나 식물이 이때 처음 생겼다고 단정하지 않는다. לך의 수입2fs 태그는 보존하고 GKC103f의 남성 휴지형과 남자 대상 담화에 따라 너로 옮긴다.

Previous v0.4.10

It will bring forth thorns and thistles for you, and you will eat the plants of the field.

Previous v0.4.8

It will bring forth thorns and thistles for you, and you will eat the plants of the field.

Previous v0.4.9

It will bring forth thorns and thistles for you, and you will eat the plants of the field.

## 19 · HYB.GEN.003.019

Hebrew display (MT/WLC): בְּזֵעַ֤ת אַפֶּ֨יךָ֙ תֹּ֣אכַל לֶ֔חֶם עַ֤ד שֽׁוּבְךָ֙ אֶל־הָ֣אֲדָמָ֔ה כִּ֥י מִמֶּ֖נָּה לֻקָּ֑חְתָּ כִּֽי־עָפָ֣ר אַ֔תָּה וְאֶל־עָפָ֖ר תָּשֽׁוּב׃

By the sweat of your face you will eat bread until you return to the ground, for from it you were taken. For you are dust, and to dust you will return.”

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.19

### Current best selected translation

얼굴의 땀, 빵, 땅으로 돌아감, 티끌로 돌아감의 반복을 살린다. 땅과 티끌의 서로 다른 어휘를 구별한다.

#### claude-opus-5-5

By the sweat of your face you will eat bread until you return to the ground, for from it you were taken; for dust you are, and to dust you will return.”

Final opinion (Korean original): 채택되지 않은 모델 초안이다. 얼굴의 땀, 양식, 땅/흙의 구분, ‘돌아감’의 수미상관을 보존했다. 기존 2:7 번역어와의 일관성은 편집 단계에서 확인해야 한다.

#### gemini-3.8-flash-medium

By the sweat of your face you shall eat bread until you return to the ground, for out of it you were taken; for you are dust, and to dust you shall return.”

Final opinion (Korean original): 주인님, ‘לֶחֶם’을 ‘빵’으로 번역한 것은 일상적 음식 및 양식을 포괄하는 어휘(food/bread)의 허용 가능한 선택이나, 포괄적 생계 수단으로서의 ‘식물/음식’이라는 폭넓은 의미를 배제하지 않도록 주석적 고려가 필요합니다. 본문은 ‘הָאֲדָמָה’(땅/흙, ground)와 ‘עָפָר’(티끌/먼지, dust)을 명확히 구분하고 있으며, 제안 번역이 이를 ‘땅’과 ‘티끌’로 변별한 것은 적절합니다. 17절에서 시작된 신적 선언의 인용 부호가 19절 끝에서 닫히는 것은 현대 편집자의 구두점 배치에 따릅니다.

#### gpt-6.1-sol

By the sweat of your face you will eat bread until you return to the ground, for from it you were taken. For you are dust, and to dust you will return.”

Final opinion (Korean original): 얼굴의 땀, 빵, 땅으로 돌아감, 티끌로 돌아감의 반복을 살린다. 땅과 티끌의 서로 다른 어휘를 구별한다. 양식/food와 흙먼지/흙도 대안이다. 기존2:7의 흙먼지와 이 절의 티끌은 같은 עפר를 옮긴 표현 차이이며 서로 다른 물질을 주장하지 않는다. 죽음 문맥을 넘어 영혼·부활·물질 구성·과학 이론을 본문에 보충하지 않는다.

Counterargument (Korean): 양식/food와 흙먼지/흙도 대안이다. 기존2:7의 흙먼지와 이 절의 티끌은 같은 עפר를 옮긴 표현 차이이며 서로 다른 물질을 주장하지 않는다. 죽음 문맥을 넘어 영혼·부활·물질 구성·과학 이론을 본문에 보충하지 않는다.

Previous v0.4.10

By the sweat of your face you will eat bread until you return to the ground, for from it you were taken. For you are dust, and to dust you will return.”

Previous v0.4.8

By the sweat of your face you will eat bread until you return to the ground, for from it you were taken. For you are dust, and to dust you will return.”

Previous v0.4.9

By the sweat of your face you will eat bread until you return to the ground, for from it you were taken. For you are dust, and to dust you will return.”

## 20 · HYB.GEN.003.020

Hebrew display (MT/WLC): וַיִּקְרָ֧א הָֽאָדָ֛ם שֵׁ֥ם אִשְׁתּ֖וֹ חַוָּ֑ה כִּ֛י הִ֥וא הָֽיְתָ֖ה אֵ֥ם כָּל־חָֽי׃

The man called his wife’s name Eve, because she was the mother of all the living.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.20

### Current best selected translation

하와/Eve/Eva의 이름과 살아 있는 이의 어머니라는 서술을 유지한다.

#### gemini-3.8-flash-medium

The man called his wife’s name Eve, because she was the mother of all living.

Final opinion (Korean original): 주인님, ‘הָאָדָם’은 정관사가 붙어 ‘그 사람’으로 정확히 번역되었습니다. ‘하와’(חַוָּה)와 ‘살아 있는 자’(חָי) 사이의 언어유희적 관계는 서사적·문학적 연결일 뿐, 역사언어학적으로 확정된 유일한 어원이나 이름 부여자의 신앙적·희망적 동기를 문법적으로 입증하는 사실이 아닙니다. ‘הָיְתָה’(Qal 완료 3fs)는 문자적으로 ‘~이었다’(was)를 뜻하며, 필연적으로 ‘~이 될 것이었다’(would become)는 목적론적 결과를 문법 형태로만 단정할 수 없으므로 제안본의 ‘어머니였기 때문이다’는 형태론에 충실합니다. ‘모든 산 자’(כָּל־חָי)는 생물학적 보편 전체라기보다 서사적으로 한정된(narratively scoped) 범위로 이해됩니다. 칠십인역(LXX) 초기 인용은 본 검토에서 별도 대조·검증되지 않았습니다.

#### gpt-6.1-sol

The man called his wife’s name Eve, because she was the mother of all the living.

Final opinion (Korean original): 하와/Eve/Eva의 이름과 살아 있는 이의 어머니라는 서술을 유지한다. 이름과 생명의 문학적 연결은 정확한 역사 어원 증명이 아니다. 어머니였다는 서술자의 시점과 앞으로 어머니가 됨이라는 독법을 열어 둔다. 이름 짓기의 믿음·희망·지배 동기를 확정하거나 모든 동식물의 생물학적 모계로 확대하지 않는다.

Counterargument (Korean): 이름과 생명의 문학적 연결은 정확한 역사 어원 증명이 아니다. 어머니였다는 서술자의 시점과 앞으로 어머니가 됨이라는 독법을 열어 둔다. 이름 짓기의 믿음·희망·지배 동기를 확정하거나 모든 동식물의 생물학적 모계로 확대하지 않는다.

Previous v0.4.10

The man called his wife’s name Eve, because she was the mother of all the living.

Previous v0.4.8

The man called his wife’s name Eve, because she was the mother of all the living.

Previous v0.4.9

The man called his wife’s name Eve, because she was the mother of all the living.

## 21 · HYB.GEN.003.021

Hebrew display (MT/WLC): וַיַּעַשׂ֩ יְהוָ֨ה אֱלֹהִ֜ים לְאָדָ֧ם וּלְאִשְׁתּ֛וֹ כָּתְנ֥וֹת ע֖וֹר וַיַּלְבִּשֵֽׁם׃

YHWH God made garments of skin for Adam and his wife and clothed them.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.21

### Current best selected translation

가죽으로 된 옷을 만들고 입힌 두 동작을 보존한다. 아담은 앞17절과 이어 현재 선택한다.

#### gemini-3.8-flash-medium

And Yahweh God made garments of skin for the man and for his wife, and clothed them.

Final opinion (Korean original): 주인님, 'לְאָדָם'을 17절과의 일관성을 위해 고유명사 '아담'으로 번역한 것은 형태소 원본 태그(lemma 120 일반명사)를 훼손하지 않는 선에서 타당한 문맥적 선택입니다. BDB 3801(כָּתְנוֹת)에 부합하는 '가죽옷(garments/tunics of skin)' 번역은 원문의 물리적 의복 형태를 정확히 담고 있습니다. 다만, 가죽옷을 인간을 향한 '보호·돌봄'이나 '내구적 대체물'로 이해하는 것은 본문 이면에 대한 신학적·문학적 해석 층위이므로 본문 자체의 객관적 진술과 구별해야 하며, 제사나 동물의 대속적 죽음 같은 후대 개념을 본문에 삽입하지 않은 절제된 번역을 지지합니다.

#### gpt-6.1-sol

YHWH God made garments of skin for Adam and his wife and clothed them.

Final opinion (Korean original): 가죽으로 된 옷을 만들고 입힌 두 동작을 보존한다. 아담은 앞17절과 이어 현재 선택한다. 사람도 대안이며 원출처 일반명사 분석은 보존한다. 튜닉/긴 속옷이라는 더 구체적인 옷 형식을 가죽옷으로 넓게 옮겼다. 동물 제사·최초 죽음·대속·제작 동기를 본문에 보충하지 않는다.

Counterargument (Korean): 사람도 대안이며 원출처 일반명사 분석은 보존한다. 튜닉/긴 속옷이라는 더 구체적인 옷 형식을 가죽옷으로 넓게 옮겼다. 동물 제사·최초 죽음·대속·제작 동기를 본문에 보충하지 않는다.

Previous v0.4.10

YHWH God made garments of skin for Adam and his wife and clothed them.

Previous v0.4.9

YHWH God made garments of skin for Adam and his wife and clothed them.

## 22 · HYB.GEN.003.022

Hebrew display (MT/WLC): וַיֹּ֣אמֶר ׀ יְהוָ֣ה אֱלֹהִ֗ים הֵ֤ן הָֽאָדָם֙ הָיָה֙ כְּאַחַ֣ד מִמֶּ֔נּוּ לָדַ֖עַת ט֣וֹב וָרָ֑ע וְעַתָּ֣ה ׀ פֶּן־יִשְׁלַ֣ח יָד֗וֹ וְלָקַח֙ גַּ֚ם מֵעֵ֣ץ הַֽחַיִּ֔ים וְאָכַ֖ל וָחַ֥י לְעֹלָֽם׃

YHWH God said, “Look, the human has become like one of us in knowing good and evil. And now, lest he reach out his hand and take also from the tree of life, and eat, and live forever—”

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.22

### Current best selected translation

선과 악을 아는 데서 우리 가운데 하나처럼 되었다는 비교 범위를 보존한다. 펜의 미완결 구문을 살지 않도록과 말줄임표로 현재 표시한다.

#### claude-opus-5-5

Then YHWH God said, “Look, the human has become like one of us in knowing good and bad. And now, lest he reach out his hand and take also from the tree of life, and eat, and live forever—”

Final opinion (Korean original): 채택되지 않은 초안으로 제출한다. ‘우리’는 삼위일체나 신적 회의를 확정하지 않고 열어 두었다. פֶּן 절은 본문처럼 미완결로 두었다. 다른 모델과의 비교 및 편집 채택 절차가 필요하다.

#### gemini-3.8-flash-medium

And Yahweh God said, "Behold, the human has become like one of us in knowing good and evil; and now, lest he reach out his hand and take also from the tree of life, and eat, and live forever—"

Final opinion (Korean original): 주인님, BDB 6435(פֶּן)가 이끄는 미완료 경계절을 3:23의 예방 조치와 연계된 수사적 단절(Aposiopesis)로 파악하여 현대 문장 부호(말줄임표 '…' 및 대시 '—')로 표기한 것은 원문의 통사적 긴장을 효과적으로 보존한 선택입니다. 'הָיָה'를 상태적 과거('was')가 아닌 결과적 완료('has become/되었다')로 옮긴 것도 설득력이 있습니다. 다만 '선악을 아는 일에 우리 중 하나처럼 되었다'는 표현을 전면적인 신적 동등성으로 비약해서는 안 되며, '우리'의 지칭 대상을 삼위일체나 천상 회의로 단정하지 않고 열어둔 태도는 필수적입니다. 또한 하나님이 불안이나 공포를 느꼈다고 단정하는 것은 문법적 증거가 아닌 심리적 추론이므로 본문 번역의 근거로 삼지 않습니다.

#### gpt-6.1-sol

YHWH God said, “Look, the human has become like one of us in knowing good and evil. And now, lest he reach out his hand and take also from the tree of life, and eat, and live forever—”

Final opinion (Korean original): 선과 악을 아는 데서 우리 가운데 하나처럼 되었다는 비교 범위를 보존한다. 펜의 미완결 구문을 살지 않도록과 말줄임표로 현재 표시한다. 이전 상태를 뜻하는 있었다나 반어 독법도 대안이다. 우리 지시 대상을 확정하지 않는다. 말줄임·따옴표는 현대 편집이며 공포·급박함·반어가 원문에 확정되었다고 주장하지 않는다.

Counterargument (Korean): 이전 상태를 뜻하는 있었다나 반어 독법도 대안이다. 우리 지시 대상을 확정하지 않는다. 말줄임·따옴표는 현대 편집이며 공포·급박함·반어가 원문에 확정되었다고 주장하지 않는다.

Previous v0.4.10

YHWH God said, “Look, the human has become like one of us in knowing good and evil. And now, lest he reach out his hand and take also from the tree of life, and eat, and live forever—”

Previous v0.4.9

YHWH God said, “Look, the human has become like one of us in knowing good and evil. And now, lest he reach out his hand and take also from the tree of life, and eat, and live forever—”

## 23 · HYB.GEN.003.023

Hebrew display (MT/WLC): וַֽיְשַׁלְּחֵ֛הוּ יְהוָ֥ה אֱלֹהִ֖ים מִגַּן־עֵ֑דֶן לַֽעֲבֹד֙ אֶת־הָ֣אֲדָמָ֔ה אֲשֶׁ֥ר לֻקַּ֖ח מִשָּֽׁם׃

So YHWH God sent him out from the garden of Eden to work the ground from which he had been taken.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.23

### Current best selected translation

에덴동산에서 내보냄과 그가 취해진 땅을 일구는 목적을 보존한다.

#### gemini-3.8-flash-medium

Therefore Yahweh God sent him out from the garden of Eden to work the ground from which he was taken.

Final opinion (Korean original): 주인님, 23절의 'וַיְשַׁלְּחֵהוּ'를 '내보내어(sent out)'로, 'לַעֲבֹד אֶת־הָאֲדָמָה'를 '땅을 일구게/경작하게 하셨다'로 번역한 것은 원문의 어휘를 과장 없이 정직하게 옮긴 표준적 귀결입니다. 다만 23절의 '내보냄'과 24절의 '쫓아냄(가라쉬)'의 어휘 차이를 지나치게 도식화하여 23절은 자비로운 파송/합법적 퇴거이고 24절만 물리적 폭력성 추방이라고 이분법적으로 확정 짓는 것은 어휘의 의미 중첩 가능성을 과도하게 제한하는 해석일 수 있으므로 주의해야 합니다.

#### gpt-6.1-sol

So YHWH God sent him out from the garden of Eden to work the ground from which he had been taken.

Final opinion (Korean original): 에덴동산에서 내보냄과 그가 취해진 땅을 일구는 목적을 보존한다. 그래서는 앞 구문과의 결과 관계를 자연스럽게 잇는 편집 선택이다. 내보내다와 다음절 쫓아내다를 구별하되 사명 파견·합법 퇴거·물리적 폭력을 동사만으로 확정하지 않는다.

Counterargument (Korean): 그래서는 앞 구문과의 결과 관계를 자연스럽게 잇는 편집 선택이다. 내보내다와 다음절 쫓아내다를 구별하되 사명 파견·합법 퇴거·물리적 폭력을 동사만으로 확정하지 않는다.

Previous v0.4.10

So YHWH God sent him out from the garden of Eden to work the ground from which he had been taken.

Previous v0.4.9

So YHWH God sent him out from the garden of Eden to work the ground from which he had been taken.

## 24 · HYB.GEN.003.024

Hebrew display (MT/WLC): וַיְגָ֖רֶשׁ אֶת־הָֽאָדָ֑ם וַיַּשְׁכֵּן֩ מִקֶּ֨דֶם לְגַן־עֵ֜דֶן אֶת־הַכְּרֻבִ֗ים וְאֵ֨ת לַ֤הַט הַחֶ֨רֶב֙ הַמִּתְהַפֶּ֔כֶת לִשְׁמֹ֕ר אֶת־דֶּ֖רֶךְ עֵ֥ץ הַֽחַיִּֽים׃

He drove out the human and stationed the cherubim and the flame of the turning sword east of the garden of Eden to guard the way to the tree of life.

Source: https://raw.githubusercontent.com/openscriptures/morphhb/3d15126fb1ef74867fc1434be1942e837932691f/wlc/Gen.xml · Gen.3.24

### Current best selected translation

그 사람을 쫓아내고 동쪽에 케루빔들과 돌아가는 칼의 불꽃을 두어 길을 지키는 구문을 옮긴다.

#### claude-opus-5-5

He drove the human out, and east of the garden of Eden he stationed the cherubim and the flame of the sword that turned back and forth, to guard the way to the tree of life.

Final opinion (Korean original): 채택되지 않은 초안으로 제출한다. 방향은 ‘동쪽’, 목적어는 두 개, 분사는 칼에 일치하고, 목적은 ‘길을 지키게’로 옮겼다. 아기 천사의 모습이나 칼을 든 손 같은 묘사는 넣지 않았다.

#### gemini-3.8-flash-medium

He drove out the man, and stationed at the east of the garden of Eden the cherubim and the flame of the whirling sword to guard the way to the tree of life.

Final opinion (Korean original): 주인님, BDB 6924에 근거한 공간적 방위 '동쪽(east of)', BDB 3742의 미지의 형상을 지닌 에덴 경계 수호자 '케루빔', 그리고 BDB 3858에 기반한 '이리저리 도는 칼의 불꽃(flame of the turning sword)'의 배치는 원문 어휘에 철저히 부합합니다. 본문에서 케루빔과 회전하는 칼의 불꽃이 대등한 직접목적어로 병렬되어 있어 '천사가 손에 칼을 쥐고 있다'는 기술이 나타나지 않는 것은 사실입니다. 그러나 텍스트가 쥐는 행위를 서술하지 않았다고 해서 칼을 잡는 가능성 자체가 원천 배제되었다고 단정할 필요는 없으며, 본문에 없는 아기 천사나 칼의 작동 기제를 임의로 투영하지 않고 묘사된 텍스트 자체만을 담아낸 현재의 번역이 가장 엄밀합니다.

#### gpt-6.1-sol

He drove out the human and stationed the cherubim and the flame of the turning sword east of the garden of Eden to guard the way to the tree of life.

Final opinion (Korean original): 그 사람을 쫓아내고 동쪽에 케루빔들과 돌아가는 칼의 불꽃을 두어 길을 지키는 구문을 옮긴다. 여성 분사는 칼과 일치한다. 케루빔의 해부학·칼을 쥔 손·정확한 회전 기제를 넣지 않는다. 목적어 병렬만으로 손에 들 수 없다고 증명하지도 않는다.

Counterargument (Korean): 여성 분사는 칼과 일치한다. 케루빔의 해부학·칼을 쥔 손·정확한 회전 기제를 넣지 않는다. 목적어 병렬만으로 손에 들 수 없다고 증명하지도 않는다.

Previous v0.4.10

He drove out the human and stationed the cherubim and the flame of the turning sword east of the garden of Eden to guard the way to the tree of life.

Previous v0.4.9

He drove out the human and stationed the cherubim and the flame of the turning sword east of the garden of Eden to guard the way to the tree of life.

## Notes

Verse 1 selects a rhetorical did God really say question, also listed in BDB. Exclamatory or unfinished-speech alternatives remain open. Not from any tree is selected, with not from every tree retained as a scope alternative. The serpent is not identified by an added theological name.

Verses 2–3 are one speech by the woman. The reported do not touch prohibition is retained, without harmonizing it to chapter 2 or assigning blame for the difference. The supplied 1cp tag for ממנו in v. 3 remains in the source analysis; the contextual rendering is from it. Lest expresses an avoided outcome, without settling the speaker’s psychology.

Verses 4–5 are one speech by the serpent. Verse 4 selects certainly will not die while retaining a denial of the certainty of death as an alternative. Immediate death, delay and immortality are not settled by the construction or the final nun.

Like God in v. 5 is the current choice, with like gods/divine beings as an alternative. The first knowing participle is singular and the later one plural; the latter’s attachment remains discussable. BDB lists this verse twice under God, without exhausting syntactic options. The scope of good and evil is not restricted to one doctrinal or biological explanation.

You is plural in vv. 1, 3, 4 and 5; English leaves you uncluttered and explains the plurality here. Spanish uses ustedes forms. Quotation marks, question marks and sentence divisions are editorial, not a transcription of modern punctuation from an ancient manuscript.

Verse 6 selects desirable for gaining wisdom. BDB lists this verse under look at while discussing cognitive alternatives; the visual reading is not disproved. The scope of the third evaluative clause remains discussable. With her does not establish his presence throughout the preceding dialogue.

Verse 7 selects waist coverings. BDB lists girdle and loin-covering for this verse. Sewing leaves does not establish size, cut, complexity or full-body clothing. The supplied singular tag for leaf is preserved; translations express the collective naturally.

Verse 8 selects sound for qol, which can also mean voice, and attaches walking about to God; movement of the sound remains an alternative. The day/evening wind entry in BDB informs the breeze wording, without fixing time, temperature, direction, storm or a daily habit. Breeze is a translation choice, not a verified wind strength.

Verse 9 selects the man and singular you; Adam remains a naming alternative, without a universal rule from the article alone. Verse 10 is his first-person answer. Sound/voice alternatives remain; Spanish Te oí leaves the noun sound implicit. Present nakedness and English/Spanish past-tense backshift are rendering choices; guilt, repentance, clothing effectiveness and a fixed chronology are not added.

In v. 11 the negation belongs to the command not to eat, not to the main question. The supplied 1cp tag for ממנו is preserved while context selects from the tree. Verse 12 retains gave/gave and the resumed she; Korean makes the omitted edible item explicit. Motives such as blame are interpretive possibilities, not added speech. Verse 13 retains her deception statement without adding Satan, coercion or acquittal.

Verse 14 selects comparison above all animals, retaining among/separation alternatives. This does not establish a separate curse on every other animal, earlier legs or anatomical change. Belly movement and eating dust remain in the text, without exclusive symbolic or biological claims. The serpent-directed quotation spans vv. 14–15 and closes at v. 15.

In v. 15 zera is grammatically masculine singular; BDB lists the animal and woman offspring here as collective. Hu currently refers to her offspring, without grammar alone settling or excluding an individual referent. Spanish feminine descendencia/la is target-language agreement, not a Hebrew feminine subject. Both shuf forms are rendered strike; bruise and stronger/context-dependent verbs remain alternatives. Lexical repetition does not establish equal injury or a final outcome.

No specific Septuagint or Vulgate edition or manuscript was collated for this batch; model generalizations are not adopted as witness evidence. Jesus, Mary and Satan are not added to the text. Later individual interpretations can be discussed separately from linguistic selection. Raw model quotation errors and overstatements remain distinct from the pinned source and editorial evidence. The main question in v. 11 is not negative; the negation is inside the command. Modern quotation boundaries are editorial. Individual reference can also be discussed linguistically.

Verse16 selects pain in pregnancy as a combined reading of two coordinated nouns. The alternative pain and pregnancy/conception preserves the surface structure and remains in the initial GPT/Claude drafts. Neither pregnancy frequency nor hendiadys is established as certain. Its first pain noun also occurs as toil in v17; its second pain noun is related but distinct.

Desire is directed toward the husband without selecting control, sexuality or hostility alone. He will rule is selected as a contextual prediction, not rewritten as an imperative. The imperfect form alone does not settle all normative or theological questions. Model readings about fallen power, hope or original sin remain distinct from linguistic evidence.

Verse17 selects Adam, with the man retained as an alternative; the ground is the direct subject of the curse. Imported1cp for mimennu and2fs for lakh in v18 remain unchanged. GKC103 tables and discourse support from the tree and the male addressee. The upstream accent-comparison note in v17 remains separate metadata; no fresh physical L/BHS collation is claimed.

Field plants in v18 are not restricted to a particular species or cultivated crops. Verse19 selects bread, keeping food as an alternative, and distinguishes ground/dust. Korean dust wording differs from2:7 without asserting a different material. Verse20 retains the literary Eve/living relation without proving historical etymology, naming motive or biological ancestry of all organisms. Quotation marks across vv17–19 are modern editing.

Verse 21 retains making garments of skin and clothing them. Animal sacrifice, a first death and atonement are not inserted as direct assertions. Adam/the man and tunics/garments remain translation alternatives.

Verse 22 selects has become like one of us in knowing good and evil, leaving the plural referent open. Its lest clause remains unfinished and is followed by the sending out in v. 23; BDB discusses aposiopesis here. Was, irony and completed paraphrase remain discussable. Fear or urgency is not certain. Quotation marks and ellipses are modern editing.

Sent out in v. 23 and drove out in v. 24 remain distinct without proving a mission, legal eviction or physical violence from the verbs alone. Verse 24 retains two objects: cherubim and the flame of the turning sword; the feminine participle agrees with sword. No hand, infant angel, anatomy or rotation mechanism is supplied. Coordination does not prove holding impossible, nor east an exact gate location.

## Citation

Hansam Yang. Original Bible: Genesis 3:1–24 (en), research pilot v0.4.11. https://yangs777.github.io/hansam-bible/en/genesis-3/

Editorial material: CC BY 4.0 to the extent rights are held. Ancient WLC text: public domain. OSHB morphology: CC BY 4.0, Open Scriptures Hebrew Bible.

No human specialist approval is claimed.

Source transformation: OSHB separators removed; original vowel/accent codepoints preserved; punctuation spacing adapted.
